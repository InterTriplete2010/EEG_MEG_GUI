%Build ICA from scratch

seed = 9; 
rand('seed',seed);
randn('seed',seed);

%Number of soucre signals
n = 2;

%Load waveforms
cd('C:\Users\press\OneDrive\Desktop\Aging grant\29_10_2019')
[s1 Fs1] = audioread('Quiet_Male_IV_60_seconds_1_Chan.wav');
s1 = s1./std(s1);
[s2 Fs2] = audioread('Quiet_Female_IV_60_seconds_1_Chan.wav');
s2 = s2./std(s2);

s = [s1,s2];

%Number of data points
N = size(s1,1);

%Making a mixing matrix
A = randn(n,n);
%A = [1 0.99;0.99 1];
x = s*A;

% cd('C:\Users\press\OneDrive\Desktop\Pilot Aging EEG\Reconstruction\Stimuli\Mixed')
% [ss Fs1] = audioread('Mixed_Male_I_Female_III_Paused_RMS_80.wav');
% N = size(ss,1);
% x = [];
% x = [(ss*0.4 + ss*10) (ss/0.4 + ss*0.7)];

%Preprocessing the data
mu = mean(x);
x = x - repmat(mu,[N,1]);

%Whitening the data to have uncorrelated rows of the signals recorded
Sx = x'*x;
[V,D] = eig(Sx);
x = (V*sqrt(inv(D))*V'*x')';

%Initialize the unmixing matrix
W = eye(n,n);

%Initialize u, the estimated source signals 
u = x*W;

max_iter = 100;
eta = 0.5; %Step size for gradient descent

hs = zeros(max_iter,1);
gs = zeros(max_iter,1);

for iter = 1:max_iter
   
    display(['iter# :' num2str(iter)])
    
    u = x*W;
    
    %Get estimated maximum entropy signals U = cdf(u)
    U = tanh(u);    %This is the derivative of the function G1 = (1/a1)*ln(cosh(a1*x)) with a1 = 1; G1 is one of the feasable functions used to solve ICA (see slid 36);
    
    %h = log(abs(det(W))) + sum(log(eps + 1 - U(:).^2))/N;
    detW = abs(det(W));
    h = ((1./N)*sum(sum(U)) + 0.5*log(detW));   %See slide 48

    g = inv(W') - (2./N)*x'*U;  %This is the gradient of the entropy "h" (see slide 51)
    
    W = W + eta*g;  %Here we update W in order to maximize the entropy negentropy (or minimize the mutual imformation, so to have minimal gaussianity), which is our final goal in order to find independent components. "Eta" is chosen aribtrarly and affects the step of our updated 

    hs(iter) = h;
    gs(iter) = norm(g(:));
    figure(100)
    plot(hs,'-o')
    pause(0.01)
end

cc = 1;