%% EEG_MEG_GUI.m 
%   EEG_MEG_GUI.m is a GUI to analyze EEG and MEG data to continuous speech, 
%   clicks, tones, syllables, words, ... The GUI includes a set of functions that 
%   complement each other to a full pipeline to process EEG, MEG data.
%
%   References:
%      [1] Presacco A, Simon JZ, Anderson S. Effect of informational content of noise
%           on speech representation in the aging midbrain and cortex. J Neurophysiol
%           116: 2356 –2367, 2016a. doi:10.1152/jn.00373.2016
%
%   Author: Alex Presacco
%   Email: alessandro.presacco@gmail.com
%   Last revision: ?
% 
%%  PIPELINE for natural speech processing
%
%   STEP1: IMPORT BIOSEMI FILES (GUI -> Import data -> EEG -> BioSemi)
%   Import Biosemi files and convert to mat-files
%
%   STEP2: EXTRACT TRIALS (GUI -> Signal Analysis -> Extract trials)
%   First preprocessing - correct for time delay, large artifacts etc... and
%   extract the different trials (remove irrelevant recorded EEG/MEG data)
%
%   STEP3: FILTER (GUI -> Signal Analysis -> Filter -> IIR filter -> Bandpass)
%   Filter EEG/MEG data to remove most artifacts (between 1 and 30 Hz)
%
%   STEP4: REMOVE EYEBLINKS (GUI -> Signal Analysis -> Eye Movement Correction)
%   Remove Eyeblinks (method of Austria)
%
%   STEP5: FILTER (GUI -> Signal Analysis -> Filter -> IIR filter -> Lowpass)
%   Filter EEG/MEG data with the cut-off frequency of interest (8 Hz)
%
%   STEP6: REMOVE SENSORS (GUI -> Tools -> Remove Sensors)
%   Remove external electrodes because these can affect DSS (e.g. eye and/or earlobe electrodes). 
%   Also do this for bad/broken electrodes otherwise DSS will be dominated by the bad electrode.
%
%   STEP7: DSS (GUI -> Signal Analysis -> Extract DSS (ERP))
%   Apply DSS to EEG/MEG data
%
%   STEP8: DECODING MEG DATA (GUI -> Import data -> MEG -> KIT -> Decode MEG Data)
%   Includes both Backward (reconstructs envelope from neural responses) and
%   Forward model (predicts neural responses (create TRF) from envelope).
%   Can be used for MEG and EEG data.
% 
%%  DIFFERENT FUNCTIONS needed for pipeline (add documentation in each matlab-file?)
%
%%  Import Biosemi Files
%   PATH: GUI -> Import data -> EEG -> BioSemi
%   GOAL: Load Biosemi files and convert to mat-files, name folder and
%   files (You have to do this file per file?)
%
%   Upload BDF file                     - Upload BDF file of Biosemi (one file at the time?)
%   Offset parallel port                - ?
%   Remove first trigger                - default = off
%   Index of the Reference electrode    - 65 / 66 are reference electrodes (earlobes)
%   Folder and filename to save data    - Name path, folder and filename to save data
%
%%  Extract trials
%   PATH: GUI -> Signal Analysis -> Extract trials
%   GOAL: Preprocessing (correction for time delay, large artifacts, ...) after converting BDF to mat-format
%         and remove EEG/MEG data that is not needed (between trials)
%
%   Upload EEG          - Load EEG data in mat-files 
%   
%   Time Window:
%   Starttrigger        - 0.0046 (in seconds)
%   Endtrigger          - 60.0046 (in seconds)
%   Adj time            - time delay
%
%   Artifact Rejection: - Keep defaults
%
%   Latency Peaks:      - Keep defaults (cortical P1-N1-P2 complex)
%
%   RMS (peaks):        - ?
%   
%   Name File:          - Name filename
%
%   Extract Trials:
%   Trigger Code        - will be automatically loaded when loading EEG mat-file
%   Channels            - All channels will appear (also extended)
%   EEG/MEG data        - select this?
%   Max # sweeps        - we have 3 repetitions in one BDF, but you can leave it at 500
%
%   Time domain:        - Alternated polarity (useful for FFRs?)
%                       - Plot and save averages?
%                       - Plot and save Scalp Map
%
%%  Filter
%   PATH: GUI -> Signal Analysis -> Filters -> IIR filter -> Bandpass
%   GOAL: Filter EEG/MEG data
%
%   Upload EEG/MEG          - Load EEG data 
%   Cut-off Low F           - cut-off low frequency in Hz (recommendation: 1 Hz)
%   Cut-off High F          - cut-off high frequency in Hz (recommendation: 8 Hz)
%   1 pole (~6 dB/octave)   - order of Butterworth filter (check stability of filter by calling function check_stability(coef of filter))
%   Zero phase              - phase delay of filter (zero phase is recommended)
%
%%  Eye Movement Correction
%   PATH: GUI -> Signal Analysis -> Eye Movement Correction
%   GOAL: Remove Eyeblinks
% 
%   References:
%      [1] Method of Austria?
%
%   Upload EEG/MEG          - Load preprocessed and filtered EEG data 
%   Vertical and horizont   - Load same file?
%                           - Vertical = EX1?
%                           - Horizontal = EX8?
%
%%  Extract DSS Components
%   PATH: GUI -> Signal Analysis -> Extract DSS (ERP)
%   PATH: GUI -> Import data -> MEG -> KIT -> Extract DSS (ERP) =>
%   difference?
%   GOAL: Extract DSS components
% 
%   References:
%      [1] ?
%
%   Upload EEG          - Load EEG data 
%   P1, N1, P2          - Time windows (in ms) to extract the cortical P1-N1-P2 complex 
%                         (not a problem for continuous speech, just leave the defaults)
%   Fine name for peak  - Type file name!
%   Concatenate files   - Each trial is in one math file?
%   Sweeps              - Number of sweeps/repetitions (for continuous speech = 3, for FFRs = 2000)
%
%%  Decoding MEG data 
%   PATH: GUI -> Import data -> MEG -> KIT -> Decode MEG Data
%   GOAL: perform Backward (reconstructs envelope from neural responses) or Forward model (predicts neural responses (create TRF) from envelope).
%   EXTRA INFORMATION:
%   Training/Testing:       90%/10% of data = training/testing. 60 seconds data is divided in 10 segments. 
%                           Use cross-cross validation to train model on 9 of the ten segments and then test on remaning segements, repeat this 10 times, with each time different training and testing set.           
%                           Boosting is used for both forward and backward model
%   Outcome:                Backword - Reconstruction value = average of 10 correlations
%                           Forward - TRF = average of 10 TRF models
%
%   1. UPLOAD DATA AND STIMULUS
%
%   MEG                 - MEG directory (e.g. folder with different subjects, but all the same condition/stimulus)
%   Weights             - ?
%   Subject #           - Specifiy how many subjects you have loaded (does not matter?)
%   Target Foreground   - load wav-file of foreground stimulus for particular condition (see MEG)
%   Target Background   - load wav-file of background stimulus for particular condition (see MEG) 
%                         !Can be empty when you select Backward model Quiet (only foreground)!
%   Stimulus Noise      - Upload another wav-file to calculate the noise floor / significance level 
%                         (noise floor is now calculated using a different manner, so you can leave this empty/NA)
%           
%   2. FILTER PARAMETERS (needs to be integer numbers)
%
%   Sampling frequency, decimation and time shift:
%   SF                  - sampling frequency (automatically appears when loading preprocessed MEG mat-files)
%   Dec Fact            - 1 (no decimation), 32 (EEG), 50 (MEG). 
%   TW                  - Temporal window or Integration window in ms. Type the different lengths that you want (e.g. 500 and 250).
%
%   FIR filter for raw MEG: see specifics function Filter
%   not needed if you loaded preprocessed filtered MEG or EEG data. If you did not do this, check "filter data" and set the right parameters.
%   ?? What means 1400 as default??
%
%   IIR filter for the DSS: see specifics function Filter
%   click "Filter MEG data" if you did not filter the MEG data before DSS. If you did not check this, it will only filter the stimulus between cut-off F
%
%   3. DECODING MEG DATA
%
%   Decoding MEG data   - Backward Model (Average Trials) 
%                       - Backward Model (Single Trials) => Default when using DSS?
%                       - Forward Model (Average Trials)
%                       - Forward Model (Single Trials) => Default when using DSS?
%                       - Quiet Backward Model (Average Trials) => when you don't have a competing stimulus (do not upload stimulus target for background)
%                       - Quiet Forward Model (Average Trials) => when you don't have a competing stimulus 
%                       - Extract Auditory DSS?
%                       - Extract Auditory DSS (concatenate)?
%                       - DSS different rotation matrix?
%   Component DSS       - Backward: 6 (will combine the 6 first DSS components for MEG. For EEG, you need 6 or 10.)
%                       - Forward: 1 (uses the 64 DSS components to predict the EEG/MEG?) 
%
%%  OTHER FUNCTIONS OR INFORMATION
%
%%  check_stability(bb, aa)
%   GOAL: Checks stability of filter. 
%   When pools (~ order) are outside the unit circle, you have a unstable filter. When increasing the order of your filter, it can happen that your filter becomes unstable and you get artifacts. 
%   You can also use the fvtool() function of matlab to visualize magnitude response of your filter (check beginning for artifacts)
%
%   bb aa  - coefficients of your filter (e.g. butter(4,[1 30]/1024) = unstable filter)
%
%%  Save mat-format (if multiple subjects - 3D matrix)
%
%   cross_val               - corr of each ten semgents (60 seconds divided in each 6 seconds for cross-validation)
%   mean                    - mean of 10 cross_val values is outcome that we use
%   names                   - name of mat-file / stimulus-file. Handy if you save the data of different persons or conditions, 
%                             then you can infer which values of which row match with which condition/stimulus...
%   measure_speech_env      - actual speech envelope per 6s segment (if you want to plot this in the paper, you don't have to recalculate it)
%   measure_speech_pred     - predicted/reconstructed speech envelope per 6s segement   
%   optimal filter          - only useful for forward model: TRF for each DSS, ordered in the correct order
%