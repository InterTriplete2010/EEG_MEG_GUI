function varargout = Frequency_Discrimination(varargin)
% FREQUENCY_DISCRIMINATION MATLAB code for Frequency_Discrimination.fig
%      FREQUENCY_DISCRIMINATION, by itself, creates a new FREQUENCY_DISCRIMINATION or raises the existing
%      singleton*.
%
%      H = FREQUENCY_DISCRIMINATION returns the handle to a new FREQUENCY_DISCRIMINATION or the handle to
%      the existing singleton*.
%
%      FREQUENCY_DISCRIMINATION('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in FREQUENCY_DISCRIMINATION.M with the given input arguments.
%
%      FREQUENCY_DISCRIMINATION('Property','Value',...) creates a new FREQUENCY_DISCRIMINATION or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before Frequency_Discrimination_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to Frequency_Discrimination_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help Frequency_Discrimination

% Last Modified by GUIDE v2.5 18-Jun-2018 09:44:54

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Frequency_Discrimination_OpeningFcn, ...
                   'gui_OutputFcn',  @Frequency_Discrimination_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before Frequency_Discrimination is made visible.
function Frequency_Discrimination_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to Frequency_Discrimination (see VARARGIN)

% Choose default command line output for Frequency_Discrimination
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes Frequency_Discrimination wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = Frequency_Discrimination_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Reset the number of trials
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in Reset_Trials_Freq_Discr.
function Reset_Trials_Freq_Discr_Callback(hObject, eventdata, handles)
% hObject    handle to Reset_Trials_Freq_Discr (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global trial_number;    %Current trial
global track_reversals;
global track_steps;
global current_fig;

track_steps = 0;
track_reversals = 0;
trial_number = 0;
current_fig = figure;
grid on

set(handles.Current_Trial_Freq_Discr,'String',trial_number);
set(handles.Percentage_completed_Trials_Freq_Discr,'String',0);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Current trial
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Current_Trial_Freq_Discr_Callback(hObject, eventdata, handles)
% hObject    handle to Current_Trial_Freq_Discr (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Current_Trial_Freq_Discr as text
%        str2double(get(hObject,'String')) returns contents of Current_Trial_Freq_Discr as a double


% --- Executes during object creation, after setting all properties.
function Current_Trial_Freq_Discr_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Current_Trial_Freq_Discr (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Percentage number of trials completed
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Percentage_completed_Trials_Freq_Discr_Callback(hObject, eventdata, handles)
% hObject    handle to Percentage_completed_Trials_Freq_Discr (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Percentage_completed_Trials_Freq_Discr as text
%        str2double(get(hObject,'String')) returns contents of Percentage_completed_Trials_Freq_Discr as a double


% --- Executes during object creation, after setting all properties.
function Percentage_completed_Trials_Freq_Discr_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Percentage_completed_Trials_Freq_Discr (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Maximum number of trials allowed
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Max_Number_Trials_Freq_Discr_Callback(hObject, eventdata, handles)
% hObject    handle to Max_Number_Trials_Freq_Discr (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Max_Number_Trials_Freq_Discr as text
%        str2double(get(hObject,'String')) returns contents of Max_Number_Trials_Freq_Discr as a double


% --- Executes during object creation, after setting all properties.
function Max_Number_Trials_Freq_Discr_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Max_Number_Trials_Freq_Discr (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Frequency Discrimination Stimulus I
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in Stim_I_Freq_Discr.
function Stim_I_Freq_Discr_Callback(hObject, eventdata, handles)
% hObject    handle to Stim_I_Freq_Discr (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global response_I;

response_I = 1; 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Frequency Discrimination Stimulus II
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in Stim_II_Freq_Discr.
function Stim_II_Freq_Discr_Callback(hObject, eventdata, handles)
% hObject    handle to Stim_II_Freq_Discr (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global response_II;

response_II = 1; 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Frequency Discrimination Stimulus III
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in Stim_III_Freq_Discr.
function Stim_III_Freq_Discr_Callback(hObject, eventdata, handles)
% hObject    handle to Stim_III_Freq_Discr (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global response_III;

response_III = 1; 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Start the trial
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in Start_Trial_Freq_Discr.
function Start_Trial_Freq_Discr_Callback(hObject, eventdata, handles)
% hObject    handle to Start_Trial_Freq_Discr (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global stimulus_trial_target;  %Target stimulus to be presented  
global stimulus_trial_probe;  %Probe stimulus to be presented  
global trial_number;    %Current trial
global track_stim_to_be_played; %Keep track of which stimulus needs to be played
global response_I;
global response_II;
global response_III;
global freq_steps;
global upper_bound_values;
global lower_bound_values;
global current_fig;
global track_reversals; %Track the reversal
global track_errors;
global track_steps; %Track the number of steps required to decresase the frequency step (3 is the default) 
global response_plot;
global trials_plot;
global track_slope;
global track_slope_previous;
global track_slope_hit;
global hit_answer;
global miss_answer;
global freq_discr_threshold_track;

central_freq = str2double(get(handles.CF_Stimuli_Freq_Discr,'String'));

response_I = 0;
response_II = 0;
response_III = 0;

responses = [response_I response_II response_III];

set(handles.Start_Trial_Freq_Discr,'BackgroundColor',[1 0 0]);
set(handles.Start_Trial_Freq_Discr,'Enable','off');

max_trials = str2double(get(handles.Max_Number_Trials_Freq_Discr,'String'));

if trial_number == 0
    track_stim_to_be_played = [];
track_stim_to_be_played = size(stimulus_trial_target,1);

track_errors = 0;
track_reversals = 0;
track_slope = 1;
track_slope_previous = 1;
track_slope_hit = 1;

trials_plot = [];
response_plot = [];
freq_discr_threshold_track = [];

hit_answer = zeros(1,max_trials);
miss_answer = zeros(1,max_trials);

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Randomize the presentation of the stimuli
signal_presented = [stimulus_trial_target(track_stim_to_be_played,:);stimulus_trial_probe(track_stim_to_be_played,:);stimulus_trial_probe(track_stim_to_be_played,:)];

rand_sequence = randperm(3);
signal_sequence = signal_presented(rand_sequence,:);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if isempty(signal_presented) || isempty(current_fig)
   
  
    msgbox('No waveform has been created','Missing waveforms');
    
    return;
    
end

if isempty(trial_number)
   
   trial_number = 0; 
    
end

trial_number = trial_number + 1;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Play the first stimulus
set(handles.Stim_I_Freq_Discr,'BackgroundColor',[0 1 0]);

sound(signal_sequence(1,:),str2double(get(handles.SF_Stimuli_Freq_Discr,'String')))
pause (str2double(get(handles.Duration_Freq_I,'String'))/1000 + 0.5);

set(handles.Stim_I_Freq_Discr,'BackgroundColor',[1 1 0]);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Play the second stimulus
set(handles.Stim_II_Freq_Discr,'BackgroundColor',[0 1 0]);

sound(signal_sequence(2,:),str2double(get(handles.SF_Stimuli_Freq_Discr,'String')))
pause (str2double(get(handles.Duration_Freq_II,'String'))/1000 + 0.5);

set(handles.Stim_II_Freq_Discr,'BackgroundColor',[1 1 0]);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Play the third stimulus
set(handles.Stim_III_Freq_Discr,'BackgroundColor',[0 1 0]);

sound(signal_sequence(3,:),str2double(get(handles.SF_Stimuli_Freq_Discr,'String')))
pause (str2double(get(handles.Duration_Freq_II,'String'))/1000 + 0.5);

set(handles.Stim_III_Freq_Discr,'BackgroundColor',[1 1 0]);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

pause(0.5)

%Waiting for the user to respond
while (response_I == 0 && response_II == 0 && response_III == 0)
   
    %Exit the cycle when the user select the response
    pause(1)
end

responses = [response_I response_II response_III];
temp_oct = log2(upper_bound_values(track_stim_to_be_played,1)/lower_bound_values(track_stim_to_be_played,1));
response_plot = [response_plot;temp_oct];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Plot the hit and check the reversals
track_slope_previous = track_slope;

if responses(find(rand_sequence == 1)) == 1
   
    track_slope = 1;
    trials_plot = [trials_plot;trial_number];
      figure(current_fig.Number)  
    hold on
    plot(trial_number(end,1),response_plot(end,1),'-o','Color','k')
    hit_answer(1,trial_number) = 1;
    track_steps = track_steps + 1;
    
    if track_steps == 3 
    
        if track_errors > 0
           
            freq_discr_threshold_track = [freq_discr_threshold_track;response_plot(end,1)]; %Tracking the values of the thresholds
            
        end
        
        try %This try is to avoid the program to crash if the user makes a mistake in the first 6 trials
            
        if track_errors > 0 && sum(hit_answer(trial_number-5:trial_number-3)) < 3   %Check the previous hits to make sure that a reversal occured
       
                track_reversals = track_reversals + 1;
       
        end
        
        catch
            
        end
        
   %This is to make sure that the first reversal is recorded
    if track_errors > 0 && track_reversals == 0
        
         track_reversals = track_reversals + 1;
        
    end
        
        if track_reversals == 0 
            
    track_stim_to_be_played = track_stim_to_be_played - 12; %% Decrease the frequency step => makes the task easier. Decrease the task quickly before making the first error    
    
        else
        
           track_stim_to_be_played = track_stim_to_be_played - 1; %% Decrease the frequency step => makes the task easier    
            
        end
        
        track_steps = 0;
    
            
    if track_errors > 0 && track_slope_previous ~= track_slope
       
        track_reversals = track_reversals + 1;
       
    end
   
    end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Plot the miss and check the reversals    
else
    
    track_slope = -1;
    trials_plot = [trials_plot;trial_number];
    figure(current_fig.Number)
    hold on
    plot(trial_number(end,1),response_plot(end,1),'-*','Color','r')
miss_answer(1,trial_number) = -1;

%If the error occurs at the first trial, then replay that trial
if track_stim_to_be_played == size(stimulus_trial_target,1)
    
    track_steps = 0;
   track_errors = track_errors + 1;
   
else

%% Increase the frequency step => makes the task easier    
track_stim_to_be_played = track_stim_to_be_played + 1;
   track_steps = 0;
   track_errors = track_errors + 1;
   
   if track_errors > 1 && track_slope_previous ~= track_slope == 1;
       
       track_reversals = track_reversals + 1;
       
   end
      
end

end

xlabel('\bfTrial')
ylabel('\bfFrequency step (octave)')
title(['\bfNumber of reversals: ' num2str(track_reversals)])
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
set(handles.Current_Trial_Freq_Discr,'String',trial_number);
set(handles.Percentage_completed_Trials_Freq_Discr,'String',round(100*trial_number/max_trials));

set(handles.Start_Trial_Freq_Discr,'BackgroundColor',[0 1 0]);
set(handles.Start_Trial_Freq_Discr,'Enable','on');

%% If the number of reversals have been achieved, then terminate the task
if track_reversals == str2double(get(handles.Reversal_Freq_Discr,'String'));
   
    temp_rev_av = str2double(get(handles.Average_Reversal_Freq_Discr,'String'));
    freq_discr_threshold = mean(freq_discr_threshold_track(end - temp_rev_av + 1:end,1));
    
    title(['\bfNumber of reversals: ' num2str(track_reversals) '. Frequency Discrimination threshold: ' num2str(freq_discr_threshold)])
    saveas(current_fig,['Results_Subject_' get(handles.Subject_ID_Frq_Discr,'String') '.fig']);
    msgbox('Task completed','End');
    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Duration of Stimulus/Frequency I
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Duration_Freq_I_Callback(hObject, eventdata, handles)
% hObject    handle to Duration_Freq_I (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Duration_Freq_I as text
%        str2double(get(hObject,'String')) returns contents of Duration_Freq_I as a double


% --- Executes during object creation, after setting all properties.
function Duration_Freq_I_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Duration_Freq_I (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Starting step of the stimuli
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Start_Octave_Step_Freq_Discr_Callback(hObject, eventdata, handles)
% hObject    handle to Start_Octave_Step_Freq_Discr (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Start_Octave_Step_Freq_Discr as text
%        str2double(get(hObject,'String')) returns contents of Start_Octave_Step_Freq_Discr as a double


% --- Executes during object creation, after setting all properties.
function Start_Octave_Step_Freq_Discr_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Start_Octave_Step_Freq_Discr (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Number of reversals used to calculate the threshold
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Average_Reversal_Freq_Discr_Callback(hObject, eventdata, handles)
% hObject    handle to Average_Reversal_Freq_Discr (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Average_Reversal_Freq_Discr as text
%        str2double(get(hObject,'String')) returns contents of Average_Reversal_Freq_Discr as a double


% --- Executes during object creation, after setting all properties.
function Average_Reversal_Freq_Discr_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Average_Reversal_Freq_Discr (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Reversals to end the task
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Reversal_Freq_Discr_Callback(hObject, eventdata, handles)
% hObject    handle to Reversal_Freq_Discr (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Reversal_Freq_Discr as text
%        str2double(get(hObject,'String')) returns contents of Reversal_Freq_Discr as a double


% --- Executes during object creation, after setting all properties.
function Reversal_Freq_Discr_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Reversal_Freq_Discr (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Gain of Stimuli
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Gain_Stimuli_Freq_Discr_Callback(hObject, eventdata, handles)
% hObject    handle to Gain_Stimuli_Freq_Discr (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Gain_Stimuli_Freq_Discr as text
%        str2double(get(hObject,'String')) returns contents of Gain_Stimuli_Freq_Discr as a double


% --- Executes during object creation, after setting all properties.
function Gain_Stimuli_Freq_Discr_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Gain_Stimuli_Freq_Discr (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Ramp of Stimuli
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Ramp_Stimuli_Freq_Discr_Callback(hObject, eventdata, handles)
% hObject    handle to Ramp_Stimuli_Freq_Discr (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Ramp_Stimuli_Freq_Discr as text
%        str2double(get(hObject,'String')) returns contents of Ramp_Stimuli_Freq_Discr as a double


% --- Executes during object creation, after setting all properties.
function Ramp_Stimuli_Freq_Discr_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Ramp_Stimuli_Freq_Discr (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Center Frequency of the Stimuli
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function CF_Stimuli_Freq_Discr_Callback(hObject, eventdata, handles)
% hObject    handle to CF_Stimuli_Freq_Discr (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of CF_Stimuli_Freq_Discr as text
%        str2double(get(hObject,'String')) returns contents of CF_Stimuli_Freq_Discr as a double


% --- Executes during object creation, after setting all properties.
function CF_Stimuli_Freq_Discr_CreateFcn(hObject, eventdata, handles)
% hObject    handle to CF_Stimuli_Freq_Discr (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Sampling Frequency of the Stimuli
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function SF_Stimuli_Freq_Discr_Callback(hObject, eventdata, handles)
% hObject    handle to SF_Stimuli_Freq_Discr (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of SF_Stimuli_Freq_Discr as text
%        str2double(get(hObject,'String')) returns contents of SF_Stimuli_Freq_Discr as a double


% --- Executes during object creation, after setting all properties.
function SF_Stimuli_Freq_Discr_CreateFcn(hObject, eventdata, handles)
% hObject    handle to SF_Stimuli_Freq_Discr (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Subject ID
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Subject_ID_Frq_Discr_Callback(hObject, eventdata, handles)
% hObject    handle to Subject_ID_Frq_Discr (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Subject_ID_Frq_Discr as text
%        str2double(get(hObject,'String')) returns contents of Subject_ID_Frq_Discr as a double


% --- Executes during object creation, after setting all properties.
function Subject_ID_Frq_Discr_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Subject_ID_Frq_Discr (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Duration of Stimulus/Frequency II
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Duration_Freq_II_Callback(hObject, eventdata, handles)
% hObject    handle to Duration_Freq_II (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Duration_Freq_II as text
%        str2double(get(hObject,'String')) returns contents of Duration_Freq_II as a double


% --- Executes during object creation, after setting all properties.
function Duration_Freq_II_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Duration_Freq_II (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Create the stimuli based on the information entered
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in Create_Stim_Freq_Discr.
function Create_Stim_Freq_Discr_Callback(hObject, eventdata, handles)
% hObject    handle to Create_Stim_Freq_Discr (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global stimulus_trial_target;  %Target stimulus to be presented  
global stimulus_trial_probe;  %Probe stimulus to be presented  
global freq_steps;
global upper_bound_values;
global lower_bound_values;
global current_fig;

upper_bound_values = [];
lower_bound_values = [];
freq_steps = [];
step_octave = str2double(get(handles.Start_Octave_Step_Freq_Discr,'String'));
flag_step = 0;
temp_step = 120;
track_last_step = [];
central_freq_task = str2double(get(handles.CF_Stimuli_Freq_Discr,'String'));

stimulus_trial_target = [];
stimulus_trial_probe = [];
xout1 = [];
xout2 = [];

while (flag_step == 0)

    tt = [0:12*temp_step];
    
higher_bound = central_freq_task.*(2.^(tt/tt(end)));
lower_bound = central_freq_task./(2.^(tt/tt(end)));

temp_val = log2(higher_bound(2)/lower_bound(2));

track_last_step = [track_last_step;temp_step];

if temp_val == step_octave
    
    flag_step = 1;
    
elseif temp_val > step_octave
    
    temp_step = temp_step + 1;
    
elseif temp_val < step_octave
    
    temp_step = temp_step - 1;
end

if ~isempty(find(temp_step == track_last_step))
    
    flag_step = 1;
    
end

end

freq_steps = [0:12*temp_step];


for kk = 2:str2double(get(handles.Max_Number_Trials_Freq_Discr,'String')) + 1;
    
freq_1 = central_freq_task./(2.^(tt(kk)/tt(end)));   %Staring frequency (first N ms)
freq_2 = central_freq_task.*(2.^(tt(kk)/tt(end)));   %Ending frequency (last N ms)

lower_bound_values = [lower_bound_values;freq_1];
upper_bound_values = [upper_bound_values;freq_2];


rftime = 3/1000; %Rise/Fall time in "s"
sf = str2double(get(handles.SF_Stimuli_Freq_Discr,'String')); %sampling Frequency
length_stim = round(sf/2);  %Duration of each stimulus

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Converting the duration of the stimuli in samples and checking that the
%length of the stimuli are identical
tt_1 = [0:length_stim - 1]/sf; tt_2 = [length_stim:(sf-1)]/sf; 

if length(tt_1) > length(tt_2)
    
  tt_1(:,length(tt_2) + 1:end) = [];   
    
elseif length(tt_1) < length(tt_2)
    
    tt_2(:,length(tt_1) + 1:end) = [];  
    
end

tt_whole = [tt_1 tt_2];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Creating the two stimuli 
% NSamplesEdge = round(rftime*sf); step_freq_vector = zeros(1,NSamplesEdge);
% 
% freq_trans = [linspace(freq_1,freq_1,length(tt_1)) linspace(freq_1,freq_2,NSamplesEdge) linspace(freq_2,freq_2,length(tt_2) - NSamplesEdge)];
% add_trans_freq = cumsum(freq_trans/sf); %Integrating the phases to find the istantaneous frequency
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Creating the two stimuli  and ramping them
x1 = str2double(get(handles.Gain_Stimuli_Freq_Discr,'String')).*sin(2*pi*tt_1*freq_1);
x2 = str2double(get(handles.Gain_Stimuli_Freq_Discr,'String')).*sin(2*pi*tt_2*freq_2);

rftime = str2double(get(handles.Ramp_Stimuli_Freq_Discr,'String'))/1000; %Rise/Fall time in "s"

%Now use the rised cos (hanning window) to ramp the whole signal
NSamples = length(x1); NSamplesEdge = round(rftime*sf);
t = (1:NSamplesEdge); front = 0.5 * (1 - cos(pi*t/NSamplesEdge));
    
steady = ones(1,NSamples-2*NSamplesEdge);

back = front; back(:) = front(end:-1:1); TempEnv = [front,steady,back];

xout1 = [xout1;TempEnv.* x1];
xout2 = [xout2;TempEnv.* x2];

end

stimulus_trial_probe = xout1;  %Probe stimuli to be presented  
stimulus_trial_target = xout2;  %Target stimulis to be presented  

try
   
    audiowrite(['Target_' num2str(central_freq_task) '_Hz_Step_' num2str(temp_step) '.wav'],stimulus_trial_target'.*0.5,sf)
    audiowrite(['Probe_' num2str(central_freq_task) '_Hz_Step_' num2str(temp_step) '.wav'],stimulus_trial_probe'.*0.5,sf)

catch
    
    wavwrite(stimulus_trial_target'.*0.5,sf,['Target_' num2str(central_freq_task) '_Hz_Step_' num2str(temp_step) '.wav'])
    wavwrite(stimulus_trial_probe'.*0.5,sf,['Probe_' num2str(central_freq_task) '_Hz_Step_' num2str(temp_step) '.wav'])
    
end

current_fig = figure;
grid on
msgbox('Waveforms for the experiment have been created','Operation completed');