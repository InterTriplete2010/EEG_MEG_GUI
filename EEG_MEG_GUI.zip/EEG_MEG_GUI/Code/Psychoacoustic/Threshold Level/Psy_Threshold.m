function varargout = Psy_Threshold(varargin)
% PSY_THRESHOLD MATLAB code for Psy_Threshold.fig
%      PSY_THRESHOLD, by itself, creates a new PSY_THRESHOLD or raises the existing
%      singleton*.
%
%      H = PSY_THRESHOLD returns the handle to a new PSY_THRESHOLD or the handle to
%      the existing singleton*.
%
%      PSY_THRESHOLD('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in PSY_THRESHOLD.M with the given input arguments.
%
%      PSY_THRESHOLD('Property','Value',...) creates a new PSY_THRESHOLD or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before Psy_Threshold_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to Psy_Threshold_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help Psy_Threshold

% Last Modified by GUIDE v2.5 10-Dec-2014 23:03:34

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Psy_Threshold_OpeningFcn, ...
                   'gui_OutputFcn',  @Psy_Threshold_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before Psy_Threshold is made visible.
function Psy_Threshold_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to Psy_Threshold (see VARARGIN)

% Choose default command line output for Psy_Threshold
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes Psy_Threshold wait for user response (see UIRESUME)
% uiwait(handles.figure1);

% --- Outputs from this function are returned to the command line.
function varargout = Psy_Threshold_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;
track_trials = 0;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Choose Stim I
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in Stim_I_Psy.
function Stim_I_Psy_Callback(hObject, eventdata, handles)
% hObject    handle to Stim_I_Psy (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

message = 'Please, select Stim II or Stim III';
msgbox(message,'Invalid choice','warn','replace');  

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Choose Stim II
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in Stim_II_Psy.
function Stim_II_Psy_Callback(hObject, eventdata, handles)
% hObject    handle to Stim_II_Psy (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global rand_pos_target;
global save_response;
global track_trials;
global current_db_level;
global three_down;
global trials_number;
global stim_target;

set(handles.Present_Stim_Psy,'BackgroundColor',[0 1 0])

if (rand_pos_target == 2)
    
    save_response(1,track_trials) = current_db_level;
    three_down = three_down + 1;
 
    figure(2000)
 plot(track_trials,save_response(1,track_trials),'o')
 
 grid on
 hold on
 %Checking if the dB level needs to be lowered by 1 step (8dB)   
    if (three_down == 3)
        
        current_db_level = current_db_level - 8;
        three_down = 0;
        stim_target = stim_target/(10^0.4);
        
    end
    
else
    
    save_response(1,track_trials) = current_db_level;
    figure(2000)

    plot(track_trials,save_response(1,track_trials),'*','Color','r')
    
     grid on
 hold on
    
    save_response(1,track_trials) = current_db_level;
    current_db_level = current_db_level + 8;
    three_down = 0;
    stim_target = stim_target*(10^0.4); 
    
end

if (100*(track_trials/trials_number) == 100)
   
    line('XData',[1:track_trials],'YData',save_response)
    
    xlabel('\bfTrial')
    ylabel('\bfdb')
    title(['\bfThe average and std are: ' num2str(mean(save_response)) '+/-' num2str(std(save_response))])
    
 axis([0 (track_trials + 1) (min(save_response) - 20) (max(save_response) + 20)])  
 
 set(handles.Target_Panel,'Visible','on')
set(handles.Distractor_Panel,'Visible','on')
set(handles.Set_dB_Level,'Visible','on')
 
     message = 'The teask has been successfully completed';
msgbox(message,'End of the task','warn','replace');  

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Choose Stim III
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in Stim_III_Psy.
function Stim_III_Psy_Callback(hObject, eventdata, handles)
% hObject    handle to Stim_III_Psy (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global rand_pos_target;
global save_response;
global track_trials;
global current_db_level;
global three_down;
global trials_number;
global stim_target;

set(handles.Present_Stim_Psy,'BackgroundColor',[0 1 0])

if (rand_pos_target == 1)
    
    save_response(1,track_trials) = current_db_level;
    three_down = three_down + 1;
    
  figure(2000)
 
plot(track_trials,save_response(1,track_trials),'o')
 
grid on
 hold on
 %Checking if the dB level needs to be lowered by 1 step (8dB)   
    if (three_down == 3)
        
        current_db_level = current_db_level - 8;
        three_down = 0;
       stim_target = stim_target/(10^0.4);
       
    end
    
else
    
    save_response(1,track_trials) = current_db_level;
    figure(2000)

    plot(track_trials,save_response(1,track_trials),'*','Color','r')
    
     grid on
 hold on
    
    save_response(1,track_trials) = current_db_level;
    current_db_level = current_db_level + 8;
    three_down = 0;
    stim_target = stim_target*(10^0.4);
    
end

if (100*(track_trials/trials_number) == 100)
   
    line('XData',[1:track_trials],'YData',save_response)
    
    xlabel('\bfTrial')
    ylabel('\bfdb')
    title(['\bfThe average and std are: ' num2str(mean(save_response)) '+/-' num2str(std(save_response))])
    
 axis([0 (track_trials + 1) (min(save_response) - 20) (max(save_response) + 20)]) 
 
 set(handles.Target_Panel,'Visible','on')
set(handles.Distractor_Panel,'Visible','on')
set(handles.Set_dB_Level,'Visible','on')
    
     message = 'The teask has been successfully completed';
msgbox(message,'End of the task','warn','replace');
    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Present the stimuli
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in Present_Stim_Psy.
function Present_Stim_Psy_Callback(hObject, eventdata, handles)
% hObject    handle to Present_Stim_Psy (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global rand_pos_target;
global save_response;
global track_trials;
global current_db_level;
global three_down;
global trials_number;
global stim_target;
global stim_distractor;
global Fs;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Initializing the variables
if (isempty(track_trials))
    
set(handles.Target_Panel,'Visible','off')
set(handles.Distractor_Panel,'Visible','off')
set(handles.Set_dB_Level,'Visible','off')

trials_number = str2double(get(handles.Trials_Exp_Psy,'String'));

save_response = zeros(1,trials_number);
current_db_level = str2double(get(handles.dB_Level_Psy,'String'));
save_response(1,1) = current_db_level;    %This is the starting point;

three_down = 0; %Tracking the correct responses;
track_trials = 0;

end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


track_trials = count_trials(track_trials);

    rand_pos_target = randi(2);
    
    set(handles.Present_Stim_Psy,'BackgroundColor',[1 0 0])
    
set(handles.Stim_I_Psy,'BackgroundColor',[0 1 0])
sound(stim_target,Fs)
set(handles.Stim_I_Psy,'BackgroundColor',[1 1 0])

switch rand_pos_target
    
    case 1
set(handles.Stim_II_Psy,'BackgroundColor',[0 1 0])
if (get(handles.Distractor_Check,'Value'))

    sound(stim_distractor,Fs) 

else
    
    pause(3*(length(stim_target)/Fs))

end
set(handles.Stim_II_Psy,'BackgroundColor',[1 1 0])

set(handles.Stim_III_Psy,'BackgroundColor',[0 1 0])
sound(stim_target,Fs)
set(handles.Stim_III_Psy,'BackgroundColor',[1 1 0])


    case 2

set(handles.Stim_II_Psy,'BackgroundColor',[0 1 0])
sound(stim_target,Fs)
set(handles.Stim_II_Psy,'BackgroundColor',[1 1 0])

set(handles.Stim_III_Psy,'BackgroundColor',[0 1 0])
    if (get(handles.Distractor_Check,'Value'))

    sound(stim_distractor,Fs) 

else
    
    pause(3*(length(stim_target)/Fs))

end
set(handles.Stim_III_Psy,'BackgroundColor',[1 1 0])


end

set(handles.Track_Numb_Psy,'String',track_trials);
set(handles.Perc_Completed_Psy,'String',100*(track_trials/trials_number));



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Reset the number of trials to "0"
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in Reset_Trials_Psy.
function Reset_Trials_Psy_Callback(hObject, eventdata, handles)
% hObject    handle to Reset_Trials_Psy (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global track_trials;
global stim_target;
global dir_target;
global wav_target;
global stim_distractor;
global dir_distractor;
global wav_distractor;

cd(dir_target)
[stim_target Fs] = wavread(wav_target);

try
cd(dir_distractor)

[stim_distractor Fs] = wavread(wav_distractor);

catch
    
end

track_trials = [];

set(handles.Track_Numb_Psy,'String','0');
set(handles.Perc_Completed_Psy,'String','0');

 try
    close(2000)

    catch
    
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Display the # of trials
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Track_Numb_Psy_Callback(hObject, eventdata, handles)
% hObject    handle to Track_Numb_Psy (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Track_Numb_Psy as text
%        str2double(get(hObject,'String')) returns contents of Track_Numb_Psy as a double


% --- Executes during object creation, after setting all properties.
function Track_Numb_Psy_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Track_Numb_Psy (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Percentage completed of trials
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Perc_Completed_Psy_Callback(hObject, eventdata, handles)
% hObject    handle to Perc_Completed_Psy (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Perc_Completed_Psy as text
%        str2double(get(hObject,'String')) returns contents of Perc_Completed_Psy as a double


% --- Executes during object creation, after setting all properties.
function Perc_Completed_Psy_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Perc_Completed_Psy (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Upload the target stimulus
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in Upload_Target_Psy.
function Upload_Target_Psy_Callback(hObject, eventdata, handles)
% hObject    handle to Upload_Target_Psy (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global stim_target;
global dir_target;
global wav_target;
global Fs;

[wav_target,dir_target] = uigetfile('*.wav','Select the distractor file');

cd(dir_target)
[stim_target Fs] = wavread(wav_target);

set(handles.Target_Uploaded_Psy,'String',wav_target);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Upload the disctractor
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in Upload_Distractor_Psy.
function Upload_Distractor_Psy_Callback(hObject, eventdata, handles)
% hObject    handle to Upload_Distractor_Psy (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global stim_distractor;
global dir_distractor;
global wav_distractor;
global Fs;

[wav_distractor,dir_distractor] = uigetfile('*.wav','Select the distractor file');

cd(dir_distractor)
[stim_distractor Fs] = wavread(wav_distractor);

set(handles.Disctractor_Uploaded,'String',wav_distractor);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Distractor Uploaded
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Disctractor_Uploaded_Callback(hObject, eventdata, handles)
% hObject    handle to Disctractor_Uploaded (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Disctractor_Uploaded as text
%        str2double(get(hObject,'String')) returns contents of Disctractor_Uploaded as a double


% --- Executes during object creation, after setting all properties.
function Disctractor_Uploaded_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Disctractor_Uploaded (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Target Uploaded
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Target_Uploaded_Psy_Callback(hObject, eventdata, handles)
% hObject    handle to Target_Uploaded_Psy (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Target_Uploaded_Psy as text
%        str2double(get(hObject,'String')) returns contents of Target_Uploaded_Psy as a double


% --- Executes during object creation, after setting all properties.
function Target_Uploaded_Psy_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Target_Uploaded_Psy (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Trials Experiment
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Trials_Exp_Psy_Callback(hObject, eventdata, handles)
% hObject    handle to Trials_Exp_Psy (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Trials_Exp_Psy as text
%        str2double(get(hObject,'String')) returns contents of Trials_Exp_Psy as a double


% --- Executes during object creation, after setting all properties.
function Trials_Exp_Psy_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Trials_Exp_Psy (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Select the dB level and the stimuli
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in Select_dB_Stimuli.
function Select_dB_Stimuli_Callback(hObject, eventdata, handles)
% hObject    handle to Select_dB_Stimuli (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.Target_Panel,'Visible','on')
set(handles.Distractor_Panel,'Visible','on')
set(handles.Set_dB_Level,'Visible','on')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%dB level 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function dB_Level_Psy_Callback(hObject, eventdata, handles)
% hObject    handle to dB_Level_Psy (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of dB_Level_Psy as text
%        str2double(get(hObject,'String')) returns contents of dB_Level_Psy as a double


% --- Executes during object creation, after setting all properties.
function dB_Level_Psy_CreateFcn(hObject, eventdata, handles)
% hObject    handle to dB_Level_Psy (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%If checked, a distractor will be used
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in Distractor_Check.
function Distractor_Check_Callback(hObject, eventdata, handles)
% hObject    handle to Distractor_Check (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of Distractor_Check
