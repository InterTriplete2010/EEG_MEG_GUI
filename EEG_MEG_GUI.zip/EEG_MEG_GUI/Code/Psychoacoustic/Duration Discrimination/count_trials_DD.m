function track_trials = count_trials_DD(track_trials);


track_trials = track_trials + 1;

