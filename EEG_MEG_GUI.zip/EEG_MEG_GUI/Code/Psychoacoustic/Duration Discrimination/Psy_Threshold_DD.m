function varargout = Psy_Threshold_DD(varargin)
% PSY_THRESHOLD_DD MATLAB code for Psy_Threshold_DD.fig
%      PSY_THRESHOLD_DD, by itself, creates a new PSY_THRESHOLD_DD or raises the existing
%      singleton*.
%
%      H = PSY_THRESHOLD_DD returns the handle to a new PSY_THRESHOLD_DD or the handle to
%      the existing singleton*.
%
%      PSY_THRESHOLD_DD('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in PSY_THRESHOLD_DD.M with the given input arguments.
%
%      PSY_THRESHOLD_DD('Property','Value',...) creates a new PSY_THRESHOLD_DD or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before Psy_Threshold_DD_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to Psy_Threshold_DD_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help Psy_Threshold_DD

% Last Modified by GUIDE v2.5 16-Dec-2014 08:31:16

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Psy_Threshold_DD_OpeningFcn, ...
                   'gui_OutputFcn',  @Psy_Threshold_DD_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before Psy_Threshold_DD is made visible.
function Psy_Threshold_DD_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to Psy_Threshold_DD (see VARARGIN)

% Choose default command line output for Psy_Threshold_DD
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes Psy_Threshold_DD wait for user response (see UIRESUME)
% uiwait(handles.figure1);

% --- Outputs from this function are returned to the command line.
function varargout = Psy_Threshold_DD_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Choose Stim I
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in Stim_I_Psy_DD.
function Stim_I_Psy_DD_Callback(hObject, eventdata, handles)
% hObject    handle to Stim_I_Psy_DD (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global rand_pos_target;
global save_response;
global track_trials;
global current_DLS;
global step_down;
global trials_number;
global stim_target;
global Fs;
global current_step;
global Track_reversals;
global flag_average;
global Subject_ID;
global fig_tag;
global IFC_task;
global stop_flag;
global save_mean_position;
global stim_comp;
global save_mean_error_pos;

%set(handles.Present_Stim_Psy_DD,'BackgroundColor',[0 1 0])
set(handles.Present_Stim_Psy_DD,'Enable','on');

if (rand_pos_target == 1)
    
    save_response(1,track_trials) = current_DLS;
    step_down = step_down + 1;
    
  figure(2000)
 
plot(track_trials,save_response(1,track_trials),'o')

hold on

fig_tag = gcf;
set(fig_tag,'Visible','off')
 
%grid on
 %hold on
 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Making the target stimulus longer 
 %Checking if the duration needs to be lowered by 1 step (15ms or 2ms)   
    if (step_down == IFC_task)
     
        %% Checking if the current threshold value should be used for the final average
        if(~isempty(save_mean_error_pos))
            if (stop_flag == 0 && (track_trials - save_mean_error_pos(1,end)) == 3)
                    
save_mean_position = [save_mean_position save_mean_error_pos(1,end) track_trials];
            
            end
        end
        
        current_DLS = current_DLS - current_step;
        step_down = 0;
       t = [0:1/Fs:(length(stim_target) - round((current_step/1000)*Fs))/Fs];
stim_target_temp = str2double(get(handles.Gain_Psy_DD,'String'))*sin(2*pi*str2double(get(handles.CF_Psy_DD,'String'))*t);

stim_target = [];

stim_target = AddTemporalRamps(stim_target_temp,str2double(get(handles.Ramp_Psy_DD,'String'))/1000,Fs,1);

 
    end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Detecting and plotting an error in the discrimination task
else
    
    if (stop_flag == 0)
            
save_mean_error_pos = [save_mean_error_pos track_trials];
            
        end
    
    save_response(1,track_trials) = current_DLS;
    figure(2000)

    plot(track_trials,save_response(1,track_trials),'*','Color','r')
    
    hold on
    
    fig_tag = gcf;
set(fig_tag,'Visible','off')
    
     %grid on
 %hold on

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Making the target stimulus longer and counting the reversals
Track_reversals = Track_reversals + 1;
    save_response(1,track_trials) = current_DLS;
    current_DLS = current_DLS + current_step;
    step_down = 0;
    
    t = [0:1/Fs:(length(stim_target) + round((current_step/1000)*Fs))/Fs];
stim_target_temp = str2double(get(handles.Gain_Psy_DD,'String'))*sin(2*pi*str2double(get(handles.CF_Psy_DD,'String'))*t);

stim_target = [];

stim_target = AddTemporalRamps(stim_target_temp,str2double(get(handles.Ramp_Psy_DD,'String'))/1000,Fs,1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Checking if all trials have been completed or if 12 reversals have been reached
if (100*(track_trials/trials_number) == 100 || length(save_mean_error_pos) > (12-str2double(get(handles.Errors_PsyDD,'String'))))
    
 %% Calculating the value on the demanding curve y = b/a, where b = 400% (we require 400 the DD threshold to elicit P300 => b = 4) 
    %and a = sqrt((mean(ms))/comparison(ms))
    
  dem_curve_val = 4/(sqrt((mean(save_response(1,save_mean_position))/1000)/(length(stim_comp)/Fs)));  
    text(track_trials/2,max(save_response),['The P300 threshold is: ' num2str(dem_curve_val)])
    
    set(fig_tag,'Visible','on')
grid on
 hold on
    
    line('XData',[1:track_trials],'YData',save_response(1:track_trials))
    
    xlabel('\bfTrial')
    ylabel('\bfDLs')
    %title(['\bfThe average and std are: ' num2str(mean(save_response(1,flag_average + 1:end))) '+/-' num2str(std(save_response(1,flag_average + 1:end)))])
    title(['\bfThe average and std are: ' num2str(mean(save_response(1,save_mean_position))) '+/-' num2str(std(save_response(1,save_mean_position)))])
    
 axis([0 (track_trials + 1) (min(save_response) - 20) (max(save_response) + 20)]) 
 
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 %Saving the results
 saveas(gcf,[Subject_ID '_Staircase_Results.fig'])
 
 psy_dd.scores = save_response;
 psy_dd.mean = mean(save_response(1,save_mean_position));
 psy_dd.std = std(save_response(1,save_mean_position));
 psy_dd.flag_average = flag_average + 1;
 psy_dd.flag = flag_average;
 psy_dd.P300 = mean(save_response(1,save_mean_position)) + round(dem_curve_val);
 psy_dd.Demand_Curve = dem_curve_val;
 psy_dd.mean_pos = save_mean_position;
 psy_dd.error_av = save_mean_error_pos;
 
 save([Subject_ID '_Results.mat'],'psy_dd')
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  
 set(handles.Target_Panel,'Visible','on')
set(handles.Comp_Panel,'Visible','on')
set(handles.TSP_Psy_DD,'Visible','on')
set(handles.SS_Panel,'Visible','on')

     message = 'The teask has been successfully completed';
msgbox(message,'End of the task','warn','replace');

hold off

end

%% Disabling the response buttons to avoid subjects to press them more than one time
set(handles.Stim_I_Psy_DD,'Enable','off')
set(handles.Stim_II_Psy_DD,'Enable','off')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Choose Stim II
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in Stim_II_Psy_DD.
function Stim_II_Psy_DD_Callback(hObject, eventdata, handles)
% hObject    handle to Stim_II_Psy_DD (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global rand_pos_target;
global save_response;
global track_trials;
global current_DLS;
global step_down;
global trials_number;
global stim_target;
global Fs;
global current_step;
global Track_reversals;
global flag_average;
global Subject_ID;
global fig_tag;
global IFC_task;
global stop_flag;
global save_mean_position;
global stim_comp;
global save_mean_error_pos;

%set(handles.Present_Stim_Psy_DD,'BackgroundColor',[0 1 0])
set(handles.Present_Stim_Psy_DD,'Enable','on');

if (rand_pos_target == 2)
    
    save_response(1,track_trials) = current_DLS;
    step_down = step_down + 1;
    
  figure(2000)
 
plot(track_trials,save_response(1,track_trials),'o')

hold on

fig_tag = gcf;
set(fig_tag,'Visible','off')

%grid on
 %hold on
 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Making the target stimulus shorter 
 %Checking if the duration needs to be lowered by 1 step (15ms or 2ms)   
    if (step_down == IFC_task)
        
         %% Checking if the current threshold value should be used for the final average
        if(~isempty(save_mean_error_pos))
            if (stop_flag == 0 && (track_trials - save_mean_error_pos(1,end)) == 3)
                    
save_mean_position = [save_mean_position save_mean_error_pos(1,end) track_trials];
            
            end
        end
        
        current_DLS = current_DLS - current_step;
        step_down = 0;
       t = [0:1/Fs:(length(stim_target) - round((current_step/1000)*Fs))/Fs];
stim_target_temp = str2double(get(handles.Gain_Psy_DD,'String'))*sin(2*pi*str2double(get(handles.CF_Psy_DD,'String'))*t);

stim_target = [];

stim_target = AddTemporalRamps(stim_target_temp,str2double(get(handles.Ramp_Psy_DD,'String'))/1000,Fs,1);

      
    end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Detecting and plotting an error in the discrimination task
else
    
    if (stop_flag == 0)
            
save_mean_error_pos = [save_mean_error_pos track_trials];
            
        end
    
    save_response(1,track_trials) = current_DLS;
    figure(2000)

    plot(track_trials,save_response(1,track_trials),'*','Color','r')

    hold on
    
    fig_tag = gcf;
set(fig_tag,'Visible','off')
    
     %grid on
 %hold on
 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Making the target stimulus longer and counting the reversals
Track_reversals = Track_reversals + 1;
    save_response(1,track_trials) = current_DLS;
    current_DLS = current_DLS + current_step;
    step_down = 0;
     t = [0:1/Fs:(length(stim_target) + round((current_step/1000)*Fs))/Fs];
stim_target_temp = str2double(get(handles.Gain_Psy_DD,'String'))*sin(2*pi*str2double(get(handles.CF_Psy_DD,'String'))*t);

stim_target = [];

stim_target = AddTemporalRamps(stim_target_temp,str2double(get(handles.Ramp_Psy_DD,'String'))/1000,Fs,1);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Checking if all trials have been completed or if 12 reversals have been reached
if (100*(track_trials/trials_number) == 100 || length(save_mean_error_pos) > (12-str2double(get(handles.Errors_PsyDD,'String'))))
   
    %% Calculating the value on the demanding curve y = b/a, where b = 400% (we require 400 the DD threshold to elicit P300 => b = 4) 
    %and a = sqrt((mean(ms))/comparison(ms))
    
  dem_curve_val = 4/(sqrt((mean(save_response(1,save_mean_position))/1000)/(length(stim_comp)/Fs)));  
    text(track_trials/2,max(save_response),['The P300 threshold is: ' num2str(dem_curve_val)])
    
    set(fig_tag,'Visible','on')
grid on
 hold on
    
    line('XData',[1:track_trials],'YData',save_response(1:track_trials))
        
    xlabel('\bfTrial')
    ylabel('\bfDLs (ms)')
    %title(['\bfThe average and std are: ' num2str(mean(save_response(1,flag_average + 1:end))) '+/-' num2str(std(save_response(1,flag_average + 1:end)))])
    title(['\bfThe average and std are: ' num2str(mean(save_response(1,save_mean_position))) '+/-' num2str(std(save_response(1,save_mean_position)))])
    
 axis([0 (track_trials + 1) (min(save_response) - 20) (max(save_response) + 20)]) 
 
 saveas(gcf,[Subject_ID '_Staircase_Results.fig'])
 
 psy_dd.scores = save_response;
 %psy.mean = mean(save_response(1,flag_average + 1:end));
 %psy.std = std(save_response(1,flag_average + 1:end));
 psy_dd.mean = mean(save_response(1,save_mean_position));
 psy_dd.std = std(save_response(1,save_mean_position));
 psy_dd.flag_average = flag_average + 1;
 psy_dd.flag = flag_average;
 psy_dd.P300 = mean(save_response(1,save_mean_position)) + round(dem_curve_val);
 psy_dd.Demand_Curve = dem_curve_val;
 psy_dd.mean_pos = save_mean_position;
 psy_dd.error_av = save_mean_error_pos;
 
 save([Subject_ID '_Results.mat'],'psy_dd')
 
set(handles.Target_Panel,'Visible','on')
set(handles.Comp_Panel,'Visible','on')
set(handles.TSP_Psy_DD,'Visible','on')
set(handles.SS_Panel,'Visible','on')

     message = 'The teask has been successfully completed';
msgbox(message,'End of the task','warn','replace');

hold off

end

%% Disabling the response buttons to avoid subjects to press them more than one time
set(handles.Stim_I_Psy_DD,'Enable','off')
set(handles.Stim_II_Psy_DD,'Enable','off')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Present the stimuli
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in Present_Stim_Psy_DD.
function Present_Stim_Psy_DD_Callback(hObject, eventdata, handles)
% hObject    handle to Present_Stim_Psy_DD (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global rand_pos_target;
global save_response;
global track_trials;
global current_DLS;
global step_down;
global trials_number;
global stim_target;
global stim_comp;
global Fs;
global current_step;
global Track_reversals;
global flag_average;
global stop_flag_intemediate;
global stop_flag;
global Subject_ID;
global IFC_task;
global save_mean_position;
global save_mean_error_pos;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Initializing the variables
if (isempty(track_trials))
    
set(handles.Target_Panel,'Visible','off')
set(handles.Comp_Panel,'Visible','off')
set(handles.TSP_Psy_DD,'Visible','off')
set(handles.SS_Panel,'Visible','off')


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Creating the two stimuli
Fs = str2double(get(handles.SF_Stimuli_Psy_DD,'String'));

%% Initializing the target stimulus
tt = [0:1/Fs:str2double(get(handles.Duration_Target_Psy_DD,'String'))/1000];
stim_target_temp = str2double(get(handles.Gain_Psy_DD,'String'))*sin(2*pi*str2double(get(handles.CF_Psy_DD,'String'))*tt);
stim_target = AddTemporalRamps(stim_target_temp,str2double(get(handles.Ramp_Psy_DD,'String'))/1000,Fs,1);

%% Initializing the comparison stimulus
tc = [0:1/Fs:str2double(get(handles.Duration_Comp_Psy_DD,'String'))/1000];
stim_comp_temp = str2double(get(handles.Gain_Psy_DD,'String'))*sin(2*pi*str2double(get(handles.CF_Psy_DD,'String'))*tc);
stim_comp = AddTemporalRamps(stim_comp_temp,str2double(get(handles.Ramp_Psy_DD,'String'))/1000,Fs,1);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Subject_ID = get(handles.Subject_ID_Psy_DD,'String');

save_mean_position = [];    %Vector where to save the position of the DLs used to calcualte the final average and std
save_mean_error_pos = [];   %Vector where to save the position of the reversals used to calcualte the final average and std

IFC_task = 3;   %Number of steps to have "1-down"

stop_flag_intemediate = 1; %variable used to check when a change in step from 30 to 15ms should be applied
stop_flag = 1;  %variable used to check when a change in step from 15 to 2ms should be applied
flag_average = 0;   %Indicate the position where the calculation of the average should start

trials_number = str2double(get(handles.Trials_Exp_Psy_DD,'String'));    %Number of trials;

save_response = zeros(1,trials_number);     %Vector used to save the scores for each trial

current_DLS = 1000*(length(stim_target) - length(stim_comp))/Fs;    %Starting DLS in ms
save_response(1,1) = current_DLS;       %This is the starting point;

current_step = str2double(get(handles.Start_SS_PsyDD,'String'));          %Starting step in "ms"
step_down = 0;              %Tracking the correct responses
track_trials = 0;       %Track the number of trials
Track_reversals = 0;    %Track the number of reversals

end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Updating the step to 15ms after the first 2 reversals (or errors)
if (Track_reversals == str2double(get(handles.Errors_PsyDD,'String'))/2 && stop_flag_intemediate == 1)
   
    temp_current_step = current_step;
    current_DLS = current_DLS - current_step;
    current_step = str2double(get(handles.Start_SS_PsyDD,'String'))/2;
    current_DLS = current_DLS + current_step;
    
    t = [0:1/Fs:(length(stim_target) - round((temp_current_step/1000)*Fs) + round((current_step/1000)*Fs))/Fs];
stim_target_temp = str2double(get(handles.Gain_Psy_DD,'String'))*sin(2*pi*str2double(get(handles.CF_Psy_DD,'String'))*t);

stim_target = [];

stim_target = AddTemporalRamps(stim_target_temp,str2double(get(handles.Ramp_Psy_DD,'String'))/1000,Fs,1);

stop_flag_intemediate = 0;

end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Updating the step to 2ms, if 4 reversals (or errors) have been reached
if (Track_reversals == str2double(get(handles.Errors_PsyDD,'String')) && stop_flag == 1)
   
    temp_current_step = current_step;
    current_DLS = current_DLS - current_step;
    current_step = str2double(get(handles.Av_SS_PsyDD,'String'));
    current_DLS = current_DLS + current_step;
    
    t = [0:1/Fs:(length(stim_target) - round((temp_current_step/1000)*Fs) + round((current_step/1000)*Fs))/Fs];
stim_target_temp = str2double(get(handles.Gain_Psy_DD,'String'))*sin(2*pi*str2double(get(handles.CF_Psy_DD,'String'))*t);

stim_target = [];

stim_target = AddTemporalRamps(stim_target_temp,str2double(get(handles.Ramp_Psy_DD,'String'))/1000,Fs,1);
    
    flag_average = track_trials;
    stop_flag = 0;
    
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Presenting the stimuli in random positions

%Enabling the response buttons 
set(handles.Stim_I_Psy_DD,'Enable','on')
set(handles.Stim_II_Psy_DD,'Enable','on')

track_trials = count_trials_DD(track_trials);

    rand_pos_target = randi(2);
    
    set(handles.Present_Stim_Psy_DD,'Enable','off')
    
switch rand_pos_target
    
    case 1
set(handles.Stim_I_Psy_DD,'BackgroundColor',[0 1 0])
    sound(stim_comp,Fs) 
set(handles.Stim_I_Psy_DD,'BackgroundColor',[1 1 0])

pause(0.5)

set(handles.Stim_II_Psy_DD,'BackgroundColor',[0 1 0])
sound(stim_target,Fs)
set(handles.Stim_II_Psy_DD,'BackgroundColor',[1 1 0])


    case 2

set(handles.Stim_I_Psy_DD,'BackgroundColor',[0 1 0])
sound(stim_target,Fs)
set(handles.Stim_I_Psy_DD,'BackgroundColor',[1 1 0])

pause(0.5)

set(handles.Stim_II_Psy_DD,'BackgroundColor',[0 1 0])
sound(stim_comp,Fs) 
set(handles.Stim_II_Psy_DD,'BackgroundColor',[1 1 0])


end

set(handles.Track_Numb_Psy,'String',track_trials);
set(handles.Perc_Completed_Psy,'String',100*(track_trials/trials_number));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Reset the number of trials to "0"
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in Reset_Trials_Psy_DD.
function Reset_Trials_Psy_DD_Callback(hObject, eventdata, handles)
% hObject    handle to Reset_Trials_Psy_DD (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global track_trials;

track_trials = [];

set(handles.Track_Numb_Psy,'String','0');
set(handles.Perc_Completed_Psy,'String','0');
set(handles.Present_Stim_Psy_DD,'Enable','on');

 try
    close(2000)

    catch
    
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Display the # of trials
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Track_Numb_Psy_Callback(hObject, eventdata, handles)
% hObject    handle to Track_Numb_Psy (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Track_Numb_Psy as text
%        str2double(get(hObject,'String')) returns contents of Track_Numb_Psy as a double


% --- Executes during object creation, after setting all properties.
function Track_Numb_Psy_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Track_Numb_Psy (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Percentage completed of trials
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Perc_Completed_Psy_Callback(hObject, eventdata, handles)
% hObject    handle to Perc_Completed_Psy (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Perc_Completed_Psy as text
%        str2double(get(hObject,'String')) returns contents of Perc_Completed_Psy as a double


% --- Executes during object creation, after setting all properties.
function Perc_Completed_Psy_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Perc_Completed_Psy (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Trials Experiment
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Trials_Exp_Psy_DD_Callback(hObject, eventdata, handles)
% hObject    handle to Trials_Exp_Psy_DD (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Trials_Exp_Psy_DD as text
%        str2double(get(hObject,'String')) returns contents of Trials_Exp_Psy_DD as a double


% --- Executes during object creation, after setting all properties.
function Trials_Exp_Psy_DD_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Trials_Exp_Psy_DD (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Subject ID
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Subject_ID_Psy_DD_Callback(hObject, eventdata, handles)
% hObject    handle to Subject_ID_Psy_DD (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Subject_ID_Psy_DD as text
%        str2double(get(hObject,'String')) returns contents of Subject_ID_Psy_DD as a double


% --- Executes during object creation, after setting all properties.
function Subject_ID_Psy_DD_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Subject_ID_Psy_DD (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Select the stimuli
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in Select_Stimuli_DD.
function Select_Stimuli_DD_Callback(hObject, eventdata, handles)
% hObject    handle to Select_Stimuli_DD (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.Target_Panel,'Visible','on')
set(handles.Comp_Panel,'Visible','on')
set(handles.TSP_Psy_DD,'Visible','on')
set(handles.SS_Panel,'Visible','on')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Gain of the target stimulus
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Gain_Psy_DD_Callback(hObject, eventdata, handles)
% hObject    handle to Gain_Psy_DD (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Gain_Psy_DD as text
%        str2double(get(hObject,'String')) returns contents of Gain_Psy_DD as a double


% --- Executes during object creation, after setting all properties.
function Gain_Psy_DD_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Gain_Psy_DD (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Ramp (ms) of the target stimulus
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Ramp_Psy_DD_Callback(hObject, eventdata, handles)
% hObject    handle to Ramp_Psy_DD (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Ramp_Psy_DD as text
%        str2double(get(hObject,'String')) returns contents of Ramp_Psy_DD as a double


% --- Executes during object creation, after setting all properties.
function Ramp_Psy_DD_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Ramp_Psy_DD (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Carrier Frequency of the target stimulus
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function CF_Psy_DD_Callback(hObject, eventdata, handles)
% hObject    handle to CF_Psy_DD (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of CF_Psy_DD as text
%        str2double(get(hObject,'String')) returns contents of CF_Psy_DD as a double


% --- Executes during object creation, after setting all properties.
function CF_Psy_DD_CreateFcn(hObject, eventdata, handles)
% hObject    handle to CF_Psy_DD (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Starting step size
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Start_SS_PsyDD_Callback(hObject, eventdata, handles)
% hObject    handle to Start_SS_PsyDD (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Start_SS_PsyDD as text
%        str2double(get(hObject,'String')) returns contents of Start_SS_PsyDD as a double


% --- Executes during object creation, after setting all properties.
function Start_SS_PsyDD_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Start_SS_PsyDD (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Step size for the average
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Av_SS_PsyDD_Callback(hObject, eventdata, handles)
% hObject    handle to Av_SS_PsyDD (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Av_SS_PsyDD as text
%        str2double(get(hObject,'String')) returns contents of Av_SS_PsyDD as a double


% --- Executes during object creation, after setting all properties.
function Av_SS_PsyDD_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Av_SS_PsyDD (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Errors allowed before changing step size
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Errors_PsyDD_Callback(hObject, eventdata, handles)
% hObject    handle to Errors_PsyDD (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Errors_PsyDD as text
%        str2double(get(hObject,'String')) returns contents of Errors_PsyDD as a double


% --- Executes during object creation, after setting all properties.
function Errors_PsyDD_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Errors_PsyDD (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Initial duration of the target stimulus
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Duration_Target_Psy_DD_Callback(hObject, eventdata, handles)
% hObject    handle to Duration_Target_Psy_DD (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Duration_Target_Psy_DD as text
%        str2double(get(hObject,'String')) returns contents of Duration_Target_Psy_DD as a double


% --- Executes during object creation, after setting all properties.
function Duration_Target_Psy_DD_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Duration_Target_Psy_DD (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Sampling frequency of the stimuli
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function SF_Stimuli_Psy_DD_Callback(hObject, eventdata, handles)
% hObject    handle to SF_Stimuli_Psy_DD (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of SF_Stimuli_Psy_DD as text
%        str2double(get(hObject,'String')) returns contents of SF_Stimuli_Psy_DD as a double


% --- Executes during object creation, after setting all properties.
function SF_Stimuli_Psy_DD_CreateFcn(hObject, eventdata, handles)
% hObject    handle to SF_Stimuli_Psy_DD (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Initial duration of the comparison stimulus
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Duration_Comp_Psy_DD_Callback(hObject, eventdata, handles)
% hObject    handle to Duration_Comp_Psy_DD (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Duration_Comp_Psy_DD as text
%        str2double(get(hObject,'String')) returns contents of Duration_Comp_Psy_DD as a double


% --- Executes during object creation, after setting all properties.
function Duration_Comp_Psy_DD_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Duration_Comp_Psy_DD (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
