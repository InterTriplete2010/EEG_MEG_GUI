function [temp_Noise_boot temp_sig_boot] = bootstrap_rms_values(NoiseVec,SigVec,sweeps_number,bottstrap_replace);

%% Bootstrap the data using the "sampling with replacement" method
temp_Noise_boot = [];
temp_sig_boot = [];

if bottstrap_replace == 1
   
temp_Noise_boot = datasample(NoiseVec',sweeps_number,2,'Replace',true)';

temp_sig_boot = datasample(SigVec',sweeps_number,2,'Replace',true)';

else
   
     temp_Noise_boot = datasample(NoiseVec',sweeps_number,2,'Replace',false)';
    
     temp_sig_boot = datasample(SigVec',sweeps_number,2,'Replace',false)';
end

