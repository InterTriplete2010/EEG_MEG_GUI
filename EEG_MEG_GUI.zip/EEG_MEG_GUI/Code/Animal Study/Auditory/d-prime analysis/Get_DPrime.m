function Get_DPrime(Signal_d_prime_Cortical_selected,Signal_d_prime_Cortical_directory,Noise_d_prime_Cortical_selected,Noise_d_prime_Cortical_directory,...
    chan_selected,chan_selected_name,order_filt,high_pass_filt,low_pass_filt,line_noise,av_sweeps_d_prime,start_time_d_prime,end_time_d_prime,...
    run_boost,boost_number,remove_first_sweep_check,peak_to_peak_d_prime,p1_d_prime_val,n1_d_prime_val,bottstrap_replace,p1_prime_d_prime_val,n1_prime_d_prime_val)

% GetDPrime
% Given a vector of spike counts on noise trials and on
% signal trials, return dprime.
% 
% Editted 4/23/2013 to add the 1/(2N) rule for dealing with probabilities
%   of 1 or 0. Given N trials, replace 0 by 1/(2N) and 1 by 1-(1/2N). Take
%   N as the average length of NoiseVec and SigVec
%
% USAGE dp= getdprime(NoiseVec,SigVec)

%Calculate the ceiling value for the set of parameters chosen
ceiling_par = 1 - 1/(2*boost_number); %This limit is used to cope with the 100% and 0% problem that exists when you calculate the z-transform of the ROC curve
dp_ceiling = P2_DPrime(ceiling_par);

fig_roc = figure;
results_d_prime(1,1) = {'File'};
results_d_prime(1,2) = {'D-prime'};

results_d_prime(1,3) = {'Max value with p >= 0.99'};
results_d_prime(2,3) = {dp_ceiling};

results_d_prime(1,4) = {'Min value with p <= 0.01'};
results_d_prime(2,4) = {-dp_ceiling};

results_d_prime(1,5) = {'60 Hz Filter'};
results_d_prime(1,6) = {'Band Pass Filter (Order,High,Low)'};
results_d_prime(1,7) = {'Boostraping'};

results_d_prime(1,10) = {'D-prime (second Window)'};

if peak_to_peak_d_prime == 1
   
    results_d_prime(1,8) = {'Time P1 (ms)'};
results_d_prime(1,9) = {'Time N1 (ms)'};

    
    results_d_prime(2,8) = {num2str(p1_d_prime_val)};
results_d_prime(2,9) = {num2str(n1_d_prime_val)};

results_d_prime(1,11) = {'Time P1_Prime (ms)'};
results_d_prime(1,12) = {'Time N1_Prime (ms)'};

    
    results_d_prime(2,11) = {num2str(p1_prime_d_prime_val)};
results_d_prime(2,12) = {num2str(n1_prime_d_prime_val)};
    
else
    
    results_d_prime(1,8) = {'Time Start (ms)'};
results_d_prime(1,9) = {'Time End (ms)'};

results_d_prime(2,8) = {start_time_d_prime};
results_d_prime(2,9) = {end_time_d_prime};

end

results_d_prime(1,13) = {'Av Sweeps'};
results_d_prime(2,13) = {av_sweeps_d_prime};

results_d_prime(1,14) = {'Remove First Sweep'};

if remove_first_sweep_check == 1

results_d_prime(2,14) = {'Yes'};

else
   
  results_d_prime(2,14) = {'No'};  
    
end


results_d_prime(1,15) = {'Noise_File'};
results_d_prime(2,15) = {Noise_d_prime_Cortical_selected};
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Upload and filter the Noise data
cd(Noise_d_prime_Cortical_directory)
noise_file = [];
noise_data = [];
noise_file = load(Noise_d_prime_Cortical_selected);
noise_data = squeeze(noise_file.ind_sweeps(chan_selected,:,:));
time_d = noise_file.time_av;
sf = noise_file.sampl_freq;
%results_d_prime(2,12) = {Noise_d_prime_Cortical_selected};

%% Time av (samples)
samples_av_start = find(time_d >= start_time_d_prime,1,'first');
samples_av_end = find(time_d >= end_time_d_prime,1,'first');

build_filters = 1;

if build_filters == 1
  
%Filtering out the 60 Hz
  if (line_noise == 1)
      
  fo = 60;  q = 10; bw = (fo/(sf/2))/q;
  [bn,an] = iircomb(round(sf/fo),bw,'notch');
  
  results_d_prime(2,5) = {'Yes'};
  
  else
  
      results_d_prime(2,5) = {'No'};
  
    end
   
  if build_filters == 1
    
  [b1,a1] = butter(order_filt,[high_pass_filt low_pass_filt]/(sf/2)); 
        
  check_stability(b1,a1);
  pause(2)
  close(gcf)
  
  results_d_prime(2,6) = {num2str([order_filt high_pass_filt low_pass_filt])}; 
  
  end
  
  build_filters = 0;
  
  end

unfold_data = [];
  for ll = 1:size(noise_data,1)
      
      unfold_data = [unfold_data noise_data(ll,:)];
      
  end
  
  if line_noise == 1
  
  temp_noise_data_60Hz = filtfilt(bn,an,unfold_data);
  
  else
      
    temp_noise_data_60Hz = unfold_data;  
  
  end
  
   %Band-passing the data
  filt_data_noise = filtfilt(b1,a1,temp_noise_data_60Hz);  
  
%Refolding the filtered data
  sweep_N = size(noise_data,1);
  sample_N = size(noise_data,2);
  NoiseVec_all = [];
  
  start_sweep = 1;
  end_sweep = sample_N;
  
  for mm = 1:sweep_N
  
      temp_data_filtered = [];
     temp_data_filtered = filt_data_noise(1,start_sweep:end_sweep);
     
     NoiseVec_all = [NoiseVec_all;temp_data_filtered];
     
     start_sweep = start_sweep + sample_N;
  end_sweep = end_sweep + sample_N;
      
  end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  

save_dp = [];
save_dp_prime = [];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Upload and filter the responses. At each interaction, check
%that the uploaded file is different from the noise file
cd(Signal_d_prime_Cortical_directory)

dir_files = dir;

[files_number] = size(dir_files,1);

track_subjects = 0;
save_subject_plot = [];
save_names_legend = [];

for ii = 3:files_number
    
    matrix_file = dir_files(ii).name;
    
    if (strcmp(matrix_file(1,end-2:end),'mat') == 1 && strcmp(matrix_file,Noise_d_prime_Cortical_selected) == 0) 
        
        temp_signal_data_60Hz = [];
        filt_data_signal = []; 
        
        track_subjects = track_subjects + 1;
        
        save_subject_plot = [save_subject_plot;track_subjects];
        
  matrix_file = dir_files(ii).name;  
  
  save_names_legend = [save_names_legend;{matrix_file(1:end-4)}];
  
  temp_sign = [];
  SigVec_temp = [];
  
  temp_sign = load(matrix_file);
  
SigVec_temp = squeeze(temp_sign.ind_sweeps(chan_selected,:,:)); 

%% Upload and filter the Signals
unfold_data = [];
  for ll = 1:size(SigVec_temp,1)
      
      unfold_data = [unfold_data SigVec_temp(ll,:)];
      
  end

if line_noise == 1
  
  temp_signal_data_60Hz = filtfilt(bn,an,unfold_data);
  
  else
      
    temp_signal_data_60Hz = unfold_data;  
  
  end
  
   %Band-passing the data
     filt_data_signal = filtfilt(b1,a1,temp_signal_data_60Hz);  
  
%Refolding the filtered data
  sweep_N = size(SigVec_temp,1);
  sample_N = size(SigVec_temp,2);
  SigVec_all = [];
  
  start_sweep = 1;
  end_sweep = sample_N;
    
  for mm = 1:sweep_N
  
      temp_data_filtered = [];
     temp_data_filtered = filt_data_signal(1,start_sweep:end_sweep);
     
     SigVec_all = [SigVec_all;temp_data_filtered];
     
     start_sweep = start_sweep + sample_N;
  end_sweep = end_sweep + sample_N;
      
  end

%Average groups of "N" sweeps
if remove_first_sweep_check == 1

    SigVec_all(1,:) = [];
            
end

if remove_first_sweep_check == 1 && track_subjects == 1
   
    NoiseVec_all(1,:) = [];
    
end

av_sign = [];
av_noise = [];

if run_boost == 1;
%% Bootstrap the RMS values of selected number of "av_sweeps_d_prime" sweeps a "boost_number" number of times;

results_d_prime(2,7) = {boost_number};

for pp = 1:boost_number

[temp_Noise_boot temp_sig_boot] = bootstrap_rms_values(NoiseVec_all,SigVec_all,av_sweeps_d_prime,bottstrap_replace);

av_sign = [av_sign;mean(temp_sig_boot)];
av_noise = [av_noise;mean(temp_Noise_boot)];

end

else
    
    av_sign = SigVec_all;
    av_noise = NoiseVec_all;
    
    results_d_prime(2,7) = {0};

end


%% Creating the Noise and Signal vectors by calculating the RMS value for each sweep collected
NoiseVec = [];
SigVec = [];

NoiseVec_prime = [];
SigVec_prime = [];

if peak_to_peak_d_prime == 1 
   
    p1_start = find(time_d >= p1_d_prime_val(1),1,'first');
p1_end = find(time_d >= p1_d_prime_val(2),1,'first');

n1_start = find(time_d >= n1_d_prime_val(1),1,'first');
n1_end = find(time_d >= n1_d_prime_val(2),1,'first');

p1_prime_start = find(time_d >= p1_prime_d_prime_val(1),1,'first');
p1_prime_end = find(time_d >= p1_prime_d_prime_val(2),1,'first');

n1_prime_start = find(time_d >= n1_prime_d_prime_val(1),1,'first');
n1_prime_end = find(time_d >= n1_prime_d_prime_val(2),1,'first');

end

for kk = 1:size(av_sign,1)
    
    if peak_to_peak_d_prime == 1    %Select the type of analysis: peak-to-peak or RMS
        
        NoiseVec(kk,1) = max(av_noise(kk,p1_start:p1_end)) - min(av_noise(kk,n1_start:n1_end));
     SigVec(kk,1) = max(av_sign(kk,p1_start:p1_end)) - min(av_sign(kk,n1_start:n1_end));
     
     NoiseVec_prime(kk,1) = max(av_noise(kk,p1_prime_start:p1_prime_end)) - min(av_noise(kk,n1_prime_start:n1_prime_end));
     SigVec_prime(kk,1) = max(av_sign(kk,p1_prime_start:p1_prime_end)) - min(av_sign(kk,n1_prime_start:n1_prime_end));
        
    else
    
NoiseVec(kk,1) = sqrt(mean(av_noise(kk,samples_av_start:samples_av_end).^2));
     SigVec(kk,1) = sqrt(mean(av_sign(kk,samples_av_start:samples_av_end).^2));

    end
     
end



if run_boost == 0
    
CountList= unique([NoiseVec(:);SigVec(:)]);
CountList= flipud(CountList);

if peak_to_peak_d_prime == 1

CountList_prime = unique([NoiseVec_prime(:);SigVec_prime(:)]);
CountList_prime = flipud(CountList_prime);

end

else
    
   CountList = sort([NoiseVec(:);SigVec(:)],'descend');
   
   if peak_to_peak_d_prime == 1
   
CountList_prime = sort([NoiseVec_prime(:);SigVec_prime(:)],'descend');

   end

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Calculating the probability for the first time window
NCnt= length(CountList);
mySigVec= zeros(NCnt+2,1);
myNoiseVec= zeros(NCnt+2,1);

for iCnt=1:NCnt,
    myNoiseVec(iCnt)= sum(NoiseVec>CountList(iCnt));
    mySigVec(iCnt)= sum(SigVec>CountList(iCnt));
end

%Converting the values into probability
myNoiseVec = myNoiseVec/length(NoiseVec);
mySigVec = mySigVec/length(SigVec);

%% Plotting the ROC curve for each condition tested
figure(fig_roc.Number)
hold on
plot(mySigVec(1:end-2),myNoiseVec(1:end-2))
xlabel('\bfSignal')
ylabel('\bfNoise')

myNoiseVec(iCnt+1)= 1;    % complete the polygon
mySigVec(iCnt+1)= 1;
myNoiseVec(iCnt+2)= 1;
mySigVec(iCnt+2)= 0;
Prob= polyarea(myNoiseVec,mySigVec);
N= (length(NoiseVec)+length(SigVec))/2;

MyLim= 1/(2*N); %This limit is used to cope with the 100% and 0% problem that exists when you calculate the z-transform of the ROC curve

Prob= min(Prob,1-MyLim);
Prob= max(Prob,MyLim);

dp= P2_DPrime(Prob);

save_dp = [save_dp;dp];

results_d_prime(track_subjects + 1,1) = {matrix_file};
results_d_prime(track_subjects + 1,2) = {dp};
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if peak_to_peak_d_prime == 1
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Calculating the probability for the second time window
NCnt_prime= length(CountList_prime);
mySigVec_prime = zeros(NCnt_prime+2,1);
myNoiseVec_prime = zeros(NCnt_prime+2,1);

for iCnt_prime=1:NCnt_prime,
    myNoiseVec_prime(iCnt_prime)= sum(NoiseVec_prime>CountList_prime(iCnt_prime));
    mySigVec_prime(iCnt_prime)= sum(SigVec_prime>CountList_prime(iCnt_prime));
end

%Converting the values into probability
myNoiseVec_prime = myNoiseVec_prime/length(NoiseVec_prime);
mySigVec_prime = mySigVec_prime/length(SigVec_prime);

%% Plotting the ROC curve for each condition tested
figure(fig_roc.Number + 100)
hold on
plot(mySigVec_prime(1:end-2),myNoiseVec_prime(1:end-2))
xlabel('\bfSignal')
ylabel('\bfNoise')

myNoiseVec_prime(iCnt_prime+1)= 1;    % complete the polygon
mySigVec_prime(iCnt_prime+1)= 1;
myNoiseVec_prime(iCnt_prime+2)= 1;
mySigVec_prime(iCnt_prime+2)= 0;
Prob_prime= polyarea(myNoiseVec_prime,mySigVec_prime);
N_prime = (length(NoiseVec_prime)+length(SigVec_prime))/2;

MyLim_prime= 1/(2*N_prime); %This limit is used to cope with the 100% and 0% problem that exists when you calculate the z-transform of the ROC curve

Prob_prime= min(Prob_prime,1-MyLim_prime);
Prob_prime= max(Prob_prime,MyLim_prime);

dp_prime= P2_DPrime(Prob_prime);

save_dp_prime = [save_dp_prime;dp_prime];

results_d_prime(track_subjects + 1,10) = {dp_prime};
    end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


end

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Plotting the d-prime
figure
plot(save_dp,'-o')
ylabel('\bfD-prime')
set(gca,'TickLabelInterpreter','none')
set(gca,'XTick',[1:length(save_names_legend)])
set(gca,'XTickLabel',save_names_legend)

if peak_to_peak_d_prime == 1

   saveas(gcf,['Peak_to_Peak_D_Prime_' num2str(p1_d_prime_val(1)) '_' num2str(p1_d_prime_val(2)) '_' num2str(n1_d_prime_val(1)) '_' num2str(n1_d_prime_val(2)) '_' num2str(chan_selected_name) '.fig']) 
xlswrite (['Peak_to_Peak_D_Prime_' num2str(p1_d_prime_val(1)) '_' num2str(p1_d_prime_val(2)) '_' num2str(n1_d_prime_val(1)) '_' num2str(n1_d_prime_val(2)) '_' num2str(chan_selected_name) '.xls'],results_d_prime) 
    
else
    
    saveas(gcf,['RMS_D_Prime_' num2str(start_time_d_prime) '_' num2str(end_time_d_prime) '_' num2str(chan_selected_name) '.fig']) 
xlswrite (['RMS_D_Prime_' num2str(start_time_d_prime) '_' num2str(end_time_d_prime) '_' num2str(chan_selected_name) '.xls'],results_d_prime)

end

figure(fig_roc.Number)
legend(save_names_legend,'Interpreter','none');
hold off
xlabel('\bfSignal');
ylabel('\bfNoise');

if peak_to_peak_d_prime == 1

    saveas(gcf,['RMS_ROC_' num2str(p1_d_prime_val(1)) '_' num2str(p1_d_prime_val(2)) '_' num2str(n1_d_prime_val(1)) '_' num2str(n1_d_prime_val(2)) '_' num2str(chan_selected_name) '.fig']) 
    
else
    
saveas(gcf,['RMS_ROC_' num2str(start_time_d_prime) '_' num2str(end_time_d_prime) '_' num2str(chan_selected_name) '.fig']) 

end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if peak_to_peak_d_prime == 1
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Plotting the d-prime for the second time window
figure
plot(save_dp_prime,'-o')
ylabel('\bfD-prime')
set(gca,'TickLabelInterpreter','none')
set(gca,'XTick',[1:length(save_names_legend)])
set(gca,'XTickLabel',save_names_legend)

if peak_to_peak_d_prime == 1

   saveas(gcf,['Peak_to_Peak_D_Prime_' num2str(p1_prime_d_prime_val(1)) '_' num2str(p1_prime_d_prime_val(2)) '_' num2str(n1_prime_d_prime_val(1)) '_' num2str(n1_prime_d_prime_val(2)) '_' num2str(chan_selected_name) '.fig']) 
xlswrite (['Peak_to_Peak_D_Prime_' num2str(p1_prime_d_prime_val(1)) '_' num2str(p1_prime_d_prime_val(2)) '_' num2str(n1_prime_d_prime_val(1)) '_' num2str(n1_prime_d_prime_val(2)) '_' num2str(chan_selected_name) '.xls'],results_d_prime) 
    
else
    
    saveas(gcf,['RMS_D_Prime_' num2str(start_time_d_prime) '_' num2str(end_time_d_prime) '_' num2str(chan_selected_name) '.fig']) 
xlswrite (['RMS_D_Prime_' num2str(start_time_d_prime) '_' num2str(end_time_d_prime) '_' num2str(chan_selected_name) '.xls'],results_d_prime)

end

figure(fig_roc.Number + 100)
legend(save_names_legend,'Interpreter','none');
hold off
xlabel('\bfSignal');
ylabel('\bfNoise');

if peak_to_peak_d_prime == 1

    saveas(gcf,['RMS_ROC_' num2str(p1_prime_d_prime_val(1)) '_' num2str(p1_prime_d_prime_val(2)) '_' num2str(n1_prime_d_prime_val(1)) '_' num2str(n1_prime_d_prime_val(2)) '_' num2str(chan_selected_name) '.fig']) 
    
else
    
saveas(gcf,['RMS_ROC_' num2str(start_time_d_prime) '_' num2str(end_time_d_prime) '_' num2str(chan_selected_name) '.fig']) 

end
   
    
    
end



message = 'D-prime has been calculated and figures/files have been saved';

        msgbox(message,'End of the calculation','warn');
