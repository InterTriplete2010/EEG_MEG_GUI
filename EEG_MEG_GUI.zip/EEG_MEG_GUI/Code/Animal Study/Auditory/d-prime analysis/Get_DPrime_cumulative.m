function Get_DPrime_cumulative(Signal_d_prime_Cortical_selected,Signal_d_prime_Cortical_directory,Noise_d_prime_Cortical_selected,Noise_d_prime_Cortical_directory,...
    chan_selected,chan_selected_name,order_filt,high_pass_filt,low_pass_filt,line_noise,av_sweeps_d_prime,start_time_d_prime,end_time_d_prime,...
    run_boost,boost_number,remove_first_sweep_check,peak_to_peak_d_prime,p1_d_prime_val,n1_d_prime_val,bottstrap_replace) 

% GetDPrime
% Given a vector of spike counts on noise trials and on
% signal trials, return dprime.
% 
% Editted 4/23/2013 to add the 1/(2N) rule for dealing with probabilities
%   of 1 or 0. Given N trials, replace 0 by 1/(2N) and 1 by 1-(1/2N). Take
%   N as the average length of NoiseVec and SigVec
%
% USAGE dp= getdprime(NoiseVec,SigVec)


fig_roc = figure;
results_d_prime(1,1) = {'File'};
results_d_prime(1,2) = {'D-prime'};

results_d_prime(1,3) = {'Max value with p >= 0.99'};
results_d_prime(2,3) = {3.29};

results_d_prime(1,4) = {'Min value with p <= 0.01'};
results_d_prime(2,4) = {-3.29};

results_d_prime(1,5) = {'60 Hz Filter'};
results_d_prime(1,6) = {'Band Pass Filter (Order,High,Low)'};
results_d_prime(1,7) = {'Boostraping'};

if peak_to_peak_d_prime == 1
   
    results_d_prime(1,8) = {'Time P1 (ms)'};
results_d_prime(1,9) = {'Time N1 (ms)'};

    
    results_d_prime(2,8) = {num2str(p1_d_prime_val)};
results_d_prime(2,9) = {num2str(n1_d_prime_val)};
    
else
    
    results_d_prime(1,8) = {'Time Start (ms)'};
results_d_prime(1,9) = {'Time End (ms)'};

results_d_prime(2,8) = {start_time_d_prime};
results_d_prime(2,9) = {end_time_d_prime};

end

results_d_prime(1,10) = {'Av Sweeps'};
results_d_prime(2,10) = {av_sweeps_d_prime};

results_d_prime(1,11) = {'Remove First Sweep'};

if remove_first_sweep_check == 1

results_d_prime(2,11) = {'Yes'};

else
   
  results_d_prime(2,11) = {'No'};  
    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Upload one of the BDF files in the forlder to extract time and frequency information
cd(Noise_d_prime_Cortical_directory)
noise_file = load(Noise_d_prime_Cortical_selected);
time_d = noise_file.time_av;
sf = noise_file.sampl_freq;

%% Time av (samples)
samples_av_start = find(start_time_d_prime >= time_d,1,'first');
samples_av_end = find(end_time_d_prime <= time_d,1,'first');

build_filters = 1;

if build_filters == 1
  
%Filtering out the 60 Hz
  if (line_noise == 1)
      
  fo = 60;  q = 10; bw = (fo/(sf/2))/q;
  [bn,an] = iircomb(round(sf/fo),bw,'notch');
  
  results_d_prime(2,5) = {'Yes'};
  
  else
  
      results_d_prime(2,5) = {'No'};
  
    end
   
  if build_filters == 1
    
  [b1,a1] = butter(order_filt,[high_pass_filt low_pass_filt]/(sf/2)); 
        
  check_stability(b1,a1);
  pause(2)
  close(gcf)
  
  results_d_prime(2,6) = {num2str([order_filt high_pass_filt low_pass_filt])}; 
  
  end
  
  build_filters = 0;
  
  end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  

save_dp = [];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Upload and filter the responses. At each interaction, check
%that the uploaded file is different from the noise file
cd(Signal_d_prime_Cortical_directory)

dir_files = dir;

[files_number] = size(dir_files,1);

track_subjects = 0;
save_subject_plot = [];
save_names_legend = [];

save_temp_names = [];
for oo = 3:files_number
    
    matrix_file = dir_files(oo).name;
    
    if (strcmp(matrix_file(1,end-2:end),'mat') == 1) 
   
        save_temp_names = [save_temp_names;{matrix_file}];
        
    end
    
end

for ii = 1:size(save_temp_names,1)-1

        temp_signal_data_60Hz = [];
        filt_data_signal = []; 
        
        track_subjects = track_subjects + 1;
        
        save_subject_plot = [save_subject_plot;track_subjects];
        
  %matrix_file = [save_temp_names(ii,1:end-4) '_' save_temp_names(ii + 1,1:end-4)];  
  matrix_file = {[cell2mat(save_temp_names(ii,:)) '_' cell2mat(save_temp_names(ii + 1,:))]};  
  save_names_legend = [save_names_legend;matrix_file];
  matrix_file_load = [];
  matrix_file_load = [save_temp_names(ii,:);save_temp_names(ii + 1,:)];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
%% Upload and filter the Signals
  temp_noise_data = [];
  noise_data = [];
  
  temp_noise_data = load(cell2mat(matrix_file_load(1,:)));
  
noise_data = squeeze(temp_noise_data.ind_sweeps(chan_selected,:,:)); 


unfold_data = [];
  for ll = 1:size(noise_data,1)
      
      unfold_data = [unfold_data noise_data(ll,:)];
      
  end
  
  if line_noise == 1
  
  temp_noise_data_60Hz = filtfilt(bn,an,unfold_data);
  
  else
      
    temp_noise_data_60Hz = unfold_data;  
  
  end
  
   %Band-passing the data
  filt_data_noise = filtfilt(b1,a1,temp_noise_data_60Hz);  
  
%Refolding the filtered data
  sweep_N = size(noise_data,1);
  sample_N = size(noise_data,2);
  NoiseVec_all = [];
  
  start_sweep = 1;
  end_sweep = sample_N;
  
  for mm = 1:sweep_N
  
      temp_data_filtered = [];
     temp_data_filtered = filt_data_noise(1,start_sweep:end_sweep);
     
     NoiseVec_all = [NoiseVec_all;temp_data_filtered];
     
     start_sweep = start_sweep + sample_N;
  end_sweep = end_sweep + sample_N;
      
  end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   
  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
%% Upload and filter the Signals
  temp_sign = [];
  SigVec_temp = [];
  
  temp_sign = load(cell2mat(matrix_file_load(2,:)));
  
SigVec_temp = squeeze(temp_sign.ind_sweeps(chan_selected,:,:)); 


unfold_data = [];
  for ll = 1:size(SigVec_temp,1)
      
      unfold_data = [unfold_data SigVec_temp(ll,:)];
      
  end

if line_noise == 1
  
  temp_signal_data_60Hz = filtfilt(bn,an,unfold_data);
  
  else
      
    temp_signal_data_60Hz = unfold_data;  
  
  end
  
   %Band-passing the data
     filt_data_signal = filtfilt(b1,a1,temp_signal_data_60Hz);  
  
%Refolding the filtered data
  sweep_N = size(SigVec_temp,1);
  sample_N = size(SigVec_temp,2);
  SigVec_all = [];
  
  start_sweep = 1;
  end_sweep = sample_N;
    
  for mm = 1:sweep_N
  
      temp_data_filtered = [];
     temp_data_filtered = filt_data_signal(1,start_sweep:end_sweep);
     
     SigVec_all = [SigVec_all;temp_data_filtered];
     
     start_sweep = start_sweep + sample_N;
  end_sweep = end_sweep + sample_N;
      
  end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 

%Average groups of "N" sweeps
if remove_first_sweep_check == 1

    SigVec_all(1,:) = [];
            
end

if remove_first_sweep_check == 1
   
    NoiseVec_all(1,:) = [];
    
end

av_sign = [];
av_noise = [];

if run_boost == 1;
%% Bootstrap the RMS values of selected number of "av_sweeps_d_prime" sweeps a "boost_number" number of times;

results_d_prime(2,7) = {boost_number};

for pp = 1:boost_number

[temp_Noise_boot temp_sig_boot] = bootstrap_rms_values(NoiseVec_all,SigVec_all,av_sweeps_d_prime,bottstrap_replace);

av_sign = [av_sign;mean(temp_sig_boot)];
av_noise = [av_noise;mean(temp_Noise_boot)];

end

else
    
    av_sign = SigVec_all;
    av_noise = NoiseVec_all;
    
    results_d_prime(2,7) = {0};

end


%% Creating the Noise and Signal vectors by calculating the RMS value for each sweep collected
NoiseVec = [];
SigVec = [];

if peak_to_peak_d_prime == 1 
   
    p1_start = find(time_d >= p1_d_prime_val(1),1,'first');
p1_end = find(time_d >= p1_d_prime_val(2),1,'first');

n1_start = find(time_d >= n1_d_prime_val(1),1,'first');
n1_end = find(time_d >= n1_d_prime_val(2),1,'first');

end

for kk = 1:size(av_sign,1)
    
    if peak_to_peak_d_prime == 1    %Select the type of analysis: peak-to-peak or RMS
        
        NoiseVec(kk,1) = max(av_noise(kk,p1_start:p1_end)) - min(av_noise(kk,n1_start:n1_end));
     SigVec(kk,1) = max(av_sign(kk,p1_start:p1_end)) - min(av_sign(kk,n1_start:n1_end));
        
    else
    
NoiseVec(kk,1) = sqrt(mean(av_noise(kk,samples_av_start:samples_av_end).^2));
     SigVec(kk,1) = sqrt(mean(av_sign(kk,samples_av_start:samples_av_end).^2));

    end
     
end


CountList = [];

if run_boost == 0
    
CountList= unique([NoiseVec(:);SigVec(:)]);
CountList= flipud(CountList);

else
    
   CountList= sort([NoiseVec(:);SigVec(:)],'descend');

end

NCnt= length(CountList);
mySigVec= zeros(NCnt+2,1);
myNoiseVec= zeros(NCnt+2,1);

for iCnt=1:NCnt,
    myNoiseVec(iCnt)= sum(NoiseVec>CountList(iCnt));
    mySigVec(iCnt)= sum(SigVec>CountList(iCnt));
end

%Converting the values into probability
myNoiseVec = myNoiseVec/length(NoiseVec);
mySigVec = mySigVec/length(SigVec);

%% Plotting the ROC curve for each condition tested
figure(fig_roc.Number)
hold on
plot(mySigVec(1:end-2),myNoiseVec(1:end-2))
xlabel('\bfSignal')
ylabel('\bfNoise')

myNoiseVec(iCnt+1)= 1;    % complete the polygon
mySigVec(iCnt+1)= 1;
myNoiseVec(iCnt+2)= 1;
mySigVec(iCnt+2)= 0;
Prob= polyarea(myNoiseVec,mySigVec);
N= (length(NoiseVec)+length(SigVec))/2;

MyLim= 1/(2*N); %This limit is used to cope with the 100% and 0% problem that exists when you calculate the z-transform of the ROC curve

Prob= min(Prob,1-MyLim);
Prob= max(Prob,MyLim);

dp= P2_DPrime(Prob);

save_dp = [save_dp;dp];

results_d_prime(track_subjects + 1,1) = {matrix_file};
results_d_prime(track_subjects + 1,2) = {dp};

end

  
%% Plotting the d-prime
figure
plot(save_dp,'-o')
ylabel('\bfD-prime')
set(gca,'TickLabelInterpreter','none')
set(gca,'XTick',[1:length(save_names_legend)])
set(gca,'XTickLabel',save_names_legend)
hold on
plot(cumsum(save_dp),'Color','r','Marker','o','Linewidth',2)
legend('Individual d-prime','Cumulative d-prime')

if peak_to_peak_d_prime == 1
    
  saveas(gcf,['Cumulative_D_Prime_' num2str(p1_d_prime_val(1)) '_' num2str(p1_d_prime_val(2)) '_' num2str(n1_d_prime_val(1)) '_' num2str(n1_d_prime_val(2)) '_' num2str(chan_selected_name) '.fig']) 
xlswrite (['Cumulative_D_Prime_' num2str(p1_d_prime_val(1)) '_' num2str(p1_d_prime_val(2)) '_' num2str(n1_d_prime_val(1)) '_' num2str(n1_d_prime_val(2)) '_' num2str(chan_selected_name) '.xls'],results_d_prime)
  
    
else
    
saveas(gcf,['Cumulative_D_Prime_RMS_' num2str(start_time_d_prime) '_' num2str(end_time_d_prime) '_' num2str(chan_selected_name) '.fig']) 
xlswrite (['Cumulative_D_Prime_RMS_' num2str(start_time_d_prime) '_' num2str(end_time_d_prime) '_' num2str(chan_selected_name) '.xls'],results_d_prime)

end

figure(fig_roc.Number)
legend(save_names_legend,'Interpreter','none');
hold off
xlabel('\bfSignal');
ylabel('\bfNoise');

if peak_to_peak_d_prime == 1
   
    saveas(gcf,['Cumulative_ROC_' num2str(p1_d_prime_val(1)) '_' num2str(p1_d_prime_val(2)) '_' num2str(n1_d_prime_val(1)) '_' num2str(n1_d_prime_val(2)) '_' num2str(chan_selected_name) '.fig']) 
    
else
    
saveas(gcf,['Cumulative_ROC_RMS_' num2str(start_time_d_prime) '_' num2str(end_time_d_prime) '_' num2str(chan_selected_name) '.fig']) 

end

message = 'D-prime has been calculated and figures/files have been saved';

        msgbox(message,'End of the calculation','warn');
