function dp=p2dprime(Prob)
% P2Z -- Convert Probability to dprime for 2AFC.
%
% Prob is the area under the normal curve for
% -Inf < Z.  This version returns d' of 
% 3.29 for p>=.99 and -3.29 for p<=.01;
%Z=SQRT(2)*ERFINV((Prob-0.5)*2)
%dp= sqrt(2)*z
%Usage: dprime=p2dprime(Prob)
%By JCM, 7/19/00, derived from p2z by SF, 11/20/97
% 
% P= min(Prob,.99);   % this forces max d' of 3.29
% P= max(P,.01);   % ... and min of -3.29
% dp=2*erfinv((P-0.5)*2);
%
% Re-writted by JCM (11/16/06 to use norminv function
%   in Stats toolbox. According to the area theorem,
%   the area under the yes-no (or rating) ROC curve
%   gives p(c)max,2AFC. dprime is sqrt(2) times the 
%   z transform of p(c). (eq 7.7 in Macmillan and Creelman)).

% Prob= min(Prob,.99);   % this forces max d' of 3.29
% Prob= max(Prob,.01);    % and min of -3.29

dp= sqrt(2)*norminv(Prob,0,1);  %"norminv" returns the z-transform; I believe 2AFC can be applied to the ACC data too 

