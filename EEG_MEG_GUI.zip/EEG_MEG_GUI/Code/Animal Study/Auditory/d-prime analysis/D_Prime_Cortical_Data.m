function varargout = D_Prime_Cortical_Data(varargin)
% D_PRIME_CORTICAL_DATA MATLAB code for D_Prime_Cortical_Data.fig
%      D_PRIME_CORTICAL_DATA, by itself, creates a new D_PRIME_CORTICAL_DATA or raises the existing
%      singleton*.
%
%      H = D_PRIME_CORTICAL_DATA returns the handle to a new D_PRIME_CORTICAL_DATA or the handle to
%      the existing singleton*.
%
%      D_PRIME_CORTICAL_DATA('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in D_PRIME_CORTICAL_DATA.M with the given input arguments.
%
%      D_PRIME_CORTICAL_DATA('Property','Value',...) creates a new D_PRIME_CORTICAL_DATA or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before D_Prime_Cortical_Data_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to D_Prime_Cortical_Data_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help D_Prime_Cortical_Data

% Last Modified by GUIDE v2.5 26-Oct-2017 13:12:00

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @D_Prime_Cortical_Data_OpeningFcn, ...
                   'gui_OutputFcn',  @D_Prime_Cortical_Data_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before D_Prime_Cortical_Data is made visible.
function D_Prime_Cortical_Data_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to D_Prime_Cortical_Data (see VARARGIN)

% Choose default command line output for D_Prime_Cortical_Data
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes D_Prime_Cortical_Data wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = D_Prime_Cortical_Data_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Dir uploaded with the signals for the d-prime analysis 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Dir_Responses_d_prime_Callback(hObject, eventdata, handles)
% hObject    handle to Dir_Responses_d_prime (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Dir_Responses_d_prime as text
%        str2double(get(hObject,'String')) returns contents of Dir_Responses_d_prime as a double


% --- Executes during object creation, after setting all properties.
function Dir_Responses_d_prime_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Dir_Responses_d_prime (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Upload the signals for the d-prime analysis 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in Responses_d_prime.
function Responses_d_prime_Callback(hObject, eventdata, handles)
% hObject    handle to Responses_d_prime (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global Signal_d_prime_Cortical_selected;
global Signal_d_prime_Cortical_directory; 

[Signal_d_prime_Cortical_selected,Signal_d_prime_Cortical_directory] = uigetfile('*.mat','Select the "mat" file for the signal');

cd(Signal_d_prime_Cortical_directory)
temp_data = load(Signal_d_prime_Cortical_selected);
for kk = 1:size(temp_data.ind_sweeps,1)
    
channels(kk) = {kk};

end

set(handles.Dir_Responses_d_prime,'String',Signal_d_prime_Cortical_directory);
set(handles.Chan_Data_d_prime,'String',cell2mat(channels));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Noise file uploaded for the d-prime analysis 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Noise_d_prime_uploaded_Callback(hObject, eventdata, handles)
% hObject    handle to Noise_d_prime_uploaded (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Noise_d_prime_uploaded as text
%        str2double(get(hObject,'String')) returns contents of Noise_d_prime_uploaded as a double


% --- Executes during object creation, after setting all properties.
function Noise_d_prime_uploaded_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Noise_d_prime_uploaded (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Upload the noise file for the d-prime analysis 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in Noise_d_prime.
function Noise_d_prime_Callback(hObject, eventdata, handles)
% hObject    handle to Noise_d_prime (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global Noise_d_prime_Cortical_selected;
global Noise_d_prime_Cortical_directory; 

[Noise_d_prime_Cortical_selected,Noise_d_prime_Cortical_directory] = uigetfile('*.mat','Select the "mat" file for the noise');

set(handles.Noise_d_prime_uploaded,'String',Noise_d_prime_Cortical_selected);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%High pass cut-off of the filter
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function High_Pass_d_prime_Callback(hObject, eventdata, handles)
% hObject    handle to High_Pass_d_prime (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of High_Pass_d_prime as text
%        str2double(get(hObject,'String')) returns contents of High_Pass_d_prime as a double


% --- Executes during object creation, after setting all properties.
function High_Pass_d_prime_CreateFcn(hObject, eventdata, handles)
% hObject    handle to High_Pass_d_prime (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Order of the filter
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Order_d_prime_Callback(hObject, eventdata, handles)
% hObject    handle to Order_d_prime (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Order_d_prime as text
%        str2double(get(hObject,'String')) returns contents of Order_d_prime as a double


% --- Executes during object creation, after setting all properties.
function Order_d_prime_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Order_d_prime (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Low pass cut-off of the filter
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Low_Pass_d_prime_Callback(hObject, eventdata, handles)
% hObject    handle to Low_Pass_d_prime (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Low_Pass_d_prime as text
%        str2double(get(hObject,'String')) returns contents of Low_Pass_d_prime as a double


% --- Executes during object creation, after setting all properties.
function Low_Pass_d_prime_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Low_Pass_d_prime (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%If checked, a comb filter will be used to remove 60 Hz and its harmonics
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in line_noise_comb_d_prime.
function line_noise_comb_d_prime_Callback(hObject, eventdata, handles)
% hObject    handle to line_noise_comb_d_prime (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of line_noise_comb_d_prime

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Channels available for the analysis
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on selection change in Chan_Data_d_prime.
function Chan_Data_d_prime_Callback(hObject, eventdata, handles)
% hObject    handle to Chan_Data_d_prime (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns Chan_Data_d_prime contents as cell array
%        contents{get(hObject,'Value')} returns selected item from Chan_Data_d_prime


% --- Executes during object creation, after setting all properties.
function Chan_Data_d_prime_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Chan_Data_d_prime (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Calculate the d-prime
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in Calculate_d_prime.
function Calculate_d_prime_Callback(hObject, eventdata, handles)
% hObject    handle to Calculate_d_prime (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global Signal_d_prime_Cortical_selected;
global Signal_d_prime_Cortical_directory; 
global Noise_d_prime_Cortical_selected;
global Noise_d_prime_Cortical_directory; 

chan_options = get(handles.Chan_Data_d_prime,'String');
chan_selected = get(handles.Chan_Data_d_prime,'Value');
chan_selected_name = chan_options(chan_selected);

order_filt = str2double(get(handles.Order_d_prime,'String'));
high_pass_filt = str2double(get(handles.High_Pass_d_prime,'String'));
low_pass_filt = str2double(get(handles.Low_Pass_d_prime,'String'));

line_noise = get(handles.line_noise_comb_d_prime,'Value');

av_sweeps_d_prime = str2double(get(handles.Sweeps_Av_d_prime,'String'));

start_time_d_prime = str2double(get(handles.Start_T,'String'));
end_time_d_prime = str2double(get(handles.End_T,'String'));

run_boost = get(handles.Boosting_D_Prime,'Value');
boost_number = str2double(get(handles.Boosting_Number,'String'));

remove_first_sweep_check = get(handles.Remove_First_Sweep_D_Prime,'Value');

peak_to_peak_d_prime = get(handles.Peak_to_Peak_d_prime,'Value');

p1_d_prime_val = str2num(get(handles.P1_d_prime,'String'));
n1_d_prime_val = str2num(get(handles.N1_d_prime,'String'));
p1_prime_d_prime_val = str2num(get(handles.P1_Prime_D_Prime,'String'));
n1_prime_d_prime_val = str2num(get(handles.N1_Prime_D_Prime,'String'));

bottstrap_replace = get(handles.Bootstrap_Option,'Value');

if get(handles.Cum_d_prime,'Value') ~= 1
    
Get_DPrime(Signal_d_prime_Cortical_selected,Signal_d_prime_Cortical_directory,Noise_d_prime_Cortical_selected,Noise_d_prime_Cortical_directory,...
    chan_selected,chan_selected_name,order_filt,high_pass_filt,low_pass_filt,line_noise,av_sweeps_d_prime,start_time_d_prime,end_time_d_prime,...
    run_boost,boost_number,remove_first_sweep_check,peak_to_peak_d_prime,p1_d_prime_val,n1_d_prime_val,bottstrap_replace,p1_prime_d_prime_val,n1_prime_d_prime_val)

else
   
   Get_DPrime_cumulative(Signal_d_prime_Cortical_selected,Signal_d_prime_Cortical_directory,Noise_d_prime_Cortical_selected,Noise_d_prime_Cortical_directory,...
    chan_selected,chan_selected_name,order_filt,high_pass_filt,low_pass_filt,line_noise,av_sweeps_d_prime,start_time_d_prime,end_time_d_prime,...
    run_boost,boost_number,remove_first_sweep_check,peak_to_peak_d_prime,p1_d_prime_val,n1_d_prime_val,bottstrap_replace) 
    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Sweeps to be averaged for the d-prime analysis
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Sweeps_Av_d_prime_Callback(hObject, eventdata, handles)
% hObject    handle to Sweeps_Av_d_prime (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Sweeps_Av_d_prime as text
%        str2double(get(hObject,'String')) returns contents of Sweeps_Av_d_prime as a double


% --- Executes during object creation, after setting all properties.
function Sweeps_Av_d_prime_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Sweeps_Av_d_prime (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Start time for the analysis
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Start_T_Callback(hObject, eventdata, handles)
% hObject    handle to Start_T (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Start_T as text
%        str2double(get(hObject,'String')) returns contents of Start_T as a double


% --- Executes during object creation, after setting all properties.
function Start_T_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Start_T (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%End time for the analysis
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function End_T_Callback(hObject, eventdata, handles)
% hObject    handle to End_T (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of End_T as text
%        str2double(get(hObject,'String')) returns contents of End_T as a double


% --- Executes during object creation, after setting all properties.
function End_T_CreateFcn(hObject, eventdata, handles)
% hObject    handle to End_T (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%If checked, boosting will be applied to the RMS values
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in Boosting_D_Prime.
function Boosting_D_Prime_Callback(hObject, eventdata, handles)
% hObject    handle to Boosting_D_Prime (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of Boosting_D_Prime

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Number of samples to be drawn
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Boosting_Number_Callback(hObject, eventdata, handles)
% hObject    handle to Boosting_Number (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Boosting_Number as text
%        str2double(get(hObject,'String')) returns contents of Boosting_Number as a double


% --- Executes during object creation, after setting all properties.
function Boosting_Number_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Boosting_Number (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%If checked, the first sweep recorded will be removed from the analysis
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in Remove_First_Sweep_D_Prime.
function Remove_First_Sweep_D_Prime_Callback(hObject, eventdata, handles)
% hObject    handle to Remove_First_Sweep_D_Prime (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of Remove_First_Sweep_D_Prime

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%If checked, the cumulative d-prime will be calculated
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in Cum_d_prime.
function Cum_d_prime_Callback(hObject, eventdata, handles)
% hObject    handle to Cum_d_prime (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of Cum_d_prime

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%If checked, the peak-to-peak will be used for the d-prime
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in Peak_to_Peak_d_prime.
function Peak_to_Peak_d_prime_Callback(hObject, eventdata, handles)
% hObject    handle to Peak_to_Peak_d_prime (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of Peak_to_Peak_d_prime

if get(handles.Peak_to_Peak_d_prime,'Value')
    
    set(handles.Panel_Peaks_d_Prime,'Visible','on');
    set(handles.Start_T,'Enable','off');
    set(handles.End_T,'Enable','off');
    
else
    
    set(handles.Panel_Peaks_d_Prime,'Visible','off');
    set(handles.Start_T,'Enable','on');
    set(handles.End_T,'Enable','on');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Time window for the P1
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function P1_d_prime_Callback(hObject, eventdata, handles)
% hObject    handle to P1_d_prime (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of P1_d_prime as text
%        str2double(get(hObject,'String')) returns contents of P1_d_prime as a double


% --- Executes during object creation, after setting all properties.
function P1_d_prime_CreateFcn(hObject, eventdata, handles)
% hObject    handle to P1_d_prime (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Time window for the N1
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function N1_d_prime_Callback(hObject, eventdata, handles)
% hObject    handle to N1_d_prime (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of N1_d_prime as text
%        str2double(get(hObject,'String')) returns contents of N1_d_prime as a double


% --- Executes during object creation, after setting all properties.
function N1_d_prime_CreateFcn(hObject, eventdata, handles)
% hObject    handle to N1_d_prime (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%It determines if the bootstrap is executed with or without replacement
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on selection change in Bootstrap_Option.
function Bootstrap_Option_Callback(hObject, eventdata, handles)
% hObject    handle to Bootstrap_Option (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns Bootstrap_Option contents as cell array
%        contents{get(hObject,'Value')} returns selected item from Bootstrap_Option


% --- Executes during object creation, after setting all properties.
function Bootstrap_Option_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Bootstrap_Option (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Time window for the P1'
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function P1_Prime_D_Prime_Callback(hObject, eventdata, handles)
% hObject    handle to P1_Prime_D_Prime (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of P1_Prime_D_Prime as text
%        str2double(get(hObject,'String')) returns contents of P1_Prime_D_Prime as a double


% --- Executes during object creation, after setting all properties.
function P1_Prime_D_Prime_CreateFcn(hObject, eventdata, handles)
% hObject    handle to P1_Prime_D_Prime (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Time window for the N1'
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function N1_Prime_D_Prime_Callback(hObject, eventdata, handles)
% hObject    handle to N1_Prime_D_Prime (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of N1_Prime_D_Prime as text
%        str2double(get(hObject,'String')) returns contents of N1_Prime_D_Prime as a double


% --- Executes during object creation, after setting all properties.
function N1_Prime_D_Prime_CreateFcn(hObject, eventdata, handles)
% hObject    handle to N1_Prime_D_Prime (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
