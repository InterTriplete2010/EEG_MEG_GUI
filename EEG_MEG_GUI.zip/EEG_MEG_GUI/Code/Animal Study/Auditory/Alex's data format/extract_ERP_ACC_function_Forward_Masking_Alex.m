function extract_ERP_ACC_function_Forward_Masking_Alex(ACC_selected,ACC_directory,start_t_ERP,end_t_ERP,start_t_ACC,end_t_ACC,channel_to_be_tested,channel_selected_name,...
                            cut_off_low,cut_off_high,order_filt,comb_filter_check,remove_first_sweep,invert_pol,baseline_data,stand_RMS,...
                            frequencies_available,frequencies_selected_name,frequencies_to_be_tested,length_frequencies_available,levels_selected_name,...
                            levels_available,levels_to_be_tested,levels_frequencies_to_be_tested,levels_frequencies_selected_name,length_levels_available)

cd(ACC_directory)
matrix_file = ACC_selected;
temp_data_struct = load(matrix_file);

if levels_frequencies_to_be_tested == 1
   
    temp_all_data = squeeze(temp_data_struct.ind_sweeps(channel_to_be_tested,1:length_frequencies_available,levels_to_be_tested,:,:));
    level_freq_legend = frequencies_available;
    level_freq_save_file = num2str(levels_selected_name);
    
else
    
     temp_all_data = squeeze(temp_data_struct.ind_sweeps(channel_to_be_tested,frequencies_to_be_tested,1:length_levels_available,:,:));
    level_freq_legend = levels_available;
    level_freq_save_file = num2str(frequencies_selected_name);
    
end

track_subjects = 0;

%Figure used to plot the whole response
figure
fig_whole = gcf;

%Figure used to plot the ERP results
figure
fig_ERP = gcf;

%Figure used to plot the ACC results
figure
fig_ACC = gcf;

save_ampl_ERP(1,1) = {'Subject ID#'}; %Matrix used to the save the amplitudes of the ERP
save_ampl_ERP(1,2) = {'Frequency ID#'}; 
save_ampl_ERP(1,3) = {'Level ID#'};   
save_ampl_ERP(1,4) = {'RMS (Average)'};
save_ampl_ERP(1,5) = {'RMS (Mean across trials)'};
save_ampl_ERP(1,6) = {'SD'};
save_ampl_ERP(1,7) = {'CV'};     %Coefficient of variation
save_ampl_ERP(1,8) = {'Band Pass Filter (Order,High,Low)'};     %Parameters used for the band-pass filter
save_ampl_ERP(2,8) = {num2str([order_filt cut_off_high cut_off_low ])};   
save_ampl_ERP(1,9) = {'60 Hz Notch Filter'};

if comb_filter_check == 1

    save_ampl_ERP(2,9) = {'Yes'};

else
   
    save_ampl_ERP(2,9) = {'No'};
    
end

save_ampl_ERP(1,10) = {'Remove First Sweep'};

if remove_first_sweep == 1

    save_ampl_ERP(2,10) = {'Yes'};

else
   
    save_ampl_ERP(2,10) = {'No'};
    
end

save_ampl_ACC(1,1) = {'Subject ID#'}; %Matrix used to the save the amplitude of the ACC
save_ampl_ACC(1,2) = {'Frequency ID#'}; 
save_ampl_ACC(1,3) = {'Level ID#'};   
save_ampl_ACC(1,4) = {'RMS (Average)'};
save_ampl_ACC(1,5) = {'RMS (Mean across trials)'};
save_ampl_ACC(1,6) = {'SD'};
save_ampl_ACC(1,7) = {'CV'};    %Coefficient of variation
save_ampl_ACC(1,8) = {'Band Pass Filter (Order,High,Low)'};     %Parameters used for the band-pass filter
save_ampl_ACC(2,8) = {num2str([order_filt cut_off_high cut_off_low ])};   
save_ampl_ACC(1,9) = {'60 Hz Notch Filter'};

if comb_filter_check == 1

    save_ampl_ACC(2,9) = {'Yes'};

else
   
    save_ampl_ACC(2,9) = {'No'};
    
end

if remove_first_sweep == 1

    save_ampl_ACC(2,10) = {'Yes'};

else
   
    save_ampl_ACC(2,10) = {'No'};
    
end

temp_save_RMS_ERP = [];
temp_save_sd_ERP = [];

temp_save_RMS_ACC = [];
temp_save_sd_ACC = [];

save_subject_plot = [];

save_names_legend = [];

save_av_line = [];

for ii = 1:size(temp_all_data,1)
               
        track_subjects = track_subjects + 1;
        
        save_subject_plot = [save_subject_plot;track_subjects];
          
  save_names_legend = [save_names_legend;{level_freq_legend(ii,:)}];
  
  save_ampl_ERP(track_subjects + 1,1) = {matrix_file(1:end-4)};
  save_ampl_ACC(track_subjects + 1,1) = {matrix_file(1:end-4)};
  
  if levels_frequencies_to_be_tested == 1
    
  save_ampl_ERP(track_subjects + 1,2) = {frequencies_available(ii,:)};
  save_ampl_ACC(track_subjects + 1,2) = {frequencies_available(ii,:)};
  
  save_ampl_ERP(track_subjects + 1,3) = {levels_selected_name};
  save_ampl_ACC(track_subjects + 1,3) = {levels_selected_name};
  
  else
     
      save_ampl_ERP(track_subjects + 1,2) = {frequencies_selected_name};
  save_ampl_ACC(track_subjects + 1,2) = {frequencies_selected_name};
  
  save_ampl_ERP(track_subjects + 1,3) = {levels_available(ii,:)};
  save_ampl_ACC(track_subjects + 1,3) = {levels_available(ii,:)};
      
  end
  
      
  if invert_pol == 1 
      
  temp_data = -squeeze(temp_all_data(ii,:,:));    %20 is the gain of the TDT system
  
  else
      
  temp_data = squeeze(temp_all_data(ii,:,:));    %20 is the gain of the TDT system    
  
  end
  
   
  %Unfolding the data to minimize the border efffect when filtering the data
  unfold_data = [];
  for ll = 1:size(temp_data,1)
      
      unfold_data = [unfold_data temp_data(ll,:)];
      
  end
  
  unfold_data = unfold_data/20; %Dividing by the gain
  
  %Filtering out the 60 Hz
  if (comb_filter_check == 1)
      
  fs = (temp_data_struct.sampl_freq); fo = 60;  q = 10; bw = (fo/(fs/2))/q;
  [bn,an] = iircomb(round(fs/fo),bw,'notch');
  
  filt_data_60Hz = filtfilt(bn,an,unfold_data);
  
  else
      
      filt_data_60Hz = unfold_data;
      
  end
   
  if track_subjects == 1
      
  [b1,a1] = butter(order_filt,[cut_off_high cut_off_low]/(temp_data_struct.sampl_freq/2)); 
        
  check_stability(b1,a1);
  
  end
  
   %filtering the data
  filt_data = filtfilt(b1,a1,filt_data_60Hz);
  
  %Refolding the filtered data
  sweep_N = size(temp_data,1);
  sample_N = size(temp_data,2);
  temp_data = [];
  
  start_sweep = 1;
  end_sweep = sample_N;
  
  for mm = 1:sweep_N
  
      temp_data_filtered = [];
     temp_data_filtered = filt_data(1,start_sweep:end_sweep);
     
     temp_data = [temp_data;temp_data_filtered];
     
     start_sweep = start_sweep + sample_N;
  end_sweep = end_sweep + sample_N;
      
  end
  
  
  time_d = temp_data_struct.time_av;

%% Adding the baseline to the data (only for visualization purpose)   
add_baseline = [];  
    
    start_sweep = 1;
  end_sweep = sample_N;
    
  end_sweep_b = round(abs(baseline_data/1000)*temp_data_struct.sampl_freq);
  time_b = 1000*[-end_sweep_b:-1]/temp_data_struct.sampl_freq;
  
  for kk = 1:sweep_N
  
      if kk == 1
          
          %add_baseline = [add_baseline;zeros(1,end_sweep_b)];
          add_baseline = [add_baseline;randn(1,end_sweep_b)];   %The addition of baseline is used for visualization purpose only. The first sweep cannot have a baseline, so a random vector is used
      else   
          
          temp_baseline = filt_data(1,start_sweep:end_sweep);
               add_baseline = [add_baseline;temp_baseline(1,end-end_sweep_b + 1:end)];
      
               start_sweep = start_sweep + sample_N;
  end_sweep = end_sweep + sample_N;
               
      end
      
  end
  
  
%% Checking if the first sweep needs to be removed from the analysis
if (remove_first_sweep == 1)
    
  temp_data(1,:) = [];  
    add_baseline(1,:) = [];
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Plot the whole response
r = randi(255)/255;
g = randi(255)/255;
b = randi(255)/255;

save_av_line = [save_av_line;mean([add_baseline temp_data])];

%% Checking if the data need to be standardized
if (stand_RMS == 1)
    
  save_av_line(end,:) = mapstd(save_av_line(end,:));  
    
end

figure(fig_whole)
plot([time_b time_d],mean([add_baseline temp_data]),'Color',[r g b],'Linewidth',2)
hold on
  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
  %% Analyze D-ACC
  find_start_erp = find(time_d >= start_t_ERP,1,'first');
  find_end_erp = find(time_d >= end_t_ERP,1,'first');
  time_erp = time_d(:,find_start_erp:find_end_erp);
  temp_erp = temp_data(:,find_start_erp:find_end_erp);
    
figure(fig_ERP)
subplot(2,1,1)
hold on
plot(time_erp,mean(temp_erp),'Color',[r g b],'Linewidth',2)

subplot(2,1,2)
hold on
%max_values_erp = max(temp_erp');
temp_erp_mean = mean(temp_erp);
rms_average_erp = sqrt(mean(temp_erp_mean.^2));
rms_values_erp = sqrt(mean(temp_erp.^2,2));

save_ampl_ERP(track_subjects + 1,4) = {rms_average_erp};
save_ampl_ERP(track_subjects + 1,5) = {mean(rms_values_erp)};
save_ampl_ERP(track_subjects + 1,6) = {std(rms_values_erp)};
save_ampl_ERP(track_subjects + 1,7) = {std(rms_values_erp)/mean(rms_values_erp)};

% temp_save_RMS_ERP = [temp_save_RMS_ERP;mean(rms_values_erp)];
% temp_save_sd_ERP = [temp_save_sd_ERP;std(rms_values_erp)];
% 
% errorbar(save_subject_plot,temp_save_RMS_ERP,temp_save_sd_ERP,'Linewidth',2)

temp_save_RMS_ERP = [temp_save_RMS_ERP;rms_average_erp];
plot(save_subject_plot,temp_save_RMS_ERP,'-o')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
  %% Analyze D-ACC
  find_start_acc = find(time_d >= start_t_ACC,1,'first');
  find_end_acc = find(time_d >= end_t_ACC,1,'first');
  time_acc = time_d(:,find_start_acc:find_end_acc);
  temp_acc = temp_data(:,find_start_acc:find_end_acc);

   

figure(fig_ACC)
subplot(2,1,1)
hold on
plot(time_acc,mean(temp_acc),'Color',[r g b],'Linewidth',2)

subplot(2,1,2)
hold on
%max_values_acc = max(temp_acc');
temp_acc_mean = mean(temp_acc);
rms_average_acc = sqrt(mean(temp_acc_mean.^2));
rms_values_acc = sqrt(mean(temp_acc.^2,2));

save_ampl_ACC(track_subjects + 1,4) = {rms_average_acc};
save_ampl_ACC(track_subjects + 1,5) = {mean(rms_values_acc)};
save_ampl_ACC(track_subjects + 1,6) = {std(rms_values_acc)};
save_ampl_ACC(track_subjects + 1,7) = {std(rms_values_acc)/mean(rms_values_acc)};

% temp_save_RMS_ACC = [temp_save_RMS_ACC;mean(rms_values_acc)];
% temp_save_sd_ACC = [temp_save_sd_ACC;std(rms_values_acc)];
% 
% errorbar(save_subject_plot,temp_save_RMS_ACC,temp_save_sd_ACC,'Linewidth',2)
temp_save_RMS_ACC = [temp_save_RMS_ACC;rms_average_acc];
plot(save_subject_plot,temp_save_RMS_ACC,'-o')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  

    end
    
figure(fig_whole)
hold off
set(fig_whole,'Color',[1 1 1])
title('Whole response')
xlabel('Time (ms)')
ylabel('Amplitude (\muV)')

legend(save_names_legend,'Interpreter','none');

axis tight;

line([start_t_ERP start_t_ERP],[min(min(save_av_line)) max(max(save_av_line))],'Linewidth',3,'Color','k')
line([start_t_ACC start_t_ACC],[min(min(save_av_line)) max(max(save_av_line))],'Linewidth',3,'Color','k')

saveas(fig_whole,['Whole_Response_' cell2mat(channel_selected_name) '_' cell2mat(levels_frequencies_selected_name) '_' level_freq_save_file '.fig']) 

figure(fig_ERP)
hold off

set(fig_ERP,'Color',[1 1 1])

subplot(2,1,1)
title('Averages Region I')
xlabel('Time (ms)')
ylabel('Amplitude (\muV)')

legend(save_names_legend,'Interpreter','none');

axis tight;

subplot(2,1,2)
title('RMS Region I')
xlabel('Subject/Condition')
ylabel('Amplitude (\muV)')

set(gca,'TickLabelInterpreter','none')
set(gca,'XTick',[1:length(save_names_legend)])
set(gca,'XTickLabel',save_names_legend)

axis tight;

saveas(fig_ERP,['Results_Region_I_' cell2mat(channel_selected_name) '_' cell2mat(levels_frequencies_selected_name) '_' level_freq_save_file '.fig'])
xlswrite (['Results_Region_I_' cell2mat(channel_selected_name) '_' cell2mat(levels_frequencies_selected_name) '_' level_freq_save_file '.xls'],save_ampl_ERP)      

figure(fig_ACC)
hold off

set(fig_ACC,'Color',[1 1 1])

subplot(2,1,1)
title('Averages Region II')
xlabel('Time (ms)')
ylabel('Amplitude (\muV)')

legend(save_names_legend,'Interpreter','none');

axis tight;

subplot(2,1,2)
title('RMS Region II')
xlabel('Subject/Condition')
ylabel('Amplitude (\muV)')

set(gca,'TickLabelInterpreter','none')
set(gca,'XTick',[1:length(save_names_legend)])
set(gca,'XTickLabel',save_names_legend)

axis tight;

saveas(fig_ACC,['Results_Region_II_' cell2mat(channel_selected_name) '_' cell2mat(levels_frequencies_selected_name) '_' level_freq_save_file '.fig']) 
xlswrite (['Results_Region_II_' cell2mat(channel_selected_name) '_' cell2mat(levels_frequencies_selected_name) '_' level_freq_save_file '.xls'],save_ampl_ACC)
