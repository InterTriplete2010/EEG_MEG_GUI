function varargout = ACC_Animal_GUI_Alex(varargin)
% ACC_ANIMAL_GUI_ALEX MATLAB code for ACC_Animal_GUI_Alex.fig
%      ACC_ANIMAL_GUI_ALEX, by itself, creates a new ACC_ANIMAL_GUI_ALEX or raises the existing
%      singleton*.
%
%      H = ACC_ANIMAL_GUI_ALEX returns the handle to a new ACC_ANIMAL_GUI_ALEX or the handle to
%      the existing singleton*.
%
%      ACC_ANIMAL_GUI_ALEX('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in ACC_ANIMAL_GUI_ALEX.M with the given input arguments.
%
%      ACC_ANIMAL_GUI_ALEX('Property','Value',...) creates a new ACC_ANIMAL_GUI_ALEX or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before ACC_Animal_GUI_Alex_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to ACC_Animal_GUI_Alex_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help ACC_Animal_GUI_Alex

% Last Modified by GUIDE v2.5 16-May-2018 09:57:34

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @ACC_Animal_GUI_Alex_OpeningFcn, ...
                   'gui_OutputFcn',  @ACC_Animal_GUI_Alex_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before ACC_Animal_GUI_Alex is made visible.
function ACC_Animal_GUI_Alex_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to ACC_Animal_GUI_Alex (see VARARGIN)

% Choose default command line output for ACC_Animal_GUI_Alex
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes ACC_Animal_GUI_Alex wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = ACC_Animal_GUI_Alex_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Extract the peaks
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in Extract_Peaks_ACC_Animal_Alex.
function Extract_Peaks_ACC_Animal_Alex_Callback(hObject, eventdata, handles)
% hObject    handle to Extract_Peaks_ACC_Animal_Alex (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global ACC_selected;
global ACC_directory;
global size_data;

start_t_ERP = str2double(get(handles.Start_ERP_Animal_Alex,'String'));
end_t_ERP = str2double(get(handles.End_ERP_Animal_Alex,'String'));

start_t_ACC = str2double(get(handles.Start_ACC_Alex,'String'));
end_t_ACC = str2double(get(handles.End_ACC_Alex,'String'));

channels_available = get(handles.Channel_ACC_Animal_Alex,'String');
channels_to_be_tested = get(handles.Channel_ACC_Animal_Alex,'Value');
channels_selected_name = channels_available(channels_to_be_tested);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%The frequency and level parameters are used only with the forward masking
%analysis
frequencies_available = get(handles.Frequency_ACC_GUI,'String');
frequencies_to_be_tested = get(handles.Frequency_ACC_GUI,'Value');
frequencies_selected_name = str2num(frequencies_available(frequencies_to_be_tested,:));

levels_available = get(handles.Level_ACC_GUI,'String');
levels_to_be_tested = get(handles.Level_ACC_GUI,'Value');
levels_selected_name = str2num(levels_available(levels_to_be_tested,:));

levels_frequencies_available = get(handles.Freq_Levels_ACC_Choice,'String');
levels_frequencies_to_be_tested = get(handles.Freq_Levels_ACC_Choice,'Value');
levels_frequencies_selected_name = levels_frequencies_available(levels_frequencies_to_be_tested,:);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

cut_off_low = str2double(get(handles.Cut_Off_Low_Animal_Alex,'String'));
cut_off_high = str2double(get(handles.Cut_Off_High_Animal_Alex,'String'));
order_filt = str2double(get(handles.Order_filt_Animal_Alex,'String'));

comb_filter_check = get(handles.Comb_Filter_60_Hz_ACC_Alex,'Value');

remove_first_sweep = get(handles.Remove_First_sweep_ACC,'Value');

invert_pol = get(handles.Invert_polarity_Peaks,'Value');

baseline_data = str2double(get(handles.Baseline_ACC,'String'));

stand_RMS = get(handles.Standardize_RMS,'Value');

if get(handles.Extract_Peaks_RMS_ACC,'Value') == 1
  
    if size_data < 4
extract_ERP_ACC_function_Alex(ACC_directory,start_t_ERP,end_t_ERP,start_t_ACC,end_t_ACC,channels_to_be_tested,channels_selected_name,...
                            cut_off_low,cut_off_high,order_filt,comb_filter_check,remove_first_sweep,invert_pol,baseline_data,stand_RMS)

    else
       
      extract_ERP_ACC_function_Forward_Masking_Alex(ACC_selected,ACC_directory,start_t_ERP,end_t_ERP,start_t_ACC,end_t_ACC,channels_to_be_tested,channels_selected_name,...
                            cut_off_low,cut_off_high,order_filt,comb_filter_check,remove_first_sweep,invert_pol,baseline_data,stand_RMS,...
                            frequencies_available,frequencies_selected_name,frequencies_to_be_tested,length(frequencies_available(:,1)),levels_selected_name,...
                            levels_available,levels_to_be_tested,levels_frequencies_to_be_tested,levels_frequencies_selected_name,length(levels_available(:,1)))  
        
    end
else
 
    if size_data < 4
        
    extract_Peaks_ERP_ACC_function_Alex(ACC_directory,start_t_ERP,end_t_ERP,start_t_ACC,end_t_ACC,channels_to_be_tested,channels_selected_name,...
                            cut_off_low,cut_off_high,order_filt,comb_filter_check,remove_first_sweep,invert_pol,baseline_data,stand_RMS)
    
    else
       
        extract_Peaks_ERP_ACC_function_Forward_Masking_Alex(ACC_selected,ACC_directory,start_t_ERP,end_t_ERP,start_t_ACC,end_t_ACC,channels_to_be_tested,channels_selected_name,...
                            cut_off_low,cut_off_high,order_filt,comb_filter_check,remove_first_sweep,invert_pol,baseline_data,stand_RMS,...
                            frequencies_available,frequencies_selected_name,frequencies_to_be_tested,length(frequencies_available(:,1)),levels_selected_name,...
                            levels_available,levels_to_be_tested,levels_frequencies_to_be_tested,levels_frequencies_selected_name,length(levels_available(:,1)))
        
    end
                        
end
                        
 message = 'Data have been analyzed and saved';

        msgbox(message,'End of the analysis','warn');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Condition to be tested
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on selection change in Channel_ACC_Animal_Alex.
function Channel_ACC_Animal_Alex_Callback(hObject, eventdata, handles)
% hObject    handle to Channel_ACC_Animal_Alex (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns Channel_ACC_Animal_Alex contents as cell array
%        contents{get(hObject,'Value')} returns selected item from Channel_ACC_Animal_Alex


% --- Executes during object creation, after setting all properties.
function Channel_ACC_Animal_Alex_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Channel_ACC_Animal_Alex (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Dir uploaded with the data to be analyzed
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Dir_uploaded_ACC_Animal_Alex_Callback(hObject, eventdata, handles)
% hObject    handle to Dir_uploaded_ACC_Animal_Alex (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Dir_uploaded_ACC_Animal_Alex as text
%        str2double(get(hObject,'String')) returns contents of Dir_uploaded_ACC_Animal_Alex as a double


% --- Executes during object creation, after setting all properties.
function Dir_uploaded_ACC_Animal_Alex_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Dir_uploaded_ACC_Animal_Alex (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Upload the dir with the data to be analyzed
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in Upload_Dir_ACC_Animal_Alex.
function Upload_Dir_ACC_Animal_Alex_Callback(hObject, eventdata, handles)
% hObject    handle to Upload_Dir_ACC_Animal_Alex (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global ACC_selected;
global ACC_directory;
global size_data;

[ACC_selected,ACC_directory] = uigetfile('*.mat','Select the mat file');

set(handles.Dir_uploaded_ACC_Animal_Alex,'String',ACC_directory);

cd(ACC_directory)
temp_file_channels = load(ACC_selected);

set(handles.Frequency_ACC_GUI,'Value',1);
    set(handles.Level_ACC_GUI,'Value',1);
        set(handles.Freq_Levels_ACC_Choice,'Value',1);
    
%Checking if the data have been saved in a 3 or 5-D matrix
size_data = length(size(temp_file_channels.ind_sweeps));
if length(size(temp_file_channels.ind_sweeps)) > 3
       
set(handles.Frequency_ACC_GUI,'String',temp_file_channels.frequencies_tested);    
set(handles.Level_ACC_GUI,'String',temp_file_channels.levels_tested);    
set(handles.Freq_Levels_ACC_Choice,'String',{'Frequency','Level'});

else
    
   set(handles.Frequency_ACC_GUI,'String','Not available');    
set(handles.Level_ACC_GUI,'String','Not available');     
set(handles.Freq_Levels_ACC_Choice,'String','Not available');

end

for kk = 1:size(temp_file_channels.ind_sweeps,1)
   
    chan_file(kk,1) = {['Chan_' num2str(kk)]};
    
end

set(handles.Channel_ACC_Animal_Alex,'Value',1);
set(handles.Channel_ACC_Animal_Alex,'String',chan_file);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Start point of the time window for Region II
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Start_ACC_Alex_Callback(hObject, eventdata, handles)
% hObject    handle to Start_ACC_Alex (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Start_ACC_Alex as text
%        str2double(get(hObject,'String')) returns contents of Start_ACC_Alex as a double


% --- Executes during object creation, after setting all properties.
function Start_ACC_Alex_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Start_ACC_Alex (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%End point of the time window for Region II
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function End_ACC_Alex_Callback(hObject, eventdata, handles)
% hObject    handle to End_ACC_Alex (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of End_ACC_Alex as text
%        str2double(get(hObject,'String')) returns contents of End_ACC_Alex as a double


% --- Executes during object creation, after setting all properties.
function End_ACC_Alex_CreateFcn(hObject, eventdata, handles)
% hObject    handle to End_ACC_Alex (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Start point of the time window for Region II
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Start_ERP_Animal_Alex_Callback(hObject, eventdata, handles)
% hObject    handle to Start_ERP_Animal_Alex (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Start_ERP_Animal_Alex as text
%        str2double(get(hObject,'String')) returns contents of Start_ERP_Animal_Alex as a double


% --- Executes during object creation, after setting all properties.
function Start_ERP_Animal_Alex_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Start_ERP_Animal_Alex (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%End point of the time window for Region I
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function End_ERP_Animal_Alex_Callback(hObject, eventdata, handles)
% hObject    handle to End_ERP_Animal_Alex (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of End_ERP_Animal_Alex as text
%        str2double(get(hObject,'String')) returns contents of End_ERP_Animal_Alex as a double


% --- Executes during object creation, after setting all properties.
function End_ERP_Animal_Alex_CreateFcn(hObject, eventdata, handles)
% hObject    handle to End_ERP_Animal_Alex (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Cut-off of the High pass filter 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Cut_Off_High_Animal_Alex_Callback(hObject, eventdata, handles)
% hObject    handle to Cut_Off_High_Animal_Alex (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Cut_Off_High_Animal_Alex as text
%        str2double(get(hObject,'String')) returns contents of Cut_Off_High_Animal_Alex as a double


% --- Executes during object creation, after setting all properties.
function Cut_Off_High_Animal_Alex_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Cut_Off_High_Animal_Alex (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Order of the filter 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Order_filt_Animal_Alex_Callback(hObject, eventdata, handles)
% hObject    handle to Order_filt_Animal_Alex (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Order_filt_Animal_Alex as text
%        str2double(get(hObject,'String')) returns contents of Order_filt_Animal_Alex as a double


% --- Executes during object creation, after setting all properties.
function Order_filt_Animal_Alex_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Order_filt_Animal_Alex (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Cut-off of the Low pass filter 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Cut_Off_Low_Animal_Alex_Callback(hObject, eventdata, handles)
% hObject    handle to Cut_Off_Low_Animal_Alex (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Cut_Off_Low_Animal_Alex as text
%        str2double(get(hObject,'String')) returns contents of Cut_Off_Low_Animal_Alex as a double


% --- Executes during object creation, after setting all properties.
function Cut_Off_Low_Animal_Alex_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Cut_Off_Low_Animal_Alex (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%If checked, a comb filter will be applied to the data to eliminate 60 Hz
%and its harmonics
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in Comb_Filter_60_Hz_ACC_Alex.
function Comb_Filter_60_Hz_ACC_Alex_Callback(hObject, eventdata, handles)
% hObject    handle to Comb_Filter_60_Hz_ACC_Alex (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of Comb_Filter_60_Hz_ACC_Alex

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%If checked, the first sweep recorded will be tossed out
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in Remove_First_sweep_ACC.
function Remove_First_sweep_ACC_Callback(hObject, eventdata, handles)
% hObject    handle to Remove_First_sweep_ACC (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of Remove_First_sweep_ACC

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%If checked, the polarity of the peaks will be inverted
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in Invert_polarity_Peaks.
function Invert_polarity_Peaks_Callback(hObject, eventdata, handles)
% hObject    handle to Invert_polarity_Peaks (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of Invert_polarity_Peaks

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Baseline to be added to the ERP
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Baseline_ACC_Callback(hObject, eventdata, handles)
% hObject    handle to Baseline_ACC (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Baseline_ACC as text
%        str2double(get(hObject,'String')) returns contents of Baseline_ACC as a double


% --- Executes during object creation, after setting all properties.
function Baseline_ACC_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Baseline_ACC (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%If checked, waveform will be standardized before calculating the RMS value
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in Standardize_RMS.
function Standardize_RMS_Callback(hObject, eventdata, handles)
% hObject    handle to Standardize_RMS (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of Standardize_RMS

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Choose if to analyze RMS or peaks
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on selection change in Extract_Peaks_RMS_ACC.
function Extract_Peaks_RMS_ACC_Callback(hObject, eventdata, handles)
% hObject    handle to Extract_Peaks_RMS_ACC (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns Extract_Peaks_RMS_ACC contents as cell array
%        contents{get(hObject,'Value')} returns selected item from Extract_Peaks_RMS_ACC

if get(handles.Extract_Peaks_RMS_ACC,'Value') == 1
    
set(handles.uipanel4,'Title','Region I')
    set(handles.uipanel5,'Title','Region II')
   
else
   
    set(handles.uipanel4,'Title','Peak P1')
    set(handles.uipanel5,'Title','Peak N1')

end
    
% --- Executes during object creation, after setting all properties.
function Extract_Peaks_RMS_ACC_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Extract_Peaks_RMS_ACC (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Frequencies recorded ACC
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on selection change in Frequency_ACC_GUI.
function Frequency_ACC_GUI_Callback(hObject, eventdata, handles)
% hObject    handle to Frequency_ACC_GUI (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns Frequency_ACC_GUI contents as cell array
%        contents{get(hObject,'Value')} returns selected item from Frequency_ACC_GUI


% --- Executes during object creation, after setting all properties.
function Frequency_ACC_GUI_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Frequency_ACC_GUI (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Levels recorded ACC
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on selection change in Level_ACC_GUI.
function Level_ACC_GUI_Callback(hObject, eventdata, handles)
% hObject    handle to Level_ACC_GUI (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns Level_ACC_GUI contents as cell array
%        contents{get(hObject,'Value')} returns selected item from Level_ACC_GUI


% --- Executes during object creation, after setting all properties.
function Level_ACC_GUI_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Level_ACC_GUI (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Select if the analysis will be done for frequency or level
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on selection change in Freq_Levels_ACC_Choice.
function Freq_Levels_ACC_Choice_Callback(hObject, eventdata, handles)
% hObject    handle to Freq_Levels_ACC_Choice (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns Freq_Levels_ACC_Choice contents as cell array
%        contents{get(hObject,'Value')} returns selected item from Freq_Levels_ACC_Choice


% --- Executes during object creation, after setting all properties.
function Freq_Levels_ACC_Choice_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Freq_Levels_ACC_Choice (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
