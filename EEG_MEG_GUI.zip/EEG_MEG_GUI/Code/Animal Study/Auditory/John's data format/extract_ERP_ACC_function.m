function extract_ERP_ACC_function(ACC_directory,start_t_ERP,end_t_ERP,start_t_ACC,end_t_ACC,dB_to_be_tested,dB_selected_name,...
                            Freq_to_be_tested,Freq_selected_name,cut_off_low,cut_off_high,order_filt)


cd(ACC_directory)

dir_files = dir;

[files_number] = size(dir_files,1);

track_subjects = 0;

%Figure used to plot the ERP results
figure
fig_ERP = gcf;

%Figure used to plot the ACC results
figure
fig_ACC = gcf;

save_ampl_ERP(1,1) = {'Subject ID#'};   %Matrix used to the save the amplitudes of the ERP
save_ampl_ERP(1,2) = {'RMS (Average)'};
save_ampl_ERP(1,3) = {'RMS (Mean across trials)'};
save_ampl_ERP(1,4) = {'SD'};
save_ampl_ERP(1,5) = {'CV'};     %Coefficient of variation

save_ampl_ACC(1,1) = {'Subject ID#'};   %Matrix used to the save the amplitude of the ACC
save_ampl_ACC(1,2) = {'RMS (Average)'};
save_ampl_ACC(1,3) = {'RMS (Mean across trials)'};
save_ampl_ACC(1,4) = {'SD'};
save_ampl_ACC(1,5) = {'CV'};    %Coefficient of variation

temp_save_RMS_ERP = [];
temp_save_sd_ERP = [];

temp_save_RMS_ACC = [];
temp_save_sd_ACC = [];

save_subject_plot = [];

save_names_legend = [];

for ii = 3:files_number
    
    matrix_file = dir_files(ii).name;
    
    if (strcmp(matrix_file(1,end-2:end),'mat') == 1) 
    
        track_subjects = track_subjects + 1;
        
        save_subject_plot = [save_subject_plot;track_subjects];
        
  matrix_file = dir_files(ii).name;  
  
  save_names_legend = [save_names_legend;{matrix_file}];
  
  save_ampl_ERP(track_subjects + 1,1) = {matrix_file};
  save_ampl_ACC(track_subjects + 1,1) = {matrix_file};
  
  temp_data_struct = load(matrix_file);
  temp_data = squeeze(temp_data_struct.data_exported.data(Freq_to_be_tested,dB_to_be_tested,:,:));
  
  %Unfolding the data to minimize the border efffect when filtering the data
  unfold_data = [];
  for ll = 1:size(temp_data,1)
      
      unfold_data = [unfold_data temp_data(ll,:)];
      
  end
  
  %Filtering out the 60 Hz
%   wo = 60/(temp_data_struct.data_exported.sampling_frequency/2);
%   bw = wo/35;
%   [b,a] = iirnotch(60/(temp_data_struct.data_exported.sampling_frequency/2),bw);
%   
%   filt_data_60Hz = filtfilt(b,a,unfold_data);
%    

filt_data_60Hz = unfold_data;

  %filtering the data
  [b,a] = butter(order_filt,[cut_off_high cut_off_low]/(temp_data_struct.data_exported.sampling_frequency/2)); 
    
  filt_data = filtfilt(b,a,filt_data_60Hz);
  
  %Refolding the filtered data
  sweep_N = size(temp_data,1);
  sample_N = size(temp_data,2);
  temp_data = [];
  
  start_sweep = 1;
  end_sweep = sample_N;
  
  for mm = 1:sweep_N
  
     temp_data_filtered = filt_data(1,start_sweep:end_sweep);
     
     temp_data = [temp_data;temp_data_filtered];
     
     start_sweep = start_sweep + sample_N;
  end_sweep = end_sweep + sample_N;
      
  end
  
  
  time_d = temp_data_struct.data_exported.time;
 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
  %% Analyze ERP
  find_start_erp = find(time_d >= start_t_ERP,1,'first');
  find_end_erp = find(time_d >= end_t_ERP,1,'first');
  time_erp = time_d(:,find_start_erp:find_end_erp);
temp_erp = temp_data(:,find_start_erp:find_end_erp);

figure(fig_ERP)
subplot(2,1,1)
hold on
plot(time_erp,mean(temp_erp),'Color',[randi(255)/255 randi(255)/255 randi(255)/255],'Linewidth',2)

subplot(2,1,2)
hold on
%max_values_erp = max(temp_erp');
temp_erp_mean = mean(temp_erp);
rms_average_erp = sqrt(mean(temp_erp_mean.^2));
rms_values_erp = sqrt(mean(temp_erp.^2,2));

save_ampl_ERP(track_subjects + 1,2) = {rms_average_erp};
save_ampl_ERP(track_subjects + 1,3) = {mean(rms_values_erp)};
save_ampl_ERP(track_subjects + 1,4) = {std(rms_values_erp)};
save_ampl_ERP(track_subjects + 1,5) = {std(rms_values_erp)/mean(rms_values_erp)};

temp_save_RMS_ERP = [temp_save_RMS_ERP;mean(rms_values_erp)];
temp_save_sd_ERP = [temp_save_sd_ERP;std(rms_values_erp)];

errorbar(save_subject_plot,temp_save_RMS_ERP,temp_save_sd_ERP,'Linewidth',2)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
  %% Analyze ACC
  find_start_acc = find(time_d >= start_t_ACC,1,'first');
  find_end_acc = find(time_d >= end_t_ACC,1,'first');
  time_acc = time_d(:,find_start_acc:find_end_acc);
temp_acc = temp_data(:,find_start_acc:find_end_acc);

figure(fig_ACC)
subplot(2,1,1)
hold on
plot(time_acc,mean(temp_acc),'Color',[randi(255)/255 randi(255)/255 randi(255)/255],'Linewidth',2)

subplot(2,1,2)
hold on
%max_values_acc = max(temp_acc');
temp_acc_mean = mean(temp_acc);
rms_average_acc = sqrt(mean(temp_acc_mean.^2));
rms_values_acc = sqrt(mean(temp_acc.^2,2));

save_ampl_ACC(track_subjects + 1,2) = {rms_average_acc};
save_ampl_ACC(track_subjects + 1,3) = {mean(rms_values_acc)};
save_ampl_ACC(track_subjects + 1,4) = {std(rms_values_acc)};
save_ampl_ACC(track_subjects + 1,5) = {std(rms_values_acc)/mean(rms_values_acc)};

temp_save_RMS_ACC = [temp_save_RMS_ACC;mean(rms_values_acc)];
temp_save_sd_ACC = [temp_save_sd_ACC;std(rms_values_acc)];

errorbar(save_subject_plot,temp_save_RMS_ACC,temp_save_sd_ACC,'Linewidth',2)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  

    end
    
end

figure(fig_ERP)
hold off

set(fig_ERP,'Color',[1 1 1])

subplot(2,1,1)
title('Averages Region I')
xlabel('Time (ms)')
ylabel('Amplitude (\muV)')

legend(save_names_legend,'Interpreter','none');

subplot(2,1,2)
title('Amplitude +/- SD Region I')
xlabel('Subject')
ylabel('Amplitude (\muV)')

saveas(fig_ERP,['Results_Region_I_' cell2mat(dB_selected_name) 'dB_' cell2mat(Freq_selected_name) 'Hz' '.fig'])
xlswrite (['Results_Region_I_' cell2mat(dB_selected_name) 'dB_' cell2mat(Freq_selected_name) 'Hz' '.xls'],save_ampl_ERP)      

figure(fig_ACC)
hold off

set(fig_ACC,'Color',[1 1 1])

subplot(2,1,1)
title('Averages Region II')
xlabel('Time (ms)')
ylabel('Amplitude (\muV)')

legend(save_names_legend,'Interpreter','none');

subplot(2,1,2)
title('Amplitude +/- SD Region II')
xlabel('Subject')
ylabel('Amplitude (\muV)')

saveas(fig_ACC,['Results_Region_II_' cell2mat(dB_selected_name) 'dB_' cell2mat(Freq_selected_name) 'Hz' '.fig']) 
xlswrite (['Results_Region_II_' cell2mat(dB_selected_name) 'dB_' cell2mat(Freq_selected_name) 'Hz' '.xls'],save_ampl_ACC)
