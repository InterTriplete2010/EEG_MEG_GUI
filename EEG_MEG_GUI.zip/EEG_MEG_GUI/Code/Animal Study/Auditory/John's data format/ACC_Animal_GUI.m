function varargout = ACC_Animal_GUI(varargin)
% ACC_ANIMAL_GUI MATLAB code for ACC_Animal_GUI.fig
%      ACC_ANIMAL_GUI, by itself, creates a new ACC_ANIMAL_GUI or raises the existing
%      singleton*.
%
%      H = ACC_ANIMAL_GUI returns the handle to a new ACC_ANIMAL_GUI or the handle to
%      the existing singleton*.
%
%      ACC_ANIMAL_GUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in ACC_ANIMAL_GUI.M with the given input arguments.
%
%      ACC_ANIMAL_GUI('Property','Value',...) creates a new ACC_ANIMAL_GUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before ACC_Animal_GUI_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to ACC_Animal_GUI_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help ACC_Animal_GUI

% Last Modified by GUIDE v2.5 22-Feb-2017 11:05:27

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @ACC_Animal_GUI_OpeningFcn, ...
                   'gui_OutputFcn',  @ACC_Animal_GUI_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before ACC_Animal_GUI is made visible.
function ACC_Animal_GUI_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to ACC_Animal_GUI (see VARARGIN)

% Choose default command line output for ACC_Animal_GUI
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes ACC_Animal_GUI wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = ACC_Animal_GUI_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Extract the peaks
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in Extract_Peaks_ACC_Animal.
function Extract_Peaks_ACC_Animal_Callback(hObject, eventdata, handles)
% hObject    handle to Extract_Peaks_ACC_Animal (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global ACC_selected;
global ACC_directory;

start_t_ERP = str2double(get(handles.Start_ERP_Animal,'String'));
end_t_ERP = str2double(get(handles.End_ERP_Animal,'String'));

start_t_ACC = str2double(get(handles.Start_ACC,'String'));
end_t_ACC = str2double(get(handles.End_ACC,'String'));

dB_available = get(handles.dB_ACC_Animal,'String');
dB_to_be_tested = get(handles.dB_ACC_Animal,'Value');
dB_selected_name = dB_available(dB_to_be_tested);

Freq_available = get(handles.Freq_Presented_ABR,'String');
Freq_to_be_tested = get(handles.Freq_Presented_ABR,'Value');
Freq_selected_name = Freq_available(Freq_to_be_tested);

cut_off_low = str2double(get(handles.Cut_Off_Low_Animal,'String'));
cut_off_high = str2double(get(handles.Cut_Off_High_Animal,'String'));
order_filt = str2double(get(handles.Order_filt_Animal,'String'));

extract_ERP_ACC_function(ACC_directory,start_t_ERP,end_t_ERP,start_t_ACC,end_t_ACC,dB_to_be_tested,dB_selected_name,...
                            Freq_to_be_tested,Freq_selected_name,cut_off_low,cut_off_high,order_filt)

 message = 'Data have been analyzed and saved';

        msgbox(message,'End of the analysis','warn');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%dB levels to be tested
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on selection change in dB_ACC_Animal.
function dB_ACC_Animal_Callback(hObject, eventdata, handles)
% hObject    handle to dB_ACC_Animal (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns dB_ACC_Animal contents as cell array
%        contents{get(hObject,'Value')} returns selected item from dB_ACC_Animal


% --- Executes during object creation, after setting all properties.
function dB_ACC_Animal_CreateFcn(hObject, eventdata, handles)
% hObject    handle to dB_ACC_Animal (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Dir uploaded with the data to be analyzed
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Dir_uploaded_ACC_Animal_Callback(hObject, eventdata, handles)
% hObject    handle to Dir_uploaded_ACC_Animal (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Dir_uploaded_ACC_Animal as text
%        str2double(get(hObject,'String')) returns contents of Dir_uploaded_ACC_Animal as a double


% --- Executes during object creation, after setting all properties.
function Dir_uploaded_ACC_Animal_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Dir_uploaded_ACC_Animal (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Upload the dir with the data to be analyzed
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in Upload_Dir_ACC_Animal.
function Upload_Dir_ACC_Animal_Callback(hObject, eventdata, handles)
% hObject    handle to Upload_Dir_ACC_Animal (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global ACC_selected;
global ACC_directory;

[ACC_selected,ACC_directory] = uigetfile('*.mat','Select the figure');

set(handles.Dir_uploaded_ACC_Animal,'String',ACC_directory);

cd(ACC_directory)
temp_file_conditions = load(ACC_selected);
set(handles.dB_ACC_Animal,'String',num2cell(temp_file_conditions.data_exported.dB_Levels'));
set(handles.Freq_Presented_ABR,'String',num2cell(temp_file_conditions.data_exported.Frequency'));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Start point of the time window for Region II
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Start_ACC_Callback(hObject, eventdata, handles)
% hObject    handle to Start_ACC (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Start_ACC as text
%        str2double(get(hObject,'String')) returns contents of Start_ACC as a double


% --- Executes during object creation, after setting all properties.
function Start_ACC_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Start_ACC (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%End point of the time window for Region II
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function End_ACC_Callback(hObject, eventdata, handles)
% hObject    handle to End_ACC (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of End_ACC as text
%        str2double(get(hObject,'String')) returns contents of End_ACC as a double


% --- Executes during object creation, after setting all properties.
function End_ACC_CreateFcn(hObject, eventdata, handles)
% hObject    handle to End_ACC (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Start point of the time window for Region II
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Start_ERP_Animal_Callback(hObject, eventdata, handles)
% hObject    handle to Start_ERP_Animal (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Start_ERP_Animal as text
%        str2double(get(hObject,'String')) returns contents of Start_ERP_Animal as a double


% --- Executes during object creation, after setting all properties.
function Start_ERP_Animal_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Start_ERP_Animal (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%End point of the time window for Region I
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function End_ERP_Animal_Callback(hObject, eventdata, handles)
% hObject    handle to End_ERP_Animal (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of End_ERP_Animal as text
%        str2double(get(hObject,'String')) returns contents of End_ERP_Animal as a double


% --- Executes during object creation, after setting all properties.
function End_ERP_Animal_CreateFcn(hObject, eventdata, handles)
% hObject    handle to End_ERP_Animal (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Cut-off of the High pass filter 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Cut_Off_High_Animal_Callback(hObject, eventdata, handles)
% hObject    handle to Cut_Off_High_Animal (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Cut_Off_High_Animal as text
%        str2double(get(hObject,'String')) returns contents of Cut_Off_High_Animal as a double


% --- Executes during object creation, after setting all properties.
function Cut_Off_High_Animal_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Cut_Off_High_Animal (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Order of the filter 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Order_filt_Animal_Callback(hObject, eventdata, handles)
% hObject    handle to Order_filt_Animal (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Order_filt_Animal as text
%        str2double(get(hObject,'String')) returns contents of Order_filt_Animal as a double


% --- Executes during object creation, after setting all properties.
function Order_filt_Animal_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Order_filt_Animal (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Cut-off of the Low pass filter 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Cut_Off_Low_Animal_Callback(hObject, eventdata, handles)
% hObject    handle to Cut_Off_Low_Animal (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Cut_Off_Low_Animal as text
%        str2double(get(hObject,'String')) returns contents of Cut_Off_Low_Animal as a double


% --- Executes during object creation, after setting all properties.
function Cut_Off_Low_Animal_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Cut_Off_Low_Animal (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Frequencies presented
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on selection change in Freq_Presented_ABR.
function Freq_Presented_ABR_Callback(hObject, eventdata, handles)
% hObject    handle to Freq_Presented_ABR (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns Freq_Presented_ABR contents as cell array
%        contents{get(hObject,'Value')} returns selected item from Freq_Presented_ABR


% --- Executes during object creation, after setting all properties.
function Freq_Presented_ABR_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Freq_Presented_ABR (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
