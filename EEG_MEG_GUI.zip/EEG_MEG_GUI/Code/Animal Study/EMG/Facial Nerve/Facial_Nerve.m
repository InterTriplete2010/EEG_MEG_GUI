function varargout = Facial_Nerve(varargin)
% FACIAL_NERVE MATLAB code for Facial_Nerve.fig
%      FACIAL_NERVE, by itself, creates a new FACIAL_NERVE or raises the existing
%      singleton*.
%
%      H = FACIAL_NERVE returns the handle to a new FACIAL_NERVE or the handle to
%      the existing singleton*.
%
%      FACIAL_NERVE('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in FACIAL_NERVE.M with the given input arguments.
%
%      FACIAL_NERVE('Property','Value',...) creates a new FACIAL_NERVE or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before Facial_Nerve_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to Facial_Nerve_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help Facial_Nerve

% Last Modified by GUIDE v2.5 26-Jul-2017 12:53:20

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Facial_Nerve_OpeningFcn, ...
                   'gui_OutputFcn',  @Facial_Nerve_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before Facial_Nerve is made visible.
function Facial_Nerve_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to Facial_Nerve (see VARARGIN)

% Choose default command line output for Facial_Nerve
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes Facial_Nerve wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = Facial_Nerve_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Directory uploaded 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Dir_Uploaded_Facial_Nerve_Callback(hObject, eventdata, handles)
% hObject    handle to Dir_Uploaded_Facial_Nerve (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Dir_Uploaded_Facial_Nerve as text
%        str2double(get(hObject,'String')) returns contents of Dir_Uploaded_Facial_Nerve as a double


% --- Executes during object creation, after setting all properties.
function Dir_Uploaded_Facial_Nerve_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Dir_Uploaded_Facial_Nerve (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Upload the directory with the files to be analyzed 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in Upoload_Dir_Facial_Nerve.
function Upoload_Dir_Facial_Nerve_Callback(hObject, eventdata, handles)
% hObject    handle to Upoload_Dir_Facial_Nerve (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global mat_files_FN;
global dir_FN;
global vector_files_FN;
global all_files_FN;

[mat_files_FN,dir_FN] = uigetfile('*.mat','Select the "dir" file for the analysis');

set(handles.Dir_Uploaded_Facial_Nerve,'String',dir_FN);

%Extracting the "mat" files from the directory
cd(dir_FN)

prop_dir = what;
all_files_FN = {};
vector_files_FN = {};

for kk = 1:length(prop_dir.mat)

    all_files_FN = [all_files_FN;prop_dir.mat(kk)];
    
end
set(handles.Files_Facial_Nerve,'String',all_files_FN);
set(handles.Files_Facial_Nerve,'Max',length(prop_dir.mat)); %Making sure that multiple selections are allowed
set(handles.Files_Selected_FN,'String',[]);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%This table lists the files available
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in Upoload_Dir_Facial_Nerve.
% --- Executes on selection change in Files_Facial_Nerve.
function Files_Facial_Nerve_Callback(hObject, eventdata, handles)
% hObject    handle to Files_Facial_Nerve (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns Files_Facial_Nerve contents as cell array
%        contents{get(hObject,'Value')} returns selected item from Files_Facial_Nerve


% --- Executes during object creation, after setting all properties.
function Files_Facial_Nerve_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Files_Facial_Nerve (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%This table lists the files selected
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on selection change in Files_Selected_FN.
function Files_Selected_FN_Callback(hObject, eventdata, handles)
% hObject    handle to Files_Selected_FN (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns Files_Selected_FN contents as cell array
%        contents{get(hObject,'Value')} returns selected item from Files_Selected_FN


% --- Executes during object creation, after setting all properties.
function Files_Selected_FN_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Files_Selected_FN (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Add a file for the analysis
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in Add_File_FN.
function Add_File_FN_Callback(hObject, eventdata, handles)
% hObject    handle to Add_File_FN (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global vector_files_FN;
global all_files_FN;

File_FN_available = all_files_FN;
temp_file_FN_pos = get(handles.Files_Facial_Nerve,'Value');
temp_file_FN = File_FN_available(temp_file_FN_pos,:);

all_files_FN(temp_file_FN_pos,:) = [];
vector_files_FN = [vector_files_FN;temp_file_FN];

set(handles.Files_Facial_Nerve,'value',1);  %Setting the value to "1" to avoid Matlab to complain about the current position of the file
set(handles.Files_Facial_Nerve,'String',all_files_FN);
set(handles.Files_Selected_FN,'String',vector_files_FN);

set(handles.Files_Facial_Nerve,'Max',length(all_files_FN));
set(handles.Files_Selected_FN,'Max',length(vector_files_FN));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Remove a file for the analysis
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in Remove_File_FN.
function Remove_File_FN_Callback(hObject, eventdata, handles)
% hObject    handle to Remove_File_FN (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global vector_files_FN;
global all_files_FN;

File_FN_available = cellstr(get(handles.Files_Selected_FN,'String'));
temp_file_FN_pos = get(handles.Files_Selected_FN,'Value');
temp_file_FN = File_FN_available(temp_file_FN_pos,:);

all_files_FN = [all_files_FN;temp_file_FN];
vector_files_FN(temp_file_FN_pos,:) = [];

set(handles.Files_Facial_Nerve,'String',all_files_FN);
set(handles.Files_Selected_FN,'value',1);
set(handles.Files_Selected_FN,'String',vector_files_FN);

set(handles.Files_Facial_Nerve,'Max',length(all_files_FN));
set(handles.Files_Selected_FN,'Max',length(vector_files_FN));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Plot the waveforms of the selected files
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in Plot_Waveforms_FN.
function Plot_Waveforms_FN_Callback(hObject, eventdata, handles)
% hObject    handle to Plot_Waveforms_FN (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global vector_files_FN;

figure
max_col = str2double(get(handles.Columns_Subplots_FN,'String'));

for hh = 1:length(vector_files_FN)

    %Setting up the subplots
    if (hh == 1)
       
        if length(vector_files_FN) < max_col
            
        subplot_columns = length(vector_files_FN);
        
        else
            
            subplot_columns = max_col;
            
        end
        
        if mod(length(vector_files_FN),subplot_columns) == 0
            
        subplot_rows = length(vector_files_FN)/subplot_columns;
        
        else
          
            subplot_rows = (length(vector_files_FN) - mod(length(vector_files_FN),subplot_columns))/subplot_columns + 1;
                       
        
        end
        
        subplot(subplot_rows,subplot_columns,hh);
        
    end
        
    temp_file = [];
    temp_data = [];
    temp_file = load(cell2mat(vector_files_FN(hh,:)));
    
    %Building the filter
    if (hh == 1)
        
        [num_FN,den_FN] = butter(str2double(get(handles.Order_Filt_FN,'String')),[str2double(get(handles.HP_Filt_FN,'String')) str2double(get(handles.LP_Filt_FN,'String'))]/(temp_file.data_electrical_pulses.Sampl_Freq/2));
        
        fs = temp_file.data_electrical_pulses.Sampl_Freq; fo = 60;  q = 10; bw = (fo/(fs/2))/q;
  [bn,an] = iircomb(round(fs/fo),bw,'notch');
        
    end
       
    if get(handles.Remove_60_Hz_FN,'Value') == 1
        
  filt_data_60Hz = filter(bn,an,temp_file.data_electrical_pulses.EMG');
  
    else
        
  filt_data_60Hz = temp_file.data_electrical_pulses.EMG';      
  
    end
  
  temp_data = filter(num_FN,den_FN,filt_data_60Hz);
  
        subplot(subplot_rows,subplot_columns,hh);
        
        plot(temp_file.data_electrical_pulses.Time(1,1:size(temp_data,1)),temp_data,'Linewidth',2)
    
        title(cell2mat(vector_files_FN(hh,:)),'Interpreter','none')
        
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Cut-off for the High pass 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function HP_Filt_FN_Callback(hObject, eventdata, handles)
% hObject    handle to HP_Filt_FN (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of HP_Filt_FN as text
%        str2double(get(hObject,'String')) returns contents of HP_Filt_FN as a double


% --- Executes during object creation, after setting all properties.
function HP_Filt_FN_CreateFcn(hObject, eventdata, handles)
% hObject    handle to HP_Filt_FN (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Order of the filter
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Order_Filt_FN_Callback(hObject, eventdata, handles)
% hObject    handle to Order_Filt_FN (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Order_Filt_FN as text
%        str2double(get(hObject,'String')) returns contents of Order_Filt_FN as a double


% --- Executes during object creation, after setting all properties.
function Order_Filt_FN_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Order_Filt_FN (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Cut-off for the Low pass 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function LP_Filt_FN_Callback(hObject, eventdata, handles)
% hObject    handle to LP_Filt_FN (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of LP_Filt_FN as text
%        str2double(get(hObject,'String')) returns contents of LP_Filt_FN as a double


% --- Executes during object creation, after setting all properties.
function LP_Filt_FN_CreateFcn(hObject, eventdata, handles)
% hObject    handle to LP_Filt_FN (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%If checked, a comb filter will be applied to the data to remove 60 Hz
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in Remove_60_Hz_FN.
function Remove_60_Hz_FN_Callback(hObject, eventdata, handles)
% hObject    handle to Remove_60_Hz_FN (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of Remove_60_Hz_FN

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Columns to be generated
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Columns_Subplots_FN_Callback(hObject, eventdata, handles)
% hObject    handle to Columns_Subplots_FN (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Columns_Subplots_FN as text
%        str2double(get(hObject,'String')) returns contents of Columns_Subplots_FN as a double


% --- Executes during object creation, after setting all properties.
function Columns_Subplots_FN_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Columns_Subplots_FN (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Move the file up in the list
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in Move_UP_FN.
function Move_UP_FN_Callback(hObject, eventdata, handles)
% hObject    handle to Move_UP_FN (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global vector_files_FN;

File_FN_available = cellstr(get(handles.Files_Selected_FN,'String'));
temp_file_FN_pos = get(handles.Files_Selected_FN,'Value');
temp_file_FN = File_FN_available(temp_file_FN_pos,:);

if temp_file_FN_pos == 1
   
    return;
    
end

temp_vector_files_FN = vector_files_FN;
temp_vector_files_FN(temp_file_FN_pos,:) = vector_files_FN(temp_file_FN_pos - 1,:);
temp_vector_files_FN(temp_file_FN_pos - 1,:) = temp_file_FN;

vector_files_FN = temp_vector_files_FN;
set(handles.Files_Selected_FN,'String',vector_files_FN);
set(handles.Files_Selected_FN,'value',temp_file_FN_pos - 1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Move the file down in the list
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in Move_down_FN.
function Move_down_FN_Callback(hObject, eventdata, handles)
% hObject    handle to Move_down_FN (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global vector_files_FN;

File_FN_available = cellstr(get(handles.Files_Selected_FN,'String'));
temp_file_FN_pos = get(handles.Files_Selected_FN,'Value');
temp_file_FN = File_FN_available(temp_file_FN_pos,:);

if temp_file_FN_pos == length(vector_files_FN)
   
    return;
    
end

temp_vector_files_FN = vector_files_FN;
temp_vector_files_FN(temp_file_FN_pos,:) = vector_files_FN(temp_file_FN_pos + 1,:);
temp_vector_files_FN(temp_file_FN_pos + 1,:) = temp_file_FN;

vector_files_FN = temp_vector_files_FN;
set(handles.Files_Selected_FN,'String',vector_files_FN);
set(handles.Files_Selected_FN,'value',temp_file_FN_pos + 1);
