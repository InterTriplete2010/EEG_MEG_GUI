function cABR_latencies_function(array_dir,norm_factor,latency_to_be_removed)

%Create the figures to plot the waves
fig_1 = figure;
fig_2 = fig_1 + 1;
fig_3 = fig_1 + 2;

colors_plot = ['r';'k';'r';'k'];

norm_factor_plot = norm_factor;
norm_factor_plot (latency_to_be_removed) = [];

save_mean_values = [];
create_matrix_stats_analysis = 1;

for kk = 1:length(array_dir)

cd(cell2mat(array_dir(kk)))

mat_files = dir;

[files_number] = size(mat_files,1);

if(create_matrix_stats_analysis == 1)

    save_values_stats_analysis = zeros(length(array_dir),files_number-2,length(norm_factor));

    create_matrix_stats_analysis = 0;
    
end

save_latencies = [];

for ii = 3:files_number
    
    if (strcmp(mat_files(ii).name(end-3:end), '.xls') == 1)

  matrix_file = mat_files(ii).name;      
  
  [num,txt,raw] = xlsread(matrix_file);
  
  num_normalized = num(1,:) - norm_factor;
  
  save_latencies = [save_latencies;num_normalized(1,:)];
  save_values_stats_analysis(kk,ii - 2,:) = num_normalized;  
  
    end
    
end


save_latencies(:,latency_to_be_removed) = []; 

if (size(save_latencies,1) > 1)
    
mean_values = mean(save_latencies); 
std_values = std(save_latencies);
std_error_values = std_values/sqrt(length(mean_values));

else
    
    mean_values = save_latencies; 
std_values = zeros(1,size(save_latencies,2));
    std_error_values = std_values/sqrt(length(mean_values));
    
end

save_mean_values = [save_mean_values;mean_values];

%% Plot the values with std
figure(fig_1)

if (kk == 1 || kk == 2)
subplot(2,1,1)
errorbar(norm_factor_plot,mean_values,std_values,colors_plot(kk))

if (kk == 2)

    xlabel('\bfTime (ms)')
    ylabel('\bfNormalized Timing (ms)')
    
    title('\bfDA with STD')
legend('Young','Old')

set(gca,'fontweight','bold')

else
    
    hold on

end

else
subplot(2,1,2)
errorbar(norm_factor_plot,mean_values,std_values,colors_plot(kk))

if (kk == 4)

    cd ..
cd ..
    
    xlabel('\bfTime (ms)')
    ylabel('\bfNormalized Timing (ms)')
    title('\bfAH with STD')
legend('Young','Old')

set(gca,'fontweight','bold')

saveas(gcf,'Normalized_Peaks_Standard_Deviation.fig')

else
    
    hold on

end

end

%% Plot the values with Standard Error
figure(fig_2)

if (kk == 1 || kk == 2)
subplot(2,1,1)
errorbar(norm_factor_plot,mean_values,std_error_values,colors_plot(kk))

if (kk == 2)

    xlabel('\bfTime (ms)')
    ylabel('\bfNormalized Timing (ms)')
    
    title('\bfDA with Sandard Error')
legend('Young','Old')

set(gca,'fontweight','bold')

else
    
    hold on

end

else
subplot(2,1,2)
errorbar(norm_factor_plot,mean_values,std_error_values,colors_plot(kk))

if (kk == 4)


    xlabel('\bfTime (ms)')
    ylabel('\bfNormalized Timing (ms)')
    title('\bfAH with Standard Error')
legend('Young','Old')

set(gca,'fontweight','bold')

saveas(gcf,'Normalized_Peaks_Standard_Error.fig')

else
    
    hold on

end

end

%% Plot the values without std or standard deviation
figure(fig_3)
if (kk == 1 || kk == 2)
subplot(2,1,1)
plot(norm_factor_plot,mean_values,colors_plot(kk))

if (kk == 2)

    xlabel('\bfTime (ms)')
    ylabel('\bfNormalized Timing (ms)')
    title('\bfDA')
legend('Young','Old')
set(gca,'fontweight','bold')


else
    
    hold on

end

else
    
subplot(2,1,2)
plot(norm_factor_plot,mean_values,colors_plot(kk))

if (kk == 4)

    xlabel('\bfTime (ms)')
    ylabel('\bfNormalized Timing (ms)')
    title('\bfAH')
legend('Young','Old')
set(gca,'fontweight','bold')

saveas(gcf,'Normalized_Peaks_No_Error.fig')

else
    
    hold on

end

end

end

hold off

%% Computing the stats analysis
save_values_stats_analysis(:,:,latency_to_be_removed) = [];

track_groups = 1;

anova.p_value = zeros(size(save_values_stats_analysis,1) - 2,size(save_values_stats_analysis,3));
anova.f_value = zeros(size(save_values_stats_analysis,1) - 2,size(save_values_stats_analysis,3));

for tt = 1:size(save_values_stats_analysis,1) - 2
 temp_group = zeros(2,size(save_values_stats_analysis,2));
   
    for gg = 1:size(save_values_stats_analysis,3)
    
        temp_group(1,:) = squeeze(save_values_stats_analysis(track_groups,:,gg));
        temp_group(2,:) = squeeze(save_values_stats_analysis(track_groups + 1,:,gg));
        
        %temp_group_reduced = temp_group(:,1:14);
        
    %[p_anova,table_anova,stats_anova] = anova1(temp_group_reduced');
[p_anova,table_anova,stats_anova] = anova1(temp_group');

    anova.p_value(tt,gg) = cell2mat(table_anova(2,6));
    anova.f_value (tt,gg) = cell2mat(table_anova(2,5));
    
    close
    close
    
    end

    track_groups = track_groups + 2;
    
end

equal_sign(1,1:length(norm_factor_plot)) = {'='};

figure
plot(norm_factor_plot,anova.p_value(1,:))

xlabel('\bfTime (ms)')
    ylabel('\bfP-value')
    title('\bfDA')
    
    text(norm_factor_plot(round(length(norm_factor_plot)/2) - 2),round(max(anova.p_value(1,:)))/2,num2str(norm_factor_plot'));
    text(norm_factor_plot(round(length(norm_factor_plot)/2) - 1),round(max(anova.p_value(1,:)))/2,equal_sign);
    text(norm_factor_plot(round(length(norm_factor_plot)/2)),round(max(anova.p_value(1,:)))/2,num2str(anova.p_value(1,:)'));
    
set(gca,'fontweight','bold')

saveas(gcf,'Anova_DA.fig')

figure
plot(norm_factor_plot,anova.p_value(2,:))
xlabel('\bfTime (ms)')
    ylabel('\bfP-value')
    title('\bfAH')
    
    text(norm_factor_plot(round(length(norm_factor_plot)/2) - 2),round(max(anova.p_value(2,:)))/2,num2str(norm_factor_plot'));
    text(norm_factor_plot(round(length(norm_factor_plot)/2) - 1),round(max(anova.p_value(2,:)))/2,equal_sign);
    text(norm_factor_plot(round(length(norm_factor_plot)/2)),round(max(anova.p_value(2,:)))/2,num2str(anova.p_value(2,:)'));
        
set(gca,'fontweight','bold')

saveas(gcf,'Anova_AH.fig')

save ('Anova_Values','anova')
xlswrite ('Anova_Values',anova.p_value,1);
xlswrite ('Anova_Values',anova.f_value,2);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%MANOVA Analysis
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%DA
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
young_da = squeeze(save_values_stats_analysis(1,:,:));
old_da = squeeze(save_values_stats_analysis(2,:,:));

%%Early
groups_early = {'early';'early';'early';'early';'early';'early';'early';'early';'early';'early';'early';'early';'early';'early';'early';...
    'early_old';'early_old';'early_old';'early_old';'early_old';'early_old';'early_old';'early_old';'early_old';'early_old';'early_old';'early_old';'early_old';'early_old';'early_old'};

matrix_early_da = zeros(size(temp_group,2)*2,4);

for tt = 1:30
    
    if (tt < 16)
    
      matrix_early_da(tt,:) = young_da(tt,2:5);
      
    else
       
        matrix_early_da(tt,:) = old_da(tt-size(matrix_early_da,1)/2,2:5);
        
    end
    
end

[d_da_early,p_da_early,stats] = manova1(matrix_early_da,groups_early);

%%Late
groups_late = {'late';'late';'late';'late';'late';'late';'late';'late';'late';'late';'late';'late';'late';'late';'late';...
    'late_old';'late_old';'late_old';'late_old';'late_old';'late_old';'late_old';'late_old';'late_old';'late_old';'late_old';'late_old';'late_old';'late_old';'late_old'};

matrix_late_da = zeros(size(temp_group,2)*2,5);

for tt = 1:30
    
    if (tt < 16)
    
      matrix_late_da(tt,:) = young_da(tt,6:10);
      
    else
       
        matrix_late_da(tt,:) = old_da(tt-size(matrix_late_da,1)/2,6:10);
        
    end
    
end

[d_da_late,p_da_late,stats] = manova1(matrix_late_da,groups_late);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%AH
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
young_ah = squeeze(save_values_stats_analysis(3,:,:));
old_ah = squeeze(save_values_stats_analysis(4,:,:));

%%Early
matrix_early_ah = zeros(size(temp_group,2)*2,4);

for tt = 1:30
    
    if (tt < 16)
    
      matrix_early_ah(tt,:) = young_ah(tt,2:5);
      
    else
       
        matrix_early_ah(tt,:) = old_ah(tt-size(matrix_early_ah,1)/2,2:5);
        
    end
    
end

[d_ah_early,p_ah_early,stats] = manova1(matrix_early_ah,groups_early);


%%Late
matrix_late_ah = zeros(size(temp_group,2)*2,5);

for tt = 1:30
    
    if (tt < 16)
    
      matrix_late_ah(tt,:) = young_ah(tt,6:10);
      
    else
       
        matrix_late_ah(tt,:) = old_ah(tt-size(matrix_late_ah,1)/2,6:10);
        
    end
    
end

[d_ah_late,p_ah_late,stats] = manova1(matrix_late_ah,groups_late);

figure
subplot(2,1,1)
stem(d_da_early,p_da_early)
hold on
stem(d_da_late,p_da_late,'r')

xlabel('\bfd value: no rejection (d = 0); rejection (d = 1)')
ylabel('\bfp value')

set(gca,'fontweight','bold')

title('\bfMANOVA results for DA')

legend((['p value Early = ' num2str(p_da_early)]),(['p value Late = ' num2str(p_da_late)]))
  
subplot(2,1,2)
stem(d_ah_early,p_ah_early)
hold on
stem(d_ah_late,p_ah_late,'r')

xlabel('\bfd value: no rejection (d = 0); rejection (d = 1)')
ylabel('\bfp value')

set(gca,'fontweight','bold')

title('\bfMANOVA results for AH')

legend((['p value Early = ' num2str(p_ah_early)]),(['p value Late = ' num2str(p_ah_late)]))

saveas(gcf,'MANOVA.fig')
