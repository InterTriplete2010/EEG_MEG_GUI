function varargout = Extract_Normalize_cABR_latencies_GUI(varargin)
% EXTRACT_NORMALIZE_CABR_LATENCIES_GUI MATLAB code for Extract_Normalize_cABR_latencies_GUI.fig
%      EXTRACT_NORMALIZE_CABR_LATENCIES_GUI, by itself, creates a new EXTRACT_NORMALIZE_CABR_LATENCIES_GUI or raises the existing
%      singleton*.
%
%      H = EXTRACT_NORMALIZE_CABR_LATENCIES_GUI returns the handle to a new EXTRACT_NORMALIZE_CABR_LATENCIES_GUI or the handle to
%      the existing singleton*.
%
%      EXTRACT_NORMALIZE_CABR_LATENCIES_GUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in EXTRACT_NORMALIZE_CABR_LATENCIES_GUI.M with the given input arguments.
%
%      EXTRACT_NORMALIZE_CABR_LATENCIES_GUI('Property','Value',...) creates a new EXTRACT_NORMALIZE_CABR_LATENCIES_GUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before Extract_Normalize_cABR_latencies_GUI_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to Extract_Normalize_cABR_latencies_GUI_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help Extract_Normalize_cABR_latencies_GUI

% Last Modified by GUIDE v2.5 15-Aug-2013 15:57:22

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Extract_Normalize_cABR_latencies_GUI_OpeningFcn, ...
                   'gui_OutputFcn',  @Extract_Normalize_cABR_latencies_GUI_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before Extract_Normalize_cABR_latencies_GUI is made visible.
function Extract_Normalize_cABR_latencies_GUI_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to Extract_Normalize_cABR_latencies_GUI (see VARARGIN)

% Choose default command line output for Extract_Normalize_cABR_latencies_GUI
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes Extract_Normalize_cABR_latencies_GUI wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = Extract_Normalize_cABR_latencies_GUI_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Extract and Normalize the cABR latencies 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in cABR_Latencies_Excel.
function cABR_Latencies_Excel_Callback(hObject, eventdata, handles)
% hObject    handle to cABR_Latencies_Excel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global IHS_file_directory_Young_DA;
global IHS_file_directory_Old_DA;
global IHS_file_directory_Young_AH;
global IHS_file_directory_Old_AH;

norm_factor = str2double(get(handles.Normalization_Factor_Peaks_Excel,'String'));

array_dir = [{IHS_file_directory_Young_DA} {IHS_file_directory_Old_DA} {IHS_file_directory_Young_AH} {IHS_file_directory_Old_AH}];

latency_to_be_removed = str2double(get(handles.Pos_Latency_Removed,'String'));

cABR_latencies_function(array_dir,norm_factor,latency_to_be_removed)

message = 'Latencies have been extracted and normalized';

        msgbox(message,'Analysis completed','warn');
        
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Choose the directory for Young AH
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Dir_excel_cABR_Young_AH_Callback(hObject, eventdata, handles)
% hObject    handle to Dir_excel_cABR_Young_AH (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Dir_excel_cABR_Young_AH as text
%        str2double(get(hObject,'String')) returns contents of Dir_excel_cABR_Young_AH as a double


% --- Executes during object creation, after setting all properties.
function Dir_excel_cABR_Young_AH_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Dir_excel_cABR_Young_AH (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Directory selected for Young AH
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in Upload_excel_cABR_Young_AH.
function Upload_excel_cABR_Young_AH_Callback(hObject, eventdata, handles)
% hObject    handle to Upload_excel_cABR_Young_AH (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global IHS_file_directory_Young_AH;

[IHS_file_selected_Young_AH,IHS_file_directory_Young_AH] = uigetfile('*.xls','Select the directory for Young AH');

set(handles.Dir_excel_cABR_Young_AH,'String',IHS_file_directory_Young_AH);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Normalization factor for the peaks
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Normalization_Factor_Peaks_Excel_Callback(hObject, eventdata, handles)
% hObject    handle to Normalization_Factor_Peaks_Excel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Normalization_Factor_Peaks_Excel as text
%        str2double(get(hObject,'String')) returns contents of Normalization_Factor_Peaks_Excel as a double


% --- Executes during object creation, after setting all properties.
function Normalization_Factor_Peaks_Excel_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Normalization_Factor_Peaks_Excel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Choose the directory for Old AH
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Dir_excel_cABR_Old_AH_Callback(hObject, eventdata, handles)
% hObject    handle to Dir_excel_cABR_Old_AH (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Dir_excel_cABR_Old_AH as text
%        str2double(get(hObject,'String')) returns contents of Dir_excel_cABR_Old_AH as a double


% --- Executes during object creation, after setting all properties.
function Dir_excel_cABR_Old_AH_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Dir_excel_cABR_Old_AH (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Directory selected for Old AH
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in Upload_excel_cABR_Old_AH.
function Upload_excel_cABR_Old_AH_Callback(hObject, eventdata, handles)
% hObject    handle to Upload_excel_cABR_Old_AH (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global IHS_file_directory_Old_AH;

[IHS_file_selected_Old_AH,IHS_file_directory_Old_AH] = uigetfile('*.xls','Select the directory for Old AH');

set(handles.Dir_excel_cABR_Old_AH,'String',IHS_file_directory_Old_AH);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Choose the directory for Young DA
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Dir_excel_cABR_Young_DA_Callback(hObject, eventdata, handles)
% hObject    handle to Dir_excel_cABR_Young_DA (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Dir_excel_cABR_Young_DA as text
%        str2double(get(hObject,'String')) returns contents of Dir_excel_cABR_Young_DA as a double


% --- Executes during object creation, after setting all properties.
function Dir_excel_cABR_Young_DA_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Dir_excel_cABR_Young_DA (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Directory selected for Young DA
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in Upload_excel_cABR_Young_DA.
function Upload_excel_cABR_Young_DA_Callback(hObject, eventdata, handles)
% hObject    handle to Upload_excel_cABR_Young_DA (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global IHS_file_directory_Young_DA;

[IHS_file_selected_Young_DA,IHS_file_directory_Young_DA] = uigetfile('*.xls','Select the directory for Young DA');

set(handles.Dir_excel_cABR_Young_DA,'String',IHS_file_directory_Young_DA);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Choose the directory for Old DA
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Dir_excel_cABR_Old_DA_Callback(hObject, eventdata, handles)
% hObject    handle to Dir_excel_cABR_Old_DA (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Dir_excel_cABR_Old_DA as text
%        str2double(get(hObject,'String')) returns contents of Dir_excel_cABR_Old_DA as a double


% --- Executes during object creation, after setting all properties.
function Dir_excel_cABR_Old_DA_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Dir_excel_cABR_Old_DA (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Directory selected for Old DA
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in Upload_excel_cABR_Old_DA.
function Upload_excel_cABR_Old_DA_Callback(hObject, eventdata, handles)
% hObject    handle to Upload_excel_cABR_Old_DA (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global IHS_file_directory_Old_DA;

[IHS_file_selected_Old_DA,IHS_file_directory_Old_DA] = uigetfile('*.xls','Select the directory for Old DA');

set(handles.Dir_excel_cABR_Old_DA,'String',IHS_file_directory_Old_DA);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Position of the latency to be removed
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Pos_Latency_Removed_Callback(hObject, eventdata, handles)
% hObject    handle to Pos_Latency_Removed (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Pos_Latency_Removed as text
%        str2double(get(hObject,'String')) returns contents of Pos_Latency_Removed as a double


% --- Executes during object creation, after setting all properties.
function Pos_Latency_Removed_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Pos_Latency_Removed (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
