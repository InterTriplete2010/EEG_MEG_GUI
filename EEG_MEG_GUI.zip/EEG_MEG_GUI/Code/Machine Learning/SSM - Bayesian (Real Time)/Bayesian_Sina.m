function varargout = Bayesian_Sina(varargin)
% BAYESIAN_SINA MATLAB code for Bayesian_Sina.fig
%      BAYESIAN_SINA, by itself, creates a new BAYESIAN_SINA or raises the existing
%      singleton*.
%
%      H = BAYESIAN_SINA returns the handle to a new BAYESIAN_SINA or the handle to
%      the existing singleton*.
%
%      BAYESIAN_SINA('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in BAYESIAN_SINA.M with the given input arguments.
%
%      BAYESIAN_SINA('Property','Value',...) creates a new BAYESIAN_SINA or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before Bayesian_Sina_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to Bayesian_Sina_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help Bayesian_Sina

% Last Modified by GUIDE v2.5 02-Oct-2018 14:07:40

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Bayesian_Sina_OpeningFcn, ...
                   'gui_OutputFcn',  @Bayesian_Sina_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before Bayesian_Sina is made visible.
function Bayesian_Sina_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to Bayesian_Sina (see VARARGIN)

% Choose default command line output for Bayesian_Sina
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes Bayesian_Sina wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = Bayesian_Sina_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%EEG/MEG data uploaded
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Data_Bayesian_Callback(hObject, eventdata, handles)
% hObject    handle to Data_Bayesian (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Data_Bayesian as text
%        str2double(get(hObject,'String')) returns contents of Data_Bayesian as a double


% --- Executes during object creation, after setting all properties.
function Data_Bayesian_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Data_Bayesian (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Upload EEG/MEG data
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in Upload_Data_Bayesian.
function Upload_Data_Bayesian_Callback(hObject, eventdata, handles)
% hObject    handle to Upload_Data_Bayesian (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Foreground uploaded
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Foreground_Uploaded_Bayesian_Callback(hObject, eventdata, handles)
% hObject    handle to Foreground_Uploaded_Bayesian (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Foreground_Uploaded_Bayesian as text
%        str2double(get(hObject,'String')) returns contents of Foreground_Uploaded_Bayesian as a double


% --- Executes during object creation, after setting all properties.
function Foreground_Uploaded_Bayesian_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Foreground_Uploaded_Bayesian (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Upload Foreground 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in Upload_Foreground_Bayesian.
function Upload_Foreground_Bayesian_Callback(hObject, eventdata, handles)
% hObject    handle to Upload_Foreground_Bayesian (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Background uploaded
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Background_Uploaded_Bayesian_Callback(hObject, eventdata, handles)
% hObject    handle to Background_Uploaded_Bayesian (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Background_Uploaded_Bayesian as text
%        str2double(get(hObject,'String')) returns contents of Background_Uploaded_Bayesian as a double


% --- Executes during object creation, after setting all properties.
function Background_Uploaded_Bayesian_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Background_Uploaded_Bayesian (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Upload Background 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in Upload_Background_Bayesian.
function Upload_Background_Bayesian_Callback(hObject, eventdata, handles)
% hObject    handle to Upload_Background_Bayesian (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Estimate the probability
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in Bayesian_Inference.
function Bayesian_Inference_Callback(hObject, eventdata, handles)
% hObject    handle to Bayesian_Inference (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
