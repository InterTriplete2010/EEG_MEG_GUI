function [curr_state Delta_1 Delta_2 Delta_3] = HMM_Real_Time(yy_raw,loop,Delta_1_Temp,Delta_2_Temp,Delta_3_Temp,temp_xx)
%yy_raw = yy_data;
%y_hmm_smooth = smooth([1:length(yy_raw(1:4))],yy_raw(1:4),0.15,'loess');
% figure
% plot(temp_xx,y_hmm_smooth)
% hold on
% plot(temp_xx,yy_raw)

%yy = y_hmm_smooth';
state_I_t = 3*10^-5;%Threshold for different states

%Probabilities
tran_matr = [0.8,0.1,0.1;0.15,0.8,0.05;0.15,0.05,0.8];    %Transition matrix

%Conditional probabilities
P_R = [0.7,0.15,0.15];
P_P = [0.25,0.7,0.05];
P_N = [0.25,0.05,0.7];

%Prior probability
pi_1 = 0.6;
pi_2 = 0.2;
pi_3 = 0.2;

curr_state = [];

if loop == 1
%Initialize the Viterbi algorithm based on the assumption that the system
%is in state 1
Delta_1 = P_R(1)*pi_1; 
Delta_2 = P_R(2)*pi_2;
Delta_3 = P_R(3)*pi_3;

%temp_val = 3*10^-7;
%yy = yy_raw(loop);

curr_state = find(max([Delta_1 Delta_2 Delta_3]) == [Delta_1 Delta_2 Delta_3]);
else

yy = smooth([1:length(yy_raw(1:loop))],yy_raw(1:loop),0.25,'loess')';
temp_val = diff(yy(loop - 1:loop)); %Take the derivative

      
 %Check to which group the derivative should belong to based on the
 %threshold
 
 if temp_val >= 0
 
   if (temp_val <= state_I_t)
       
       
       Delta_1 = P_R(1)*max([tran_matr(1,1)*Delta_1_Temp tran_matr(2,1)*Delta_2_Temp tran_matr(3,1)*Delta_3_Temp]);
       Delta_2 = P_R(2)*max([tran_matr(1,2)*Delta_1_Temp tran_matr(2,2)*Delta_2_Temp tran_matr(3,2)*Delta_3_Temp]);
       Delta_3 = P_R(3)*max([tran_matr(1,3)*Delta_1_Temp tran_matr(2,3)*Delta_2_Temp tran_matr(3,3)*Delta_3_Temp]);
       
       curr_state = find(max([Delta_1 Delta_2 Delta_3]) == [Delta_1 Delta_2 Delta_3]);
       
   else
       
       Delta_1 = P_P(1)*max([tran_matr(1,1)*Delta_1_Temp tran_matr(2,1)*Delta_2_Temp tran_matr(3,1)*Delta_3_Temp]);
       Delta_2 = P_P(2)*max([tran_matr(1,2)*Delta_1_Temp tran_matr(2,2)*Delta_2_Temp tran_matr(3,2)*Delta_3_Temp]);
       Delta_3 = P_P(3)*max([tran_matr(1,3)*Delta_1_Temp tran_matr(2,3)*Delta_2_Temp tran_matr(3,3)*Delta_3_Temp]);
       
       curr_state = find(max([Delta_1 Delta_2 Delta_3]) == [Delta_1 Delta_2 Delta_3]);
    
   end
   
 else
     if (abs(temp_val) <= state_I_t)
       
       
       Delta_1 = P_R(1)*max([tran_matr(1,1)*Delta_1_Temp tran_matr(2,1)*Delta_2_Temp tran_matr(3,1)*Delta_3_Temp]);
       Delta_2 = P_R(2)*max([tran_matr(1,2)*Delta_1_Temp tran_matr(2,2)*Delta_2_Temp tran_matr(3,2)*Delta_3_Temp]);
       Delta_3 = P_R(3)*max([tran_matr(1,3)*Delta_1_Temp tran_matr(2,3)*Delta_2_Temp tran_matr(3,3)*Delta_3_Temp]);
       
       curr_state = find(max([Delta_1 Delta_2 Delta_3]) == [Delta_1 Delta_2 Delta_3]);
       
   else
           
       Delta_1 = P_N(1)*max([tran_matr(1,1)*Delta_1_Temp tran_matr(2,1)*Delta_2_Temp tran_matr(3,1)*Delta_3_Temp]);
       Delta_2 = P_N(2)*max([tran_matr(1,2)*Delta_1_Temp tran_matr(2,2)*Delta_2_Temp tran_matr(3,2)*Delta_3_Temp]);
       Delta_3 = P_N(3)*max([tran_matr(1,3)*Delta_1_Temp tran_matr(2,3)*Delta_2_Temp tran_matr(3,3)*Delta_3_Temp]);
       
       curr_state = find(max([Delta_1 Delta_2 Delta_3]) == [Delta_1 Delta_2 Delta_3]);
       
   end
    
 end

end
