ss = zeros(1,101);
ss([10 40]) = 1e-3;
ss(20) = -1e-3;
figure
subplot(3,1,1)
fs = 200;
tt = [0:length(ss)-1]/fs;
stem(tt,ss)

sigma = 0.1;
xx = [-1:0.02:1];
gauss_func = [1/(sqrt(2*pi)*sigma)]*exp(-((xx.^2)./(2*(sigma.^2))));
shift_wind = circshift(gauss_func,-30);
subplot(3,1,2)
plot(xx,gauss_func)
hold on
plot(xx,shift_wind,'r')
hold off

filt_data = filter(shift_wind,1,ss);
subplot(3,1,3)
plot(tt,filt_data)
hold on
shift_filt_data = circshift(filt_data,-18);
plot(tt,shift_filt_data)
hold off
