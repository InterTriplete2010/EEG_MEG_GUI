% This file reproduces the simulation results of case 2 in Figure 4 of the
% paper "Real-Time Tracking of Selective Auditory Attention from M/EEG: A 
% Bayesian Filtering Approach" by Miran et al. The parameters are set as 
% explained in the paper. This code uses the fasta.m function available in
% FASTA package [1] for implementing the Forward-Backward Splitting method,
% which has been included in the folder for convenience.

% [1] https://www.cs.umd.edu/~tomg/projects/fasta/

%% Constructing the Auditory Response through the Forward Model

% Fixing the SF to 200 Hz
fs = 200; % sampling rate

%Upload the waveforms files
[FileName_Foreground,PathName_Foreground] = uigetfile('*.wav','Select the Target speech');

cd(PathName_Foreground)
[Target_talker Freq_TT] = audioread(FileName_Foreground);

[FileName_Background,PathName_Background] = uigetfile('*.wav','Select the Background speech');

cd(PathName_Background)
[Background_talker Freq_BT] = audioread(FileName_Background);

%Extract the envelope and resample the data down to 200 Hz
Target_talker_env = abs(hilbert(Target_talker));
Background_talker_env = abs(hilbert(Background_talker));

%Filter the speech
[b_env,a_env] = butter(2,[1 8]/(Freq_TT/2)); 

Target_talker_env_filt = filter(b_env,a_env,Target_talker_env);
Background_talker_env_filt = filter(b_env,a_env,Background_talker_env);

%Downsample the speech
env(:,1) = resample(Target_talker_env_filt(:,1),fs,Freq_TT);
env(:,2) = resample(Background_talker_env_filt(:,1),fs,Freq_TT);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Upload the dir with the mat files
folder_name = uigetdir;
cd(folder_name)
curr_dir = what;
track_sub = 0;

for kk = 1:length(curr_dir.mat)
  X = [];
  cov = [];
  
  track_sub = track_sub + 1;
  
temp_file = cell2mat(curr_dir.mat(kk))
    dss_data = load(temp_file);
 
    check_sensors = 0;  %These lines of code have been added to handle the situation where the first DSS has null values (vector of zeros)
    track_DSS = 3;  %Use only the first DSS
    
    while (check_sensors == 0)

        temp_dss = squeeze(dss_data.data_exported.dss(:,track_DSS,:));

        track_DSS = track_DSS + 1;
    check_sensors = sum(mean(temp_dss')');
    end
    
    %temp_dss_mean = mean(temp_dss')';
    trial = 3;
    temp_dss_mean = temp_dss(:,trial);  %Use only the first trial of the first DSS

%Filter for the DSS    
if kk == 1
    
 [b_dss,a_dss] = butter(2,[1 8]/(dss_data.data_exported.sampling_frequency/2)); 

end

temp_dss_mean_filt = filter(b_dss,a_dss,temp_dss_mean);
dss_resampled = [];

%Downsample the DSS
for mm = 1:size(temp_dss_mean_filt,2)
    
dss_resampled(:,mm) = resample(temp_dss_mean_filt(:,mm),fs,dss_data.data_exported.sampling_frequency);

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Real-Time Decoding of the Attentional State from the Auditory Response
% setting the decoder estimation parameters
if kk == 1
TRF_length = 0.3;

T = 90*fs; % trial length
L = floor(TRF_length*fs)+1; % decoder lag
T = T-L+1; % effective data length for estimation
W = floor(0.25*fs); % considering consecutive windows of length 250ms
K = floor(T/W); % number of windows, i.e. instances
c = 1e-1;   %Constant used to initialize the covariance matrix

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Kernel with Gaussian windows
% sep = 0.05; % separation of Gaussian kernels
% sig_ker = 0.008^2; % variance of Gaussian kernels
% 
% d_TRF = TRF_length*fs; % original TRF dimension
% d_c = TRF_length/sep; % reduced dimension

% creating kernel
% ind = (0:TRF_length*fs)/fs;
% ind = ind';
% ker = zeros(d_TRF + 1,d_c);
% for i = 1:d_c
%     ker(:,i) = exp(-((ind - (i-1)*sep).^2)/(2*sig_ker));
% end
% 
% ker_temp = ker/max(max(ker));
% ker_final = [ker_temp;zeros(1,size(ker_temp,2))]; 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

end

% setting the parameters of FASTA package for efficient FBS implementation
% (algorithm 1 from the supplemental material)

for oo = 7:7
    lambda = 1 - W/(10*fs) % forgetting factor 
gamma_var = 10^7*1e-10*1; % l1 regularization parameter (oo = 3 => 10^-3)
g = @(x) norm(x,1)*gamma_var;   %This is the regularization parameter
proxg = @(x,t) sign(x).*max(abs(x) - t*gamma_var,0);     %t = step size; see algorithm 1 in supplemental material. proxg returns the theta value
opts = [];
opts.maxIters = 1000;
opts.tol = 1e-3;
opts.verbose = false;
opts.accelerate = true; %Accelerate the convergence of the FASTA algorithm based on the FISTA algorithm
opts.adaptive = false;
opts.restart = true;
opts.stringHeader='    ';

Y = [];
Y = dss_resampled;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Time-shift the speech waveforms to look at different lags
X1 = [];
X2 = [];
for kk = L:-1:1
   
    temp_env_1 = circshift(env(:,1),round(kk - 1));
    X1(:,kk) = temp_env_1(1:size(env,1) - L + 1);
    
    temp_env_2 = circshift(env(:,2),round(kk - 1));
    X2(:,kk) = temp_env_2(1:size(env,1) - L + 1);
    
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%This is the X matrix in equation S2. "c" is for the initialization
cov1 = [c*ones(T,1) X1];
cov2 = [c*ones(T,1) X2];

% %Filter the data with the kernel
% temp_ker_1 = zeros(size(cov1,1),size(cov1,2));
% temp_ker_2 = zeros(size(cov1,1),size(cov1,2));
% for mm = 1:size(ker_final,2)
%   
%     temp_ker_1 = temp_ker_1 + filter(ker_final(:,mm),1,cov1);
%     temp_ker_2 = temp_ker_2 + filter(ker_final(:,mm),1,cov2);
%         
% end

cov_conc = [];
cov_conc = [cov1 cov2]; %The two speech envelopes are concatenated to have FASTA find the optimal solution. 
%cov_conc = [temp_ker_1 temp_ker_2];

Dec_conc = zeros(2*(L + 1),K);

%Matrix and vector of the foreground recursively upadted for the f(x) function of the
%Forward-Backward Splitting
A_conc = zeros(2*(L + 1),2*(L + 1));
b_conc = zeros(1,2*(L + 1));

% variables for storing attentional marker outputs
m1 = zeros(K,1) + 1e-7; % l1-based attentional marker outputs for speaker 1
m2 = zeros(K,1) + 1e-7; % l1-based attentional marker outputs for speaker 2



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Run FASTA for each of windows selected
start_m1_m2 = round(0.08*fs);
end_m1_m2 = round(0.25*fs);

m2_offset = size(A_conc,1)/2;
for k = 1:K
    % estimating the decoder coefficients at instance k through FBS
    A_conc = lambda*A_conc + cov_conc((k-1)*W+1:k*W,:)'*cov_conc((k-1)*W+1:k*W,:);
    b_conc = lambda*b_conc + Y((k-1)*W+1:k*W)'*cov_conc((k-1)*W+1:k*W,:);
    %These are the equations for algorithm 1
%     A1 = lambda*A1 + cov1((k-1)*W+1:k*W,:)'*cov1((k-1)*W+1:k*W,:);
%     b1 = lambda*b1 + Y((k-1)*W+1:k*W)'*cov1((k-1)*W+1:k*W,:);
%     
%     A2 = lambda*A2 + cov2((k-1)*W+1:k*W,:)'*cov2((k-1)*W+1:k*W,:);
%     b2 = lambda*b2 + Y((k-1)*W+1:k*W)'*cov2((k-1)*W+1:k*W,:);
    
    if k == 1
%         init1 = zeros(L + 1,1);
%         init2 = zeros(L + 1,1);
        init_conc = zeros(2*(L + 1),1);
        
    else
         %init1 = Dec1(:,k-1);
         %init2 = Dec2(:,k-1);
        init_conc = Dec_conc(:,k-1);
    end
    
%     [Dec1(:,k),~] = fasta( @(x) x, @(x) x, @(x) x'*A1*x-2*b1*x, @(x) 2*A1*x-2*b1', g, proxg, init1, opts);
%     [Dec2(:,k),~] = fasta( @(x) x, @(x) x, @(x) x'*A2*x-2*b2*x, @(x) 2*A2*x-2*b2', g, proxg, init2, opts);
[Dec_conc(:,k),~] = fasta( @(x) x, @(x) x, @(x) x'*A_conc*x-2*b_conc*x, @(x) 2*A_conc*x-2*b_conc', g, proxg, init_conc, opts);

%Smoothing up the peaks before extracting the max value
temp_m1 = abs(Dec_conc(start_m1_m2:end_m1_m2,k));
sgf1 = sgolayfilt(temp_m1,4,9)';
m1(k) = max(max(sgf1),1e-7);

temp_m2 = abs(Dec_conc(m2_offset + start_m1_m2:m2_offset + end_m1_m2,k));
sgf2 = sgolayfilt(temp_m2,4,9)';
m2(k) = max(max(sgf2),1e-7);


    % calculating the attentional marker outputs at instance k for each speaker 
%     m1(k) = max(norm(Dec_conc(start_m1_m2:end_m1_m2,k),1) , 1e-7); %Calculate the biomarker in the specified range of time for the foreground
%     m2(k) = max(norm(Dec_conc(m2_offset + start_m1_m2:m2_offset + end_m1_m2,k),1) , 1e-7);  %Calculate the biomarker in the specified range of time for the background
        
   
end

lim1 = 0.4*max(max(abs([Dec_conc(2:m2_offset,ceil(8*fs/W):end) Dec_conc(2:m2_offset,ceil(8*fs/W):end)])));
fig = figure('pos',[100 100 800 600]);
subplot(2,1,1)
imagesc((1:K)*W/fs,(0:L-1)/fs,-Dec_conc(2:m2_offset,:),[-lim1,lim1])
colorbar;
title('Estimated decoder for attended speaker')
ylabel('decoder lag (s)')
xlabel('trial time (s)')
subplot(2,1,2)
imagesc((1:K)*W/fs,(0:L-1)/fs,-Dec_conc(m2_offset + 2:end,:),[-lim1,lim1])
colorbar;
title('Estimated decoder for unattended speaker')
ylabel('decoder lag (s)')
xlabel('trial time (s)')

saveas(gcf,[temp_file(1:end-4) '_' num2str(trial) '.fig'])
end
%saveas(gcf,'Decoder.fig')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Estimate the parameters for the LogNorm, Gamma and the Gaussian distributions
%M100
m1_norm = m1([104:172 324:344]);    %120 = 30 seconds worth of data
m2_norm = m2([104:172 324:344]);

%Use this chunck of code only for the 3 state
m1_norm_temp = abs(m1-m2);
figure
subplot(2,1,1)
plot((1:K)*W/fs,m1_norm_temp)

subplot(2,1,2)
m1_norm = abs(m1_norm - m2_norm);
plot([104:172 324:344]*W/fs,m1_norm)

figure
subplot(2,1,1)
plot((1:K)*W/fs,m1)
hold on
plot((1:K)*W/fs,m2)
hold off
title('Whole response')

subplot(2,1,2)
plot([104:172 324:344]*W/fs,m1_norm)
hold on
plot([104:172 324:344]*W/fs,m2_norm)
hold off
title('Response for the prior')

legend('Foreground','Background')
saveas(gcf,[temp_file(1:end-4) 'M1_M2_' num2str(trial) '.fig'])

start_t = 1;
end_t = 27;
step_size = 27;
rho_1_log_norm = [];
mu_a_log_norm = [];
for par_m1 = 1:floor(length(m1_norm)/step_size)
   
    const_c_1 = exp(2*log(mean(m1_norm(start_t:end_t)))) + var(m1_norm(start_t:end_t));
rho_1_log_norm(par_m1) = log(const_c_1) - 2*log(mean(m1_norm(start_t:end_t)));
mu_a_log_norm(par_m1) = log(mean(m1_norm(start_t:end_t))) - rho_1_log_norm(kk)/2;

  start_t = start_t + step_size;
  end_t = end_t + step_size;

end

mu_a_log_norm_mean = mean(mu_a_log_norm);
rho_1_log_norm_mean = var(rho_1_log_norm);
mu_a_log_rho_mean = mean(rho_1_log_norm);

const_c_1 = exp(2*log(mean(m1_norm))) + var(m1_norm);
rho_1_log_norm_batch = log(const_c_1) - 2*log(mean(m1_norm));
mu_a_log_norm_batch = log(mean(m1_norm)) - rho_1_log_norm_batch/2;

start_t = 1;
end_t = 27;
step_size = 27;
rho_2_log_norm = [];
mu_u_log_norm = [];

for par_m2 = 1:floor(length(m2_norm)/step_size)
   
    const_c_2 = exp(2*log(mean(m2_norm(start_t:end_t)))) + var(m2_norm(start_t:end_t));
rho_2_log_norm(par_m2) = log(const_c_2) - 2*log(mean(m2_norm(start_t:end_t)));
mu_u_log_norm(par_m2) = log(mean(m2_norm(start_t:end_t))) - rho_2_log_norm(kk)/2;

  start_t = start_t + step_size;
  end_t = end_t + step_size;

end

mu_u_log_norm_mean = mean(mu_u_log_norm);
rho_2_log_norm_mean = var(rho_2_log_norm);
mu_u_log_rho_mean = mean(rho_2_log_norm);

const_c_2 = exp(2*log(mean(m2_norm))) + var(m2_norm);
rho_2_log_norm_batch = log(const_c_2) - 2*log(mean(m2_norm));
mu_u_log_norm_batch = log(mean(m2_norm)) - rho_2_log_norm_batch/2;


log_norm_a = [1./(sort(m1_norm).*0.5.*sqrt(2*pi))].*exp((-[log(sort(m1_norm)) - mu_a_log_norm_mean].^2)./(2*(rho_1_log_norm_batch.^2)));
log_norm_u = [1./(sort(m2_norm).*0.5.*sqrt(2*pi))].*exp((-[log(sort(m2_norm)) - mu_u_log_norm_batch].^2)./(2*(rho_2_log_norm_batch.^2)));

figure
plot(sort(m1_norm),log_norm_a)
hold on
plot (sort(m2_norm),log_norm_u)
hold off

title('Log-Norm distributions')
legend('Attended','Unattended')

save_par = {zeros(1,8)};
save_par(1,1) = {'Alpha_A'};
save_par(1,2) = {'Alpha_A_Val'};
save_par(1,3) = {'Beta_A'};
save_par(1,4) = {'Beta_A_Val'};
save_par(1,5) = {'Mu_A'};
save_par(1,6) = {'Rho_A'};
save_par(1,7) = {'Mean_M1'};

save_par(1,8) = {'Alpha_U'};
save_par(1,9) = {'Alpha_U_Val'};
save_par(1,10) = {'Beta_U'};
save_par(1,11) = {'Beta_U_Val'};
save_par(1,12) = {'Mu_U'};
save_par(1,13) = {'Rho_U'};
save_par(1,14) = {'Mean_M2'};

beta_a_100 = mu_a_log_rho_mean/(rho_1_log_norm_mean);
save_par(2,3) = {beta_a_100};
beta_u_100 = mu_u_log_rho_mean/(rho_2_log_norm_mean);
save_par(2,10) = {beta_u_100};
alpha_a_100 = (beta_a_100.^2)*(rho_1_log_norm_mean);
save_par(2,1) = {alpha_a_100};
alpha_u_100 = (beta_u_100.^2)*(rho_2_log_norm_mean);
save_par(2,8) = {alpha_u_100};

save_par(2,5) = {mu_a_log_norm_mean};
save_par(2,6) = {rho_1_log_norm_batch};
save_par(2,7) = {mu_a_log_norm_batch};
save_par(2,2) = {[beta_a_100.^2 rho_1_log_norm_mean]};
save_par(2,4) = {[mu_a_log_rho_mean rho_1_log_norm_mean]};

save_par(2,12) = {mu_u_log_norm_mean};
save_par(2,13) = {rho_2_log_norm_batch};
save_par(2,9) = {[beta_u_100.^2 rho_2_log_norm_mean]};
save_par(2,11) = {[mu_u_log_rho_mean rho_2_log_norm_mean]};
save_par(2,14) = {mu_u_log_norm_batch};

save('Forward_Hyper_Parameters.mat','save_par')
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
