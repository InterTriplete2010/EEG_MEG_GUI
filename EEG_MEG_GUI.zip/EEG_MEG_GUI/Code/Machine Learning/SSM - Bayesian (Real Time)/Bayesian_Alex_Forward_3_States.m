% This file reproduces the simulation results of case 2 in Figure 4 of the
% paper "Real-Time Tracking of Selective Auditory Attention from M/EEG: A 
% Bayesian Filtering Approach" by Miran et al. The parameters are set as 
% explained in the paper. This code uses the fasta.m function available in
% FASTA package [1] for implementing the Forward-Backward Splitting method,
% which has been included in the folder for convenience.

% [1] https://www.cs.umd.edu/~tomg/projects/fasta/

%% Constructing the Auditory Response through the Forward Model

% Fixing the SF to 200 Hz
fs = 200; % sampling rate

%Upload the waveforms files
[FileName_Foreground,PathName_Foreground] = uigetfile('*.wav','Select the Target speech');

cd(PathName_Foreground)
[Target_talker Freq_TT] = audioread(FileName_Foreground);

[FileName_Background,PathName_Background] = uigetfile('*.wav','Select the Background speech');

cd(PathName_Background)
[Background_talker Freq_BT] = audioread(FileName_Background);

%Extract the envelope and resample the data down to 200 Hz
Target_talker_env = abs(hilbert(Target_talker));
Background_talker_env = abs(hilbert(Background_talker));

%Filter the speech
[b_env,a_env] = butter(2,[1 8]/(Freq_TT/2)); 

Target_talker_env_filt = filter(b_env,a_env,Target_talker_env);
Background_talker_env_filt = filter(b_env,a_env,Background_talker_env);

%Downsample the speech
env(:,1) = resample(Target_talker_env_filt(:,1),fs,Freq_TT);
env(:,2) = resample(Background_talker_env_filt(:,1),fs,Freq_TT);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Upload the dir with the mat files
folder_name = uigetdir;
cd(folder_name)
curr_dir = what;
track_sub = 0;

triggers_button = [14,33.8000000000000,0;22.7000000000000,47.5000000000000,66.4000000000000;27,55.7000000000000,0;15.2000000000000,46.8000000000000,0;61.8000000000000,87.7000000000000,0;26.3000000000000,0,0;6.70000000000000,23.7000000000000,49.2000000000000;35.6000000000000,0,0;15,42.4000000000000,0;9.40000000000000,21.6000000000000,53.8000000000000;27.9000000000000,67,0;6.80000000000000,26.8000000000000,75.2000000000000];
%triggers_button =[30 60 70;30 60 70;30 60 70;30 60 70;30 60 70;30 60 70;30 60 70;30 60 70;30 60 70;30 60 70;30 60 70;30 60 70];
%triggers_button =[45 0 0;45 0 0;45 0 0;45 0 0;45 0 0;45 0 0;45 0 0;45 0 0;45 0 0;45 0 0;45 0 0;45 0 0;];
track_trigg_button = 1;

for kk = 1:length(curr_dir.mat)
  X = [];
  cov = [];
  
  track_sub = track_sub + 1;
  
temp_file = cell2mat(curr_dir.mat(kk))
    dss_data = load(temp_file);
 
    check_sensors = 0;  %These lines of code have been added to handle the situation where the first DSS has null values (vector of zeros)
    track_DSS = 1;  %Use only the first DSS
    
    while (check_sensors == 0)

        temp_dss = squeeze(dss_data.data_exported.dss(:,track_DSS,:));

        track_DSS = track_DSS + 1;
    check_sensors = sum(mean(temp_dss')');
    end
    
    %temp_dss_mean = mean(temp_dss')';
    for trial = 1:3
    trial
    temp_dss_mean = temp_dss(:,trial);  %Use only the first trial of the first DSS

%Filter for the DSS    
if kk == 1
    
 [b_dss,a_dss] = butter(2,[1 8]/(dss_data.data_exported.sampling_frequency/2)); 

 
end

temp_dss_mean_filt = filter(b_dss,a_dss,temp_dss_mean);
dss_resampled = [];

%Downsample the DSS
for mm = 1:size(temp_dss_mean_filt,2)
    
dss_resampled(:,mm) = resample(temp_dss_mean_filt(:,mm),fs,dss_data.data_exported.sampling_frequency);

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Real-Time Decoding of the Attentional State from the Auditory Response
% setting the decoder estimation parameters
if kk == 1

T = 90*fs; % trial length
L = floor(0.5*fs)+1; % decoder lag
T = T-L+1; % effective data length for estimation
W = floor(0.5*fs); % considering consecutive windows of length 250ms
K = floor(T/W); % number of windows, i.e. instances
c = 1e-1;   %Constant used to initialize the covariance matrix

% %% Build the TRF with a Gaussian Filter
% TRF = zeros(1,L);
% TRF([10 40]) = 1;
% TRF(20) = -1;
% tt = [0:length(TRF)-1]/fs;
% 
% sigma = 0.1;
% xx = [-1:0.02:1];
% gauss_func = [1/(sqrt(2*pi)*sigma)]*exp(-((xx.^2)./(2*(sigma.^2))));
% shift_TRF = circshift(gauss_func,-30);
% filt_TRF = filter(shift_TRF,1,TRF);
% shift_filt_TRF = circshift(filt_TRF,-18);
% % figure
% % plot(tt,shift_filt_TRF)

end

% setting the parameters of the dynamic state-space models
outer_EM_dynamic = 20;
inner_EM_dynamic = 1;
Newton_iter = 10;

c0 = 1.65; % for %90 confidence intervals

% parameters of the inverse-gamma prior on state-space variances
mean_p = 0.2;
var_p = 5;
a_0 = 2 + mean_p^2/var_p; %Standard way to calculate the alpha value
b_0 = mean_p*(a_0-1);   %Standard way to calculate the beta value

% parameters of the fixed-lag sliding window
K_F = floor(1.5*fs/W); % forward-lag (number of segments for the forward lag)
K_B = floor(13.5*fs/W); % backward_lag (number of segments for the backward lag)
%K_B = floor(10*fs/W); % backward_lag (number of segments for the backward lag)
K_W = K_F + K_B + 1; % window-length (decoding windows move with overlapping lags)
lambda_state = 0.999;    %This is the c0 in the supplemental material. zk = c0*z(k-1) + wk

% dynamic state-space model outputs for the two attentional markers
z_dyn_l = zeros(K,1); % _l: l1_based
eta_dyn_l = zeros(K,1);

z_smoothed_l = zeros(K,1);
eta_smoothed_l = 0.3*ones(K,1); %This is just an inizialization parameter for the variance of the inverse gamma. you just need a small number

% Kalman filtering and smoothing variables
z_k_k_l = zeros(K_W+1,1);
z_k_k_1_l = zeros(K_W+1,1);
sig_k_k_l = zeros(K_W+1,1);
sig_k_k_1_l = zeros(K_W+1,1);

z_k_K_c = zeros(K_W+1,1);
sig_k_K_c = zeros(K_W+1,1);
z_k_K_l = zeros(K_W+1,1);
sig_k_K_l = zeros(K_W+1,1);

S_l = zeros(K_W,1);

% tuned attended and unattended prior distributions based on a similar trial
alpha_0_l = [169 911 69];%[4.2e+3;2.27e+4];  [2e+3 1.11e+4]
beta_0_l = [108 89 372];%[540;447];  [378 313]

mu_0_l = [-6.32;-8.08;-7.9];

% alpha_0_l = [251 333];
% beta_0_l = [256 216];
% mu_0_l = [-6.3;-7];

% initialized attended and unattended Log-Normal distribution parameters
% based on a similar trial
rho_d_0_l = [0.08;0.7;0.35];
mu_d_0_l = [-6.32;-8.08;-7.9];
% rho_d_0_l = [0.18;0.4];
% mu_d_0_l = [-6.3;-7];

rho_d_l = rho_d_0_l;
mu_d_l = mu_d_0_l;


% setting the parameters of FASTA package for efficient FBS implementation
% (algorithm 1 from the supplemental material)
    lambda = 1 - W/(10*fs); % forgetting factor 
gamma_var = 10^7*1e-10*1; % l1 regularization parameter (oo = 3 => 10^-3)
g = @(x) norm(x,1)*gamma_var;   %This is the regularization parameter
proxg = @(x,t) sign(x).*max(abs(x) - t*gamma_var,0);     %t = step size; see algorithm 1 in supplemental material. proxg returns the theta value
opts = [];
opts.maxIters = 1000;
opts.tol = 1e-3;    %Use 1e-2 for Backward model to speed up the algorithm
opts.verbose = false;
opts.accelerate = true; %Accelerate the convergence of the FASTA algorithm based on the FISTA algorithm
opts.adaptive = false;
opts.restart = true;
opts.stringHeader='    ';

Y = [];
Y = dss_resampled;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Time-shift the speech waveforms to look at different lags
X1 = [];
X2 = [];
for kk = L:-1:1
   
    temp_env_1 = circshift(env(:,1),round(kk - 1));
    X1(:,kk) = temp_env_1(1:size(env,1) - L + 1);
    
    temp_env_2 = circshift(env(:,2),round(kk - 1));
    X2(:,kk) = temp_env_2(1:size(env,1) - L + 1);
    
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%This is the X matrix in equation S2. "c" is for the initialization
cov1 = [c*ones(T,1) X1];
cov2 = [c*ones(T,1) X2];
cov_conc = [cov1 cov2]; %The two speech envelopes are concatenated to have FASTA find the optimal solution. 

Dec_conc = zeros(2*(L + 1),K);

%Matrix and vector of the foreground recursively upadted for the f(x) function of the
%Forward-Backward Splitting
A_conc = zeros(2*(L + 1),2*(L + 1));
b_conc = zeros(1,2*(L + 1));

% variables for storing attentional marker outputs
m1 = zeros(K,1) + 1e-7; % l1-based attentional marker outputs for speaker 1
m2 = zeros(K,1) + 1e-7; % l1-based attentional marker outputs for speaker 2
m3 = zeros(K,1) + 1e-7; % l1-based attentional marker outputs for situation where the subject is attenting to both speakers


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Run FASTA for each of windows selected
start_m1_m2 = round(0.08*fs);
end_m1_m2 = round(0.255*fs);

m2_offset = size(A_conc,1)/2;

%Initialize the delta for the hidden markov chain
Delta_m1_1 = 0; Delta_m1_2 = 0; Delta_m1_3 = 0;
Delta_m2_1 = 0; Delta_m2_2 = 0; Delta_m2_3 = 0;
save_state_m1 = [];
save_state_m2 = [];
adj_m1 = 0;
adj_m2 = 0;
save_adj_m1 = [];
save_adj_m2 = [];
percentage_adj = 0.013;

for k = 1:K
    
%     filt_cov = filter(shift_filt_TRF,1,cov_conc((k-1)*W+1:k*W,:)')';
%     
%     A_conc = lambda*A_conc + filt_cov'*filt_cov;
%     b_conc = lambda*b_conc + Y((k-1)*W+1:k*W)'*filt_cov;

    % estimating the decoder coefficients at instance k through FBS
    A_conc = lambda*A_conc + cov_conc((k-1)*W+1:k*W,:)'*cov_conc((k-1)*W+1:k*W,:);
    b_conc = lambda*b_conc + Y((k-1)*W+1:k*W)'*cov_conc((k-1)*W+1:k*W,:);
    
    if k == 1

        init_conc = zeros(2*(L + 1),1);
        temp_xx = (1:K)*W/fs;

    else
        
        init_conc = Dec_conc(:,k-1);
    
    end
    
[Dec_conc(:,k),~] = fasta( @(x) x, @(x) x, @(x) x'*A_conc*x-2*b_conc*x, @(x) 2*A_conc*x-2*b_conc', g, proxg, init_conc, opts);

% temp_env_1 = cov_conc((k-1)*W+1:k*W,2);
% temp_MEG = Y((k-1)*W+1:k*W);
% temp_1_Dec_conc = filter(Dec_conc(1:102,k),1,temp_env_1);
% m1_corr(k) = corr2(temp_MEG,temp_1_Dec_conc);

% temp_env_1 = cov_conc((k-1)*W+1:k*W,1:102);
% temp_MEG = Y((k-1)*W+1:k*W);
% temp_1_Dec_conc = temp_env_1*Dec_conc(1:102,k);
% m1_corr(k) = corr2(temp_MEG,temp_1_Dec_conc_1);
%  
% 
% temp_env_2 = cov_conc((k-1)*W+1:k*W,103:end);
% temp_MEG = Y((k-1)*W+1:k*W);
% temp_2_Dec_conc = temp_env_2*Dec_conc(103:end,k);
% m2_corr(k) = corr2(temp_MEG,temp_2_Dec_conc);


%Smoothing up the peaks before extracting the max value
temp_m1 = abs(Dec_conc(start_m1_m2:end_m1_m2,k));
sgf1 = sgolayfilt(temp_m1,4,9)';
m1(k) = max(max(sgf1),1e-7);

temp_m2 = abs(Dec_conc(m2_offset + start_m1_m2:m2_offset + end_m1_m2,k));
sgf2 = sgolayfilt(temp_m2,4,9)';
m2(k) = max(max(sgf2),1e-7);

%Saving the "original" biomarkers for the HMM
% m1_hmm(k) = m1(k);
% m2_hmm(k) = m1(k);


%Plotting the results of the Real Time (Sina) model
[curr_state_m1 Delta_m1_1 Delta_m1_2 Delta_m1_3] = HMM_Real_Time(m1,k,Delta_m1_1,Delta_m1_2,Delta_m1_3,temp_xx);
[curr_state_m2 Delta_m2_1 Delta_m2_2 Delta_m2_3] = HMM_Real_Time(m2,k,Delta_m2_1,Delta_m2_2,Delta_m2_3,temp_xx);

%If there is a tie between the 3 states, then select the lowest state.
if length(curr_state_m1) > 1
   
    curr_state_m1 = curr_state_m1(1);
    
end

if length(curr_state_m2) > 1
   
    curr_state_m2 = curr_state_m2(1);
    
end

save_state_m1 = [save_state_m1;curr_state_m1];
save_state_m2 = [save_state_m2;curr_state_m2];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Adjusting the state space value on the HMM
%Adjusting the state for the foreground
if (k == 1)
 
adj_m1 = 0;

else

if (save_state_m1(k) == 2) 

            adj_m1 = adj_m1 + m1(k)*percentage_adj;

       elseif (save_state_m1(k) == 3) 

            adj_m1 = adj_m1 - m1(k)*percentage_adj;

               end
end
save_adj_m1 = [save_adj_m1;adj_m1];
m1(k) = m1(k) + adj_m1;
%This line of code has been added to avoid negative values of the
%biomarker, since only absolute values are analyzed. If a negative value is
%generated, then the algorithm will re-assign the original value to the
%biomarker
if m1(k) < 0 
    
    m1(k) = m1(k) - adj_m1;
    
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Adjusting the state for the foreground
if (k == 1)
 
adj_m2 = 0;

else

if (save_state_m2(k) == 2) 

            adj_m2 = adj_m2 + m2(k)*percentage_adj;

        elseif (save_state_m2(k) == 3) 

             adj_m2 = adj_m2 - m2(k)*percentage_adj;

               end
end
save_adj_m2 = [save_adj_m2;adj_m2];
m2(k) = m2(k) + adj_m2;

%This line of code has been added to avoid negative values of the
%biomarker, since only absolute values are analyzed. If a negative value is
%generated, then the algorithm will re-assign the original value to the
%biomarker
if m2(k) < 0 
    
    m2(k) = m2(k) - adj_m2;
    
end

m3(k) =abs(m1(k) - m2(k));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if k >= K_W % starting the dynamic state-space starting from K_W samples


        m1_w = m1(k-K_W+1:k);
        m2_w = m2(k-K_W+1:k);
        m3_w = m3(k-K_W+1:k);
        z_l = z_smoothed_l(k-K_W+1:k);
        eta_l = eta_smoothed_l(k-K_W+1:k);
  

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%      
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%      
   % outer EM. This loop is used to maximize pho(a), pho(u), mu(a) and mu(u)
        for i = 1:outer_EM_dynamic
            
            %   calculating epsilon_k's in the current iteration (E-Step)
            %   Input for equation 10 from supplementary material
            P_11_l = max((1./m1_w)*sqrt(rho_d_l(1)).*exp(-0.5*rho_d_l(1)*(log(m1_w)-mu_d_l(1)).^2),10^-8);
            P_12_l = max((1./m1_w)*sqrt(rho_d_l(2)).*exp(-0.5*rho_d_l(2)*(log(m1_w)-mu_d_l(2)).^2),10^-8);
            P_13_l = max((1./m1_w)*sqrt(rho_d_l(3)).*exp(-0.5*rho_d_l(3)*(log(m1_w)-mu_d_l(3)).^2),10^-8);
            P_21_l = max((1./m2_w)*sqrt(rho_d_l(1)).*exp(-0.5*rho_d_l(1)*(log(m2_w)-mu_d_l(1)).^2),10^-8);
            P_22_l = max((1./m2_w)*sqrt(rho_d_l(2)).*exp(-0.5*rho_d_l(2)*(log(m2_w)-mu_d_l(2)).^2),10^-8);
            P_23_l = max((1./m2_w)*sqrt(rho_d_l(3)).*exp(-0.5*rho_d_l(3)*(log(m2_w)-mu_d_l(3)).^2),10^-8);
            P_31_l = max((1./m3_w)*sqrt(rho_d_l(1)).*exp(-0.5*rho_d_l(1)*(log(m3_w)-mu_d_l(1)).^2),10^-8);
            P_32_l = max((1./m3_w)*sqrt(rho_d_l(2)).*exp(-0.5*rho_d_l(2)*(log(m3_w)-mu_d_l(2)).^2),10^-8);
            P_33_l = max((1./m3_w)*sqrt(rho_d_l(3)).*exp(-0.5*rho_d_l(3)*(log(m3_w)-mu_d_l(3)).^2),10^-8);
        
            p_l = squeeze(1./(1+exp(-z_l)));    %this is the probability converted in logit^-1
            E_l = (p_l.*P_11_l.*P_22_l.*P_33_l)./(p_l.*P_11_l.*P_22_l.*P_33_l+(1-p_l).*P_12_l.*P_13_l.*P_21_l.*P_23_l.*P_31_l.*P_32_l); %Equation 10 from supplementary material
            
            % distribution parameters update (M-Step). This step maximizes equation S11
            mu_d_l(1) = ( sum(E_l.*log(m1_w)+(1-E_l).*log(m2_w) + (1-E_l).*log(m3_w)) + K_W*mu_0_l(1) )/(2*K_W); %Equation S12
            mu_d_l(2) = ( sum(E_l.*log(m2_w)+(1-E_l).*log(m1_w) + (1-E_l).*log(m3_w)) + K_W*mu_0_l(2))/(2*K_W); %Equation S13
            mu_d_l(3) = ( sum(E_l.*log(m3_w)+(1-E_l).*log(m1_w) + (1-E_l).*log(m2_w)) + K_W*mu_0_l(2) )/(2*K_W); %Equation S13

rho_d_l(1) = (2*K_W*alpha_0_l(1))/( sum( E_l.*((log(m1_w)-mu_d_l(1)).^2) + (1-E_l).*((log(m2_w)-mu_d_l(1)).^2) + (1-E_l).*((log(m3_w)-mu_d_l(1)).^2)) + K_W*(2*beta_0_l(1)+(mu_d_l(1)-mu_0_l(1)).^2) );  %Equation S14
rho_d_l(2) = (2*K_W*alpha_0_l(2))/( sum( E_l.*((log(m2_w)-mu_d_l(2)).^2) + (1-E_l).*((log(m1_w)-mu_d_l(2)).^2) + (1-E_l).*((log(m3_w)-mu_d_l(2)).^2)) + K_W*(2*beta_0_l(2)+(mu_d_l(2)-mu_0_l(2)).^2) );  %Equation S15
rho_d_l(3) = (2*K_W*alpha_0_l(3))/( sum( E_l.*((log(m3_w)-mu_d_l(3)).^2) + (1-E_l).*((log(m1_w)-mu_d_l(3)).^2) + (1-E_l).*((log(m2_w)-mu_d_l(3)).^2)) + K_W*(2*beta_0_l(2)+(mu_d_l(2)-mu_0_l(2)).^2) );  %Equation S15

 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%      
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%      
 
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%      
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%      
             % inner EM for updating z's and eta's (M-Step)
            
            for j = 1:inner_EM_dynamic
                
                % Filtering
                for kk = 2:K_W+1
                    
                    z_k_k_1_l(kk) = lambda_state*z_k_k_l(kk-1);
                    sig_k_k_1_l(kk) = lambda_state^2*sig_k_k_l(kk-1) + eta_l(kk-1);
            

% Newton's Algorithm used to solve the third equation in S23
                    for m = 1:Newton_iter
                         
                        z_k_k_l(kk) = z_k_k_l(kk) - (z_k_k_l(kk) - z_k_k_1_l(kk) - sig_k_k_1_l(kk)*(E_l(kk-1) - exp(z_k_k_l(kk))/(1+exp(z_k_k_l(kk))))) / (1 + sig_k_k_1_l(kk)*exp(z_k_k_l(kk))/((1+exp(z_k_k_l(kk)))^2));
                    
                    end
                     
                    sig_k_k_l(kk) = 1 / (1/sig_k_k_1_l(kk) + exp(z_k_k_l(kk))/((1+exp(z_k_k_l(kk)))^2));    %Equation 4 in S23
                      
                end
                 
                % Smoothing
                z_k_K_l(K_W+1) = z_k_k_l(K_W+1);
                sig_k_K_l(K_W+1) = sig_k_K_l(K_W+1);
                
                for kk = K_W:-1:1
                     
                    S_l(kk) = sig_k_k_l(kk)*lambda_state/sig_k_k_1_l(kk+1);
                    z_k_K_l(kk) = z_k_k_l(kk) + S_l(kk)*(z_k_K_l(kk+1) - z_k_k_1_l(kk+1));
                    sig_k_K_l(kk) = sig_k_k_l(kk) + S_l(kk)^2*(sig_k_K_l(kk+1) - sig_k_k_1_l(kk+1));
                    
                end
                
                z_k_k_l(1) = z_k_K_l(1);
                sig_k_k_l(1) = sig_k_K_l(1);
                
                eta_l = ( (z_k_K_l(2:end)-z_k_K_l(1:end-1)).^2+sig_k_K_l(2:end)+sig_k_K_l(1:end-1)-2*sig_k_K_l(2:end).*S_l+2*b_0 )/(1+2*(a_0+1));   %Equation S22
                
            end
            
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%      
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%      
           
            z_l = z_k_K_l(2:end);
                        
        end

        % update the z's and eta's        
        z_smoothed_l(k-K_W+1:k) = z_k_K_l(2:end);
        eta_smoothed_l(k-K_W+1:k) = eta_l;
        z_k_k_l(1) = z_k_K_l(2);
        z_dyn_l(k-K_F) = z_smoothed_l(k-K_F);
        eta_dyn_l(k-K_F) = eta_smoothed_l(k-K_F);
        
         if k == K_W
            
            z_dyn_l(1:K_B) = z_smoothed_l(1:K_B);
            eta_dyn_l(1:K_B) = eta_smoothed_l(1:K_B);
            
         end    
        
         if k == K
             
            z_dyn_l(k-K_F+1:end) = z_smoothed_l(k-K_F+1:end);
            eta_dyn_l(k-K_F+1:end) = eta_smoothed_l(k-K_F+1:end);
            
         end    
        
         if k < K
            
            z_smoothed_l(k+1) = z_smoothed_l(k);
            eta_smoothed_l(k+1) = eta_smoothed_l(k);
            
         end
        
end
% 
% figure(1)
% 
% subplot(2,1,1)
% plot((1:K)*W/fs,m1,'g','LineWidth',1.5);
% hold on;
% plot((1:K)*W/fs,m2,'r','LineWidth',1.5);
% 
% plot([triggers_button(track_trigg_button,1) triggers_button(track_trigg_button,1)],[0 max([m1;m2])],'k')
% plot([triggers_button(track_trigg_button,2) triggers_button(track_trigg_button,2)],[0 max([m1;m2])],'k')
% plot([triggers_button(track_trigg_button,3) triggers_button(track_trigg_button,3)],[0 max([m1;m2])],'k')
% 
% % plot([22.7 22.7],[0 0.004],'k')
% %     plot([47.5 47.5],[0 0.004],'k')
% %     plot([66.4 66.4],[0 0.004],'k')
% hold off;
% legend('Attended Male','Attended Female','Location','northeast');
% xlabel('time (s)')
% lim1 = max(max(abs([m1(ceil(5*fs/W):end); m2(ceil(5*fs/W):end)])));
% ylim([0, lim1]);
% xlim([0 90]);
% title('Attentional Marker Output for Speakers 1 and 2');
% axis tight
% 
% subplot(2,1,2)
% plot((1:K)*W/fs,1./(1+exp(-z_dyn_l)),'b','LineWidth',1.5);
% hold on;
% plot((1:K)*W/fs,1./(1+exp(-z_dyn_l - c0*sqrt(eta_dyn_l))),'r-.','LineWidth',1.5);
% plot((1:K)*W/fs,1./(1+exp(-z_dyn_l + c0*sqrt(eta_dyn_l))),'r-.','LineWidth',1.5);
% plot((1:K)*W/fs,0.5*ones(K,1),'k--','LineWidth',1.5);
% 
% plot([triggers_button(track_trigg_button,1) triggers_button(track_trigg_button,1)],[0 1],'k')
% plot([triggers_button(track_trigg_button,2) triggers_button(track_trigg_button,2)],[0 1],'k')
% plot([triggers_button(track_trigg_button,3) triggers_button(track_trigg_button,3)],[0 1],'k')
% 
% % plot([22.7 22.7],[0 1],'k')
% %     plot([47.5 47.5],[0 1],'k')
% %     plot([66.4 66.4],[0 1],'k')
% hold off;
% xlabel('time (s)')
% ylim([0 1]);
% xlim([0 90]);
% title('State-Space Output (Dynamic Version)');
% 
% pause(0.2)

% if k == 240
% 
%     cc = 1;
%     
% end

% figure (2)
% subplot(2,1,1)
% plot((1:length(save_state_m1))*W/fs,save_state_m1)
% subplot(2,1,2)
% plot((1:length(save_state_m2))*W/fs,save_state_m2)

end

%end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Plotting the encoder

lim1 = 0.4*max(max(abs([Dec_conc(2:m2_offset,ceil(8*fs/W):end) Dec_conc(2:m2_offset,ceil(8*fs/W):end)])));
%fig = figure('pos',[100 100 800 600]);
figure
subplot(2,1,1)
imagesc((1:K)*W/fs,(0:L-1)/fs,-Dec_conc(2:m2_offset,:),[-lim1,lim1])
colorbar;
title('Estimated decoder for attended speaker')
ylabel('decoder lag (s)')
xlabel('trial time (s)')
subplot(2,1,2)
imagesc((1:K)*W/fs,(0:L-1)/fs,-Dec_conc(m2_offset + 2:end,:),[-lim1,lim1])
colorbar;
title('Estimated decoder for unattended speaker')
ylabel('decoder lag (s)')
xlabel('trial time (s)')

saveas(gcf,['Forward_' temp_file(1:end-4) '_Trial_' num2str(trial) '.fig'])
close(gcf)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%Plotting the results of the Real Time (Sina) model
%fig = figure('pos',[100 100 1000 600]);
figure
subplot(2,1,1)
plot((1:K)*W/fs,m1,'g','LineWidth',1.5);
hold on;
plot((1:K)*W/fs,m2,'r','LineWidth',1.5);
legend('Attended speaker','Unattended speaker','Location','northeast');
xlabel('time (s)')
lim1 = max(max(abs([m1(ceil(5*fs/W):end); m2(ceil(5*fs/W):end)])));
ylim([0, lim1]);
xlim([0 90]);
title('l1-based Attentional Marker Output for Speakers 1 and 2');
axis tight

plot([triggers_button(track_trigg_button,1) triggers_button(track_trigg_button,1)],[0 max([m1;m2])],'k')
plot([triggers_button(track_trigg_button,2) triggers_button(track_trigg_button,2)],[0 max([m1;m2])],'k')
plot([triggers_button(track_trigg_button,3) triggers_button(track_trigg_button,3)],[0 max([m1;m2])],'k')

hold off;

subplot(2,1,2)
plot((1:K)*W/fs,1./(1+exp(-z_dyn_l)),'b','LineWidth',1.5);
hold on;
plot((1:K)*W/fs,1./(1+exp(-z_dyn_l-c0*sqrt(eta_dyn_l))),'r-.','LineWidth',1.5);
plot((1:K)*W/fs,1./(1+exp(-z_dyn_l+c0*sqrt(eta_dyn_l))),'r-.','LineWidth',1.5);
plot((1:K)*W/fs,0.5*ones(K,1),'k--','LineWidth',1.5);
xlabel('time (s)')
ylim([0 1]);
xlim([0 90]);
title('State-Space Output (Dynamic Version)');

plot([triggers_button(track_trigg_button,1) triggers_button(track_trigg_button,1)],[0 1],'k')
plot([triggers_button(track_trigg_button,2) triggers_button(track_trigg_button,2)],[0 1],'k')
plot([triggers_button(track_trigg_button,3) triggers_button(track_trigg_button,3)],[0 1],'k')

hold off;

saveas(gcf,['Forward_Prob_' temp_file(1:end-4) '_Trial_' num2str(trial)])
close(gcf)

track_trigg_button = track_trigg_button + 1;

    end
end

close all
msgbox('Operation Completed');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
