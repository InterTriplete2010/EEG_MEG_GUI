function varargout = GUI_SSM_Bayesian(varargin)
% GUI_SSM_BAYESIAN MATLAB code for GUI_SSM_Bayesian.fig
%      GUI_SSM_BAYESIAN, by itself, creates a new GUI_SSM_BAYESIAN or raises the existing
%      singleton*.
%
%      H = GUI_SSM_BAYESIAN returns the handle to a new GUI_SSM_BAYESIAN or the handle to
%      the existing singleton*.
%
%      GUI_SSM_BAYESIAN('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in GUI_SSM_BAYESIAN.M with the given input arguments.
%
%      GUI_SSM_BAYESIAN('Property','Value',...) creates a new GUI_SSM_BAYESIAN or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before GUI_SSM_Bayesian_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to GUI_SSM_Bayesian_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help GUI_SSM_Bayesian

% Last Modified by GUIDE v2.5 06-Aug-2019 12:00:21

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @GUI_SSM_Bayesian_OpeningFcn, ...
                   'gui_OutputFcn',  @GUI_SSM_Bayesian_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before GUI_SSM_Bayesian is made visible.
function GUI_SSM_Bayesian_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to GUI_SSM_Bayesian (see VARARGIN)

% Choose default command line output for GUI_SSM_Bayesian
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes GUI_SSM_Bayesian wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = GUI_SSM_Bayesian_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Foreground uploaded
function Foreground_SSM_B_Callback(hObject, eventdata, handles)
% hObject    handle to Foreground_SSM_B (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Foreground_SSM_B as text
%        str2double(get(hObject,'String')) returns contents of Foreground_SSM_B as a double


% --- Executes during object creation, after setting all properties.
function Foreground_SSM_B_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Foreground_SSM_B (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Upload the data for the analysis
% --- Executes on button press in Upload_Data_SSM_B.
function Upload_Data_SSM_B_Callback(hObject, eventdata, handles)
% hObject    handle to Upload_Data_SSM_B (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global Target_talker;
global Foreground_file_directory;
global Foreground_file_selected;
global Background_file_directory;
global Background_file_selected;
global MEG_file_directory;
global MEG_file_selected;
global Freq_TT;
global Background_talker;
global Freq_BT;
global MEG_data;

[Foreground_file_selected,Foreground_file_directory] = uigetfile('*.wav','Select the foreground wav file');
cd(Foreground_file_directory)
[Target_talker Freq_TT] = audioread(Foreground_file_selected);
set(handles.Foreground_SSM_B,'String',Foreground_file_selected)
pause(0.1)

[Background_file_selected,Background_file_directory] = uigetfile('*.wav','Select the Background speech');
cd(Background_file_directory)
[Background_talker Freq_BT] = audioread(Background_file_selected);
set(handles.Background_SSM_B,'String',Background_file_selected)
pause(0.1)

[MEG_file_selected,MEG_file_directory] = uigetfile('*.mat','Select the MEG file');
cd(MEG_file_directory)
MEG_data = load(MEG_file_selected);
set(handles.MEG_SSM_B,'String',MEG_file_selected)


%Make sure that the waveforms have the same length, as defined
%by the variable duration_t
duration_t = str2double(get(handles.Dur_Trial,'String'));

samples_ts = duration_t*Freq_TT;
Target_talker = Target_talker(1:samples_ts,:);

samples_bs = duration_t*Freq_BT;
Background_talker = Background_talker(1:samples_bs,:);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Background uploaded
function Background_SSM_B_Callback(hObject, eventdata, handles)
% hObject    handle to Background_SSM_B (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Background_SSM_B as text
%        str2double(get(hObject,'String')) returns contents of Background_SSM_B as a double


% --- Executes during object creation, after setting all properties.
function Background_SSM_B_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Background_SSM_B (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%MEG data uploaded
function MEG_SSM_B_Callback(hObject, eventdata, handles)
% hObject    handle to MEG_SSM_B (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of MEG_SSM_B as text
%        str2double(get(hObject,'String')) returns contents of MEG_SSM_B as a double


% --- Executes during object creation, after setting all properties.
function MEG_SSM_B_CreateFcn(hObject, eventdata, handles)
% hObject    handle to MEG_SSM_B (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Sampling frequency for the analysis
function SF_Analysis_Callback(hObject, eventdata, handles)
% hObject    handle to SF_Analysis (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of SF_Analysis as text
%        str2double(get(hObject,'String')) returns contents of SF_Analysis as a double


% --- Executes during object creation, after setting all properties.
function SF_Analysis_CreateFcn(hObject, eventdata, handles)
% hObject    handle to SF_Analysis (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%High Pass cut-off frequency 
function HP_Filter_Callback(hObject, eventdata, handles)
% hObject    handle to HP_Filter (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of HP_Filter as text
%        str2double(get(hObject,'String')) returns contents of HP_Filter as a double


% --- Executes during object creation, after setting all properties.
function HP_Filter_CreateFcn(hObject, eventdata, handles)
% hObject    handle to HP_Filter (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Order filter 
function Order_Filter_Callback(hObject, eventdata, handles)
% hObject    handle to Order_Filter (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Order_Filter as text
%        str2double(get(hObject,'String')) returns contents of Order_Filter as a double


% --- Executes during object creation, after setting all properties.
function Order_Filter_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Order_Filter (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%DSS_Channel_analysis for the analysis
function DSS_Channel_analysis_Callback(hObject, eventdata, handles)
% hObject    handle to DSS_Channel_analysis (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of DSS_Channel_analysis as text
%        str2double(get(hObject,'String')) returns contents of DSS_Channel_analysis as a double


% --- Executes during object creation, after setting all properties.
function DSS_Channel_analysis_CreateFcn(hObject, eventdata, handles)
% hObject    handle to DSS_Channel_analysis (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Duration of the trial 
function Dur_Trial_Callback(hObject, eventdata, handles)
% hObject    handle to Dur_Trial (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Dur_Trial as text
%        str2double(get(hObject,'String')) returns contents of Dur_Trial as a double
global Target_talker;
global Foreground_file_directory;
global Foreground_file_selected;
global Background_file_directory;
global Background_file_selected;
global MEG_file_directory;
global MEG_file_selected;
global Freq_TT;
global Background_talker;
global Freq_BT;
global MEG_data;

cd(Foreground_file_directory)
[Target_talker Freq_TT] = audioread(Foreground_file_selected);

cd(Background_file_directory)
[Background_talker Freq_BT] = audioread(Background_file_selected);

cd(MEG_file_directory)

%Make sure that the waveforms have the same length, as defined
%by the variable duration_t
duration_t = str2double(get(handles.Dur_Trial,'String'));

samples_ts = duration_t*Freq_TT;
Target_talker = Target_talker(1:samples_ts,:);

samples_bs = duration_t*Freq_BT;
Background_talker = Background_talker(1:samples_bs,:);

% --- Executes during object creation, after setting all properties.
function Dur_Trial_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Dur_Trial (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Low Pass cut-off frequency 
function LP_Filter_Callback(hObject, eventdata, handles)
% hObject    handle to LP_Filter (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of LP_Filter as text
%        str2double(get(hObject,'String')) returns contents of LP_Filter as a double


% --- Executes during object creation, after setting all properties.
function LP_Filter_CreateFcn(hObject, eventdata, handles)
% hObject    handle to LP_Filter (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Regularization factor 
function Reg_Factor_Callback(hObject, eventdata, handles)
% hObject    handle to Reg_Factor (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Reg_Factor as text
%        str2double(get(hObject,'String')) returns contents of Reg_Factor as a double


% --- Executes during object creation, after setting all properties.
function Reg_Factor_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Reg_Factor (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Forgetting factor 
function Forgetting_Factor_Callback(hObject, eventdata, handles)
% hObject    handle to Forgetting_Factor (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Forgetting_Factor as text
%        str2double(get(hObject,'String')) returns contents of Forgetting_Factor as a double


% --- Executes during object creation, after setting all properties.
function Forgetting_Factor_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Forgetting_Factor (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Lags TRF
function Lags_TRF_Callback(hObject, eventdata, handles)
% hObject    handle to Lags_TRF (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Lags_TRF as text
%        str2double(get(hObject,'String')) returns contents of Lags_TRF as a double


% --- Executes during object creation, after setting all properties.
function Lags_TRF_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Lags_TRF (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Start latency of the TRF analysis
function Latency_Start_Callback(hObject, eventdata, handles)
% hObject    handle to Latency_Start (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Latency_Start as text
%        str2double(get(hObject,'String')) returns contents of Latency_Start as a double


% --- Executes during object creation, after setting all properties.
function Latency_Start_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Latency_Start (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%End latency of the TRF analysis
function End_Latency_Callback(hObject, eventdata, handles)
% hObject    handle to End_Latency (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of End_Latency as text
%        str2double(get(hObject,'String')) returns contents of End_Latency as a double


% --- Executes during object creation, after setting all properties.
function End_Latency_CreateFcn(hObject, eventdata, handles)
% hObject    handle to End_Latency (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Run the analysis
% --- Executes on button press in SSM_B_Analysis.
function SSM_B_Analysis_Callback(hObject, eventdata, handles)
% hObject    handle to SSM_B_Analysis (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global Target_talker;
global Freq_TT;
global Background_talker;
global Freq_BT;
global MEG_data;

sf = str2double(get(handles.SF_Analysis,'String'));
DSS_channel = str2double(get(handles.DSS_Channel_analysis,'String'));

hpf = str2double(get(handles.HP_Filter,'String'));
lpf = str2double(get(handles.LP_Filter,'String'));
order_f = str2double(get(handles.Order_Filter,'String'));

duration_t = str2double(get(handles.Dur_Trial,'String'));
lags_TRF = str2double(get(handles.Lags_TRF,'String'))/1000;

rf = str2double(get(handles.Reg_Factor,'String'));
ff = str2double(get(handles.Forgetting_Factor,'String'));

S_TRF = str2double(get(handles.Latency_Start,'String'))/1000;
E_TRF = str2double(get(handles.End_Latency,'String'))/1000;

samples_MEG = duration_t*MEG_data.data_exported.sampling_frequency;

Bayesian_Alex_Forward_GUI(Target_talker,Freq_TT,Background_talker,Freq_BT,MEG_data,...
    sf,DSS_channel,hpf,lpf,order_f,duration_t,lags_TRF,rf,ff,S_TRF,E_TRF,samples_MEG)
