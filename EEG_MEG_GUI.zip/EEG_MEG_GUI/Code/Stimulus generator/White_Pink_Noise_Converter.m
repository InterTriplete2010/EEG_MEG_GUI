white_noise = wgn(1,3400,60);

num_taps = 3400;
a = zeros(1,num_taps);
a(1) = 1;
for ii = 2:num_taps
a(ii) = (ii - 2.5) * a(ii-1) / (ii-1);
end
theta = filter(1,a,white_noise);


% Phase modulate.

pn = exp(i*theta);

wavwrite(white_noise,'White_Noise')
wavwrite(theta,'Pink_Noise')