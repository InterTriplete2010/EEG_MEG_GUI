function[res] = shapiro_pval(W,N)

% W : Shapiro-Wilk statistic
% N : Number of samples

% Function result - will store p value
res = 0;

pw = 0;

pi6 = 6/pi;

G  = [-0.2273E1, 0.459E0];
c3 = [0.5440E0, -0.39978E0, 0.25054E-1, -0.6714E-3];
c4 = [0.13822E1, -0.77857E0, 0.62767E-1, -0.20322E-2];

c5 = [-0.15861E1, -0.31082E0, -0.83751E-1, 0.38915E-2];
c6 = [-0.4803E0, -0.82676E-1, 0.30302E-2];

% stqr = 0.1047198E1;

stqr = sqrt(0.75);

y = log(1 - W);
xx = log(N);
m = 0;
s = 1;

if (N == 3)

  pw = pi6 * (asin(sqrt(W)) - stqr);

  if (pw < 0)
    pw = 0;
  end;

elseif (N <= 11)
  gma = (G(2)*N) + (G(1)*1);
  
  if (y > gma)
    pw = 1e-19;
  else
    y = -log(gma - y);
    m = c3(4)*N^3 + c3(3)*N^2 + c3(2)*N + c3(1);
    s = exp(c4(4)*N^3 + c4(3)*N^2 + c4(2)*N + c4(1));
    pw = 1 - normcdf((y - m)/s);
  end;     

else
  
  m  = c5(4)*xx^3 + c5(3)*xx^2 + c5(2)*xx + c5(1);
  s  = exp(c6(3)*xx^2 + c6(2)*xx + c6(1));
  pw = 1 - normcdf((y - m)/s);
  
end;

res = pw;
