%% This algorithm is based on the following paper:

% A. Schl�gla, C. Keinrathb, D. Zimmermannb, R. Schererb, R. Leebb, G. Pfurtschellerb
% "A fully automated correction method of EOG artifacts in EEG recordings"
% Clinical Neurophysiology, Volume 118, Issue 1, January 2007, Pages 98�104

function [save_cleaned_eeg] = eye_movement_correction_function_ICA_GUI(eeg_to_be_corrected,eeg_to_be_corrected_data,vertical_eye_selected,...
    horizontal_eye_selected,vertical_eye_selected_weights,horizontal_eye_selected_weights,data_selected_weights);

save_cleaned_eeg = [];

sampl_freq = eeg_to_be_corrected.data_exported.sampling_frequency;

for kk = 1:size(eeg_to_be_corrected_data,1)

%Calculating the weights;
temp_eeg_weights = data_selected_weights(kk,:);
temp_eeg = eeg_to_be_corrected_data(kk,:);

b1 = ((dot((vertical_eye_selected_weights)',(vertical_eye_selected_weights))).^-1)*(dot((vertical_eye_selected_weights)',temp_eeg_weights));
b2 = ((dot((horizontal_eye_selected_weights)',(horizontal_eye_selected_weights))).^-1)*(dot((horizontal_eye_selected_weights)',temp_eeg_weights));

vector_b = [b1 b2];
vector_eyes = [vertical_eye_selected;horizontal_eye_selected];

eye_movement_corrected_eeg = temp_eeg(:,:) - (vector_b*vector_eyes);

save_cleaned_eeg = [save_cleaned_eeg;eye_movement_corrected_eeg];

end



