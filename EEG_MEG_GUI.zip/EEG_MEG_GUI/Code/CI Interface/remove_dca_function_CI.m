function save_dca_removed_data = remove_dca_function_CI(art_sens,eeg_data_dca,time_average,sf,channels_recorded)

%This function remove the DCA by using a bivariate polynomial as described
%in Mc LAughlin et al. 2013  "Cochlear Implant artifact attenuation in late 
%auditory evoked potentials: A single channel approach", Hearing Research

save_dca_removed_data = [];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Plotting the EEG data and the average of the ICA
for kk = 1:size(eeg_data_dca,1)

    temp_eeg_data = eeg_data_dca(kk,:);
        
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Computing the coefficients for the bivariate polynomial    
%{'constant, 'x', 'x^2', 'y', 'x*y', 'y^2'} %Second degree
%{'constant', 'x', 'x^4', 'y', 'x*y', 'y^4'}) fourth degree
    
    mean_data = art_sens;
ind_variables = [time_average;mean_data]';
pol_fact_2_degree = polyfitn(ind_variables,eeg_data_dca(kk,1:size(ind_variables,1)),'constant, x, x^2, y, x*y, y^2');

%Calculating the bivariate polynomial
%Two degree
equation_dca_2_degree = pol_fact_2_degree.Coefficients(1) + pol_fact_2_degree.Coefficients(2)*(time_average) + pol_fact_2_degree.Coefficients(3)*(time_average.^2) + ...
    pol_fact_2_degree.Coefficients(4)*(mean_data) + pol_fact_2_degree.Coefficients(5)*((mean_data).*(time_average)) + pol_fact_2_degree.Coefficients(6)*(mean_data.^2);


    figure(2000)


subplot(size(eeg_data_dca,1),1,kk)
plot(1000*time_average(:,1:size(ind_variables,1)),temp_eeg_data(:,1:size(ind_variables,1)),'r')

hold on

plot(1000*time_average(:,1:size(ind_variables,1)),temp_eeg_data(:,1:size(ind_variables,1)) - equation_dca_2_degree,'k')

plot(1000*time_average(:,1:size(ind_variables,1)),equation_dca_2_degree,'g')

hold off

title(['\bfDCA removal (2 degrees) for channel: ' cell2mat(channels_recorded(kk))])
xlabel('\bfTime (ms)')
ylabel('\bfAmplitude (\muV)')


legend('Before','After','Bivariate polynomial')

save_dca_removed_data = [save_dca_removed_data;temp_eeg_data(:,1:size(ind_variables,1)) - equation_dca_2_degree];

end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

