function varargout = CI_GUI(varargin)
% CI_GUI MATLAB code for CI_GUI.fig
%      CI_GUI, by itself, creates a new CI_GUI or raises the existing
%      singleton*.
%
%      H = CI_GUI returns the handle to a new CI_GUI or the handle to
%      the existing singleton*.
%
%      CI_GUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in CI_GUI.M with the given input arguments.
%
%      CI_GUI('Property','Value',...) creates a new CI_GUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before CI_GUI_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to CI_GUI_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help CI_GUI

% Last Modified by GUIDE v2.5 13-Jul-2016 15:28:38

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @CI_GUI_OpeningFcn, ...
                   'gui_OutputFcn',  @CI_GUI_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before CI_GUI is made visible.
function CI_GUI_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to CI_GUI (see VARARGIN)

% Choose default command line output for CI_GUI
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes CI_GUI wait for user response (see UIRESUME)
% uiwait(handles.figure1);
global check_patient_info;

check_patient_info = 0;
set(handles.Scalp_Map_Energy_CI,'Visible','off');
set(handles.Plot_selec_Sens_CI,'Visible','off');

% --- Outputs from this function are returned to the command line.
function varargout = CI_GUI_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%CI file uploaded
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function CI_File_Uploaded_Callback(hObject, eventdata, handles)
% hObject    handle to CI_File_Uploaded (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of CI_File_Uploaded as text
%        str2double(get(hObject,'String')) returns contents of CI_File_Uploaded as a double


% --- Executes during object creation, after setting all properties.
function CI_File_Uploaded_CreateFcn(hObject, eventdata, handles)
% hObject    handle to CI_File_Uploaded (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Upload the CI file
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in Upload_CI_File.
function Upload_CI_File_Callback(hObject, eventdata, handles)
% hObject    handle to Upload_CI_File (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global CI_File_Selected;
global energy_data;
global data_CI;
global table_tag_sensors_CI;
global check_patient_info;

if (check_patient_info ~=9)
    
    
    message = 'One or more fields have not been filled out. Please, make sure all the information about this patient has been inserted';
        msgbox(message,'Incomplete information','warn');
    
        return;
end
    

table_tag_sensors_CI = handles.Table_Sensors_CI;

data_CI = [];
energy_data = [];

[CI_File_Selected,CI_File_Selected_directory] = uigetfile('*.mat','Select the CI file');

set(handles.CI_File_Uploaded,'String',CI_File_Selected);

cd(CI_File_Selected_directory)
data_CI = load(CI_File_Selected);

%% Filling in the info about the CI file recorded
set(handles.SF_CI_Data,'String',data_CI.data_exported.sampling_frequency);
set(handles.Ref_Chan_CI,'String',data_CI.data_exported.labels(cell2mat(data_CI.data_exported.reference_channel)));
set(handles.Channels_CI,'String',data_CI.data_exported.labels);
set(handles.Record_Time_CI,'String',data_CI.data_exported.samples/data_CI.data_exported.sampling_frequency);
set(handles.Trigg_Code_CI,'String',data_CI.data_exported.events_type);
set(handles.Numb_Trigg_CI,'String',size(data_CI.data_exported.events_type,2));

%% Plotting the Energy of each electrode
load('channel_location_biosemi');   %Loading the position of the channels

%Removing channels from the analysis(i.e. A1, A2, etc.)
channel_location_biosemi(:,33:end) = []; 
temp_data = data_CI.data_exported.eeg_data;

if (size(temp_data,1) > 32)

    temp_data(33:end,:) = [];

elseif (size(temp_data,1) < 32)

    message = ('No scalp map has been generated. You need at least 32 electrodes to create a scalp map');
        msgbox(message,'Operation terminated','warn');

        return;
end

set(gcf,'CurrentAxes',handles.Scalp_Map_Energy_CI);
set(handles.Scalp_Map_Energy_CI,'Visible','on');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Filtering the data
[b_ci,a_ci] = butter(str2double(get(handles.Order_Filt_CI,'String')),[str2double(get(handles.Cut_off_High_CI_Vis,'String')) str2double(get(handles.Cut_off_Low_CI_Vis,'String'))]/(data_CI.data_exported.sampling_frequency/2));
for kk = 1:size(temp_data,1)
    
    energy_data(kk,:) = filtfilt(b_ci,a_ci,temp_data(kk,:));

end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

topoplot(mean(energy_data.^2,2),channel_location_biosemi)
colorbar

%set_colorbar = gca;
%set(set_colorbar,'CLim',[min(mean(energy_data.^2,2)) max(mean(energy_data.^2,2))])

%Filling the table with the electrodes
set(handles.Table_Sensors_CI,'Data',data_CI.data_exported.labels);
set(handles.Table_Sensors_CI,'columnname',{'Electrodes recorded'});

message = 'Data have been uploaded';

        msgbox(message,'Calculations completed','warn');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%SF of the CI file uploaded
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function SF_CI_Data_Callback(hObject, eventdata, handles)
% hObject    handle to SF_CI_Data (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of SF_CI_Data as text
%        str2double(get(hObject,'String')) returns contents of SF_CI_Data as a double


% --- Executes during object creation, after setting all properties.
function SF_CI_Data_CreateFcn(hObject, eventdata, handles)
% hObject    handle to SF_CI_Data (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Channels recorded 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on selection change in Channels_CI.
function Channels_CI_Callback(hObject, eventdata, handles)
% hObject    handle to Channels_CI (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns Channels_CI contents as cell array
%        contents{get(hObject,'Value')} returns selected item from Channels_CI


% --- Executes during object creation, after setting all properties.
function Channels_CI_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Channels_CI (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Duration of the experiment
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Record_Time_CI_Callback(hObject, eventdata, handles)
% hObject    handle to Record_Time_CI (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Record_Time_CI as text
%        str2double(get(hObject,'String')) returns contents of Record_Time_CI as a double


% --- Executes during object creation, after setting all properties.
function Record_Time_CI_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Record_Time_CI (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Number of triggers recorded
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Numb_Trigg_CI_Callback(hObject, eventdata, handles)
% hObject    handle to Numb_Trigg_CI (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Numb_Trigg_CI as text
%        str2double(get(hObject,'String')) returns contents of Numb_Trigg_CI as a double


% --- Executes during object creation, after setting all properties.
function Numb_Trigg_CI_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Numb_Trigg_CI (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Sequence of the triggers recorded
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on selection change in Trigg_Code_CI.
function Trigg_Code_CI_Callback(hObject, eventdata, handles)
% hObject    handle to Trigg_Code_CI (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns Trigg_Code_CI contents as cell array
%        contents{get(hObject,'Value')} returns selected item from Trigg_Code_CI


% --- Executes during object creation, after setting all properties.
function Trigg_Code_CI_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Trigg_Code_CI (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Order of the filter for Energy
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Order_Filt_CI_Callback(hObject, eventdata, handles)
% hObject    handle to Order_Filt_CI (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Order_Filt_CI as text
%        str2double(get(hObject,'String')) returns contents of Order_Filt_CI as a double


% --- Executes during object creation, after setting all properties.
function Order_Filt_CI_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Order_Filt_CI (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Low Cut-off for the band-pass filter for visualization 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Cut_off_High_CI_Vis_Callback(hObject, eventdata, handles)
% hObject    handle to Cut_off_High_CI_Vis (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Cut_off_High_CI_Vis as text
%        str2double(get(hObject,'String')) returns contents of Cut_off_High_CI_Vis as a double


% --- Executes during object creation, after setting all properties.
function Cut_off_High_CI_Vis_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Cut_off_High_CI_Vis (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Select and show the sensors plotted on the scalpmap
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in Select_sensors_plot_CI.
function Select_sensors_plot_CI_Callback(hObject, eventdata, handles)
% hObject    handle to Select_sensors_plot_CI (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global energy_data;
global data_CI;

set(gcf,'CurrentAxes',handles.Scalp_Map_Energy_CI);
items_fig = get(gca,'Children');

coordinates_sensors = get(items_fig(1));

x_coord = coordinates_sensors.XData;
y_coord = coordinates_sensors.YData;

rect = getrect;

%% Estimate which electrodes should be plotted
temp_x = rect(3) + rect(1);  
x_line = [rect(1) temp_x];

temp_y = rect(4) + rect(2);  
y_line = [rect(2) temp_y];

%% Find the sensors selected
sensors_pos = find(x_coord < x_line(2) & x_coord > x_line(1) & y_coord < y_line(2) & y_coord > y_line(1));

if (isempty(sensors_pos))
   
    message = 'No sensor has been found in the selected area';

        msgbox(message,'No wave has been plotted','warn');
    
    return;
    
end

sensors_to_plot = energy_data(sensors_pos,:);

set(gcf,'CurrentAxes',handles.Plot_selec_Sens_CI)
set(handles.Plot_selec_Sens_CI,'Visible','on');

%% Deleting the waveforms and preparing to plot the selected sensors
clean_plot = get(handles.Plot_selec_Sens_CI,'Children');
delete(clean_plot)

temp_labels = data_CI.data_exported.labels;

set(handles.Sensors_plotted_CI,'String',data_CI.data_exported.labels(sensors_pos));

tt_domain = [0:size(sensors_to_plot,2)-1]/data_CI.data_exported.sampling_frequency;

distance_waves = 0;

hold on

for kk = 1:size(sensors_to_plot,1)

    plot(tt_domain,sensors_to_plot(kk,:) - distance_waves)

distance_waves = distance_waves + 2*max(sensors_to_plot(kk,:));

end

set(gca,'fontweight','bold')

hold off

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Channels selected to be plotted
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on selection change in Sensors_plotted_CI.
function Sensors_plotted_CI_Callback(hObject, eventdata, handles)
% hObject    handle to Sensors_plotted_CI (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns Sensors_plotted_CI contents as cell array
%        contents{get(hObject,'Value')} returns selected item from Sensors_plotted_CI


% --- Executes during object creation, after setting all properties.
function Sensors_plotted_CI_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Sensors_plotted_CI (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Zoom into the data
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in Zoom_in_CI.
function Zoom_in_CI_Callback(hObject, eventdata, handles)
% hObject    handle to Zoom_in_CI (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(gcf,'CurrentAxes',handles.Plot_selec_Sens_CI)
axis tight

zoom on

pause

zoom off

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%High pass of the filter
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function HP_BPF_CI_Callback(hObject, eventdata, handles)
% hObject    handle to HP_BPF_CI (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of HP_BPF_CI as text
%        str2double(get(hObject,'String')) returns contents of HP_BPF_CI as a double


% --- Executes during object creation, after setting all properties.
function HP_BPF_CI_CreateFcn(hObject, eventdata, handles)
% hObject    handle to HP_BPF_CI (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Low pass of the filter
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function LP_BPF_CI_Callback(hObject, eventdata, handles)
% hObject    handle to LP_BPF_CI (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of LP_BPF_CI as text
%        str2double(get(hObject,'String')) returns contents of LP_BPF_CI as a double


% --- Executes during object creation, after setting all properties.
function LP_BPF_CI_CreateFcn(hObject, eventdata, handles)
% hObject    handle to LP_BPF_CI (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Order of the filter
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Order_Filt_CI_Analysis_Callback(hObject, eventdata, handles)
% hObject    handle to Order_Filt_CI_Analysis (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Order_Filt_CI_Analysis as text
%        str2double(get(hObject,'String')) returns contents of Order_Filt_CI_Analysis as a double


% --- Executes during object creation, after setting all properties.
function Order_Filt_CI_Analysis_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Order_Filt_CI_Analysis (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%If checked, the band-pass filter will be applied to the data
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in Check_Filter_CI.
function Check_Filter_CI_Callback(hObject, eventdata, handles)
% hObject    handle to Check_Filter_CI (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of Check_Filter_CI

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%If checked, eye-movement correction will be applied to the data
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in Ocular_artifacts_CI.
function Ocular_artifacts_CI_Callback(hObject, eventdata, handles)
% hObject    handle to Ocular_artifacts_CI (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of Ocular_artifacts_CI
global data_CI;

%If ocular artifact has to be applied, then populate the pop-up item with
%the electrodes available for the analysis
if (get(handles.Ocular_artifacts_CI,'Value') == 1)

set(handles.Vert_Eye_CI,'String',data_CI.data_exported.labels);
set(handles.Hor_Eye_CI,'String',data_CI.data_exported.labels);

else
    
    for ll = 1:length(data_CI.data_exported.labels)
       
        empty_string(ll) = {'N/A'}; 
        
    end
    
    set(handles.Vert_Eye_CI,'String',empty_string);
set(handles.Hor_Eye_CI,'String','N/A');


end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Vertical eye electrode for the eye-movement correction
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on selection change in Vert_Eye_CI.
function Vert_Eye_CI_Callback(hObject, eventdata, handles)
% hObject    handle to Vert_Eye_CI (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns Vert_Eye_CI contents as cell array
%        contents{get(hObject,'Value')} returns selected item from Vert_Eye_CI


% --- Executes during object creation, after setting all properties.
function Vert_Eye_CI_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Vert_Eye_CI (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Horizontal eye electrode for the eye-movement correction
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on selection change in Hor_Eye_CI.
function Hor_Eye_CI_Callback(hObject, eventdata, handles)
% hObject    handle to Hor_Eye_CI (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns Hor_Eye_CI contents as cell array
%        contents{get(hObject,'Value')} returns selected item from Hor_Eye_CI


% --- Executes during object creation, after setting all properties.
function Hor_Eye_CI_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Hor_Eye_CI (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Eelctrode to remove DCA
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on selection change in Artifact_Elecr_CI.
function Artifact_Elecr_CI_Callback(hObject, eventdata, handles)
% hObject    handle to Artifact_Elecr_CI (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns Artifact_Elecr_CI contents as cell array
%        contents{get(hObject,'Value')} returns selected item from Artifact_Elecr_CI


% --- Executes during object creation, after setting all properties.
function Artifact_Elecr_CI_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Artifact_Elecr_CI (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%If checked, DCA will be removed from the final average
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in DCA_removal_CI.
function DCA_removal_CI_Callback(hObject, eventdata, handles)
% hObject    handle to DCA_removal_CI (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of DCA_removal_CI

global data_CI;

%If DCA removal has to be applied, then populate the pop-up item with
%the electrodes available for the analysis
if (get(handles.DCA_removal_CI,'Value') == 1)

set(handles.Artifact_Elecr_CI,'String',data_CI.data_exported.labels);

else
    
    for ll = 1:length(data_CI.data_exported.labels)
       
        empty_string(ll) = {'N/A'}; 
        
    end
    
    set(handles.Artifact_Elecr_CI,'String',empty_string);

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Negative Artifact rejection for CI
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Neg_Art_Rej_CI_Callback(hObject, eventdata, handles)
% hObject    handle to Neg_Art_Rej_CI (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Neg_Art_Rej_CI as text
%        str2double(get(hObject,'String')) returns contents of Neg_Art_Rej_CI as a double


% --- Executes during object creation, after setting all properties.
function Neg_Art_Rej_CI_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Neg_Art_Rej_CI (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Positive Artifact rejection for CI
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Pos_Art_Rej_CI_Callback(hObject, eventdata, handles)
% hObject    handle to Neg_Art_Rej_CI (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Neg_Art_Rej_CI as text
%        str2double(get(hObject,'String')) returns contents of Neg_Art_Rej_CI as a double


% --- Executes during object creation, after setting all properties.
function Pos_Art_Rej_CI_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Neg_Art_Rej_CI (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Seconds before trigger
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Sec_Bef_Trig_CI_Callback(hObject, eventdata, handles)
% hObject    handle to Sec_Bef_Trig_CI (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Sec_Bef_Trig_CI as text
%        str2double(get(hObject,'String')) returns contents of Sec_Bef_Trig_CI as a double


% --- Executes during object creation, after setting all properties.
function Sec_Bef_Trig_CI_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Sec_Bef_Trig_CI (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Seconds after trigger
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Sec_After_Trig_CI_Callback(hObject, eventdata, handles)
% hObject    handle to Sec_After_Trig_CI (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Sec_After_Trig_CI as text
%        str2double(get(hObject,'String')) returns contents of Sec_After_Trig_CI as a double


% --- Executes during object creation, after setting all properties.
function Sec_After_Trig_CI_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Sec_After_Trig_CI (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Adjusting time for CI data
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Adj_Time_CI_Callback(hObject, eventdata, handles)
% hObject    handle to Adj_Time_CI (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Adj_Time_CI as text
%        str2double(get(hObject,'String')) returns contents of Adj_Time_CI as a double


% --- Executes during object creation, after setting all properties.
function Adj_Time_CI_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Adj_Time_CI (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Calculate the average for the CI data
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in Average_CI_data.
function Average_CI_data_Callback(hObject, eventdata, handles)
% hObject    handle to Average_CI_data (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global data_CI;
global sensors_to_keep_CI;
global ID_patient;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Start the analysis
%Changing the toggle button to "red"
set(handles.Analyzing_button,'BackgroundColor',[1 0 0]);
set(handles.Analyzing_button,'String','ON');

%Upload the CI data
data_average = data_CI.data_exported.eeg_data;

%Preparing the variables for the average
sampling_frequency_data = data_CI.data_exported.sampling_frequency;
artifact_pos_electrode = str2double(get(handles.Pos_Art_Rej_CI,'String'));
artifact_neg_electrode = str2double(get(handles.Neg_Art_Rej_CI,'String'));
artifact_pos_artifact = str2double(get(handles.Art_DCA_pos,'String'));
artifact_neg_artifact = str2double(get(handles.Art_DCA_neg,'String'));
adj_trigger_value = str2double(get(handles.Adj_Time_CI,'String'));
Seconds_Before_trigger = str2double(get(handles.Sec_Bef_Trig_CI,'String'));
Seconds_After_trigger = str2double(get(handles.Sec_After_Trig_CI,'String'));
trigger_selected = data_CI.data_exported.events_type(1,5); %Use the fifth trigger in case the first few triggers were corrupted by noise 
max_numb_trials = str2double(get(handles.Numb_Trials,'String'));

extension_name = get(handles.Extension_Name_File,'String');

%Step 1. Check if the data need to be filtered
if (get(handles.Check_Filter_CI,'Value') == 1)
    
    message = 'Filtering the data.....';

        msgbox(message,'Filtering in progress','warn');   
        
        current_message = gcf;
        
   order_filt = str2double(get(handles.Order_Filt_CI_Analysis,'String'));
   
   cut_off_band_pass_high = str2double(get(handles.HP_BPF_CI,'String'));
   cut_off_band_pass_low = str2double(get(handles.LP_BPF_CI,'String'));
   
   eeg_filtered = Band_Pass_Filter_Function_CI_Interface (data_average,cut_off_band_pass_high,cut_off_band_pass_low,sampling_frequency_data,order_filt); 
   
   close(current_message);

else
    
    eeg_filtered = data_average;
   
end

if (isempty(eeg_filtered))
       
       return;
       
   end
      


%Step 2. Check if ocular artifact needs to be applied to the data
if (get(handles.Ocular_artifacts_CI,'Value') == 1)
    
    message = 'Removing ocular artifacts.....';

        msgbox(message,'Ocular artifact removal','warn');  
    
vertical_eye_selected = eeg_filtered(get(handles.Vert_Eye_CI,'Value'),:);
horizontal_eye_selected = eeg_filtered(get(handles.Hor_Eye_CI,'Value'),:);

vertical_eye_selected_weights = eeg_filtered(get(handles.Vert_Eye_CI,'Value'),:);
horizontal_eye_selected_weights = eeg_filtered(get(handles.Hor_Eye_CI,'Value'),:);
    
    [save_cleaned_eeg] = eye_movement_correction_function_ICA_GUI(data_CI,eeg_filtered,vertical_eye_selected,...
    horizontal_eye_selected,vertical_eye_selected_weights,horizontal_eye_selected_weights,eeg_filtered);

close(gcf)

else
    
    save_cleaned_eeg = eeg_filtered;

end



%Step 3. Extract the electrodes that will be averaged
electrodes_analysis = save_cleaned_eeg(sensors_to_keep_CI,:);
channels_recorded = data_CI.data_exported.labels(sensors_to_keep_CI);

%Checking is at least one sensor has been selected for the analysis
if (isempty(electrodes_analysis))
    
    message = 'No sensor has been selected for the analysis. Operation will be aborted';

        msgbox(message,'No sensor selected','warn');
        
            return;
        end


%Step 4. Average the sensors selected

message = 'Averaging the selected sensors.....';

        msgbox(message,'Averaging in progress','warn'); 
  
        current_message = gcf;
        
[mean_sensors_selected tt_mean] = Extract_Trials_function_all_electrodes_CI_GUI(data_CI,electrodes_analysis,Seconds_Before_trigger,...
    Seconds_After_trigger,channels_recorded,trigger_selected,ID_patient,artifact_neg_electrode,...
    artifact_pos_electrode,adj_trigger_value,max_numb_trials,extension_name);
           
        close(gcf)

        close(current_message)
        
%Step 5. Average the artifact sensor, if the DCA analysis has to be
%performed and remove DCA

if (get(handles.DCA_removal_CI,'Value') == 1)

    message = 'Removing DCA artifact.....';

        msgbox(message,'DCA removal in progress','warn'); 
    
        current_message = gcf;
        
    templ_art = save_cleaned_eeg(get(handles.Artifact_Elecr_CI,'Value'),:);
    
  channel_CI_artifact = data_CI.data_exported.labels(get(handles.Artifact_Elecr_CI,'Value'));  
    
    [mean_sensor_artifact_selected_temp single_trials] = Extract_Trials_function_all_electrodes_CI_GUI_Artifacts(data_CI,templ_art,Seconds_Before_trigger,...
    Seconds_After_trigger,channel_CI_artifact,trigger_selected,ID_patient,artifact_neg_artifact,...
    artifact_pos_artifact,adj_trigger_value,extension_name);

%Finding the mean of the pedestal based on the optimal alignment
mean_sensor_artifact_selected = align_template_sweeps_CI(single_trials,tt_mean);

%save_dca_removed_data = remove_dca_function_CI(mean_sensor_artifact_selected,mean_sensors_selected,tt_mean,sampling_frequency_data,channels_recorded);
%Remove the pedestal of each electrode selected
ind_variables = [tt_mean;mean_sensor_artifact_selected]';

for kk = 1:size(mean_sensors_selected,1)

    temp_eeg_data = mean_sensors_selected(kk,:);
    
%Creating the matrix with the Independent variables for a second degree model. 
%A column of "ones" will be added to account for the bias
ind_var = [ones(size(ind_variables,1),1) ind_variables(:,1) ind_variables(:,2) ind_variables(:,1).^2 ind_variables(:,2).^2 ind_variables(:,1).*ind_variables(:,2)];
[equation_dca_2_degree var_regr_2_degree] = Polynomial_Regress_Model_CI(temp_eeg_data(:,1:size(ind_variables,1)),ind_var,sampling_frequency_data);
    
%save_dca_removed_data = Polynomial_Regress_Model_CI(mean_sensor_artifact_selected,mean_sensors_selected,tt_mean,sampling_frequency_data,channels_recorded);
save_dca_removed_data(kk,:) = temp_eeg_data(:,1:size(ind_variables,1)) - equation_dca_2_degree';
estimated_pedestal(kk,:) = equation_dca_2_degree; 
var_regr_2_degrees_subjects(kk,:) = var_regr_2_degree;

figure
plot(1000*tt_mean,save_dca_removed_data(kk,:),'k')
hold on
plot(1000*tt_mean,equation_dca_2_degree,'r')
hold off

title(['\bfArtifact removed average of electrode - ' cell2mat(channels_recorded(kk))])
legend('Average Channel','Estimated Pedestal')

xlabel('\bfTime (ms)')
ylabel('\bfAmplitude (\muV)')

saveas(gcf,[ID_patient '_DCA_Corrected_' cell2mat(channels_recorded(kk)) '_' extension_name '.fig'])

close(gcf)

message = 'Data have being saved.....';

        msgbox(message,'Saving the data','warn'); 
        
data_exported.average_trials = save_dca_removed_data;
data_exported.var_regr_2_degrees = var_regr_2_degrees_subjects;
data_exported.sampling_frequency = sampling_frequency_data;
data_exported.time_average = tt_mean;
data_exported.labels = channels_recorded;
data_exported.channel_artifact_dca = channel_CI_artifact;

save ([ID_patient '_' extension_name],'data_exported')

close(gcf)


end
   
end


%close(current_message);

message = 'ERP have been extracted and saved.....';

        msgbox(message,'End of the analysis','warn'); 
    
   %Changing the toggle button back to "green"
set(handles.Analyzing_button,'BackgroundColor',[0 1 0]);
set(handles.Analyzing_button,'String','OFF');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Table to select the eletcordes to be averaged
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes when selected cell(s) is changed in Table_Sensors_CI.
function Table_Sensors_CI_CellSelectionCallback(hObject, eventdata, handles)
% hObject    handle to Table_Sensors_CI (see GCBO)
% eventdata  structure with the following fields (see UITABLE)
%	Indices: row and column indices of the cell(s) currently selecteds
% handles    structure with handles and user data (see GUIDATA)
global table_tag_sensors_CI;
global sensors_to_keep_CI;

event_data_indices = eventdata.Indices;

properties_table = get(table_tag_sensors_CI);

sensors_to_keep_CI = zeros(1,size(event_data_indices,1));

for kk = 1:size(event_data_indices,1)
   
    sensors_to_keep_CI(1,kk) = event_data_indices(kk,1);
    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Low Cut-off for the band-pass filter for visualization 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Cut_off_Low_CI_Vis_Callback(hObject, eventdata, handles)
% hObject    handle to Cut_off_Low_CI_Vis (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Cut_off_Low_CI_Vis as text
%        str2double(get(hObject,'String')) returns contents of Cut_off_Low_CI_Vis as a double


% --- Executes during object creation, after setting all properties.
function Cut_off_Low_CI_Vis_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Cut_off_Low_CI_Vis (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Patient information menu
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --------------------------------------------------------------------
function Patient_information_Menu_Callback(hObject, eventdata, handles)
% hObject    handle to Patient_information_Menu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Uploading the info of existing patients
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --------------------------------------------------------------------
function Existing_CI_Patient_Callback(hObject, eventdata, handles)
% hObject    handle to Existing_CI_Patient (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global check_patient_info;

[Patient_Info_Selected,Patient_Info_Selected_directory] = uigetfile('*.mat','Select the Patient Info file');

cd(Patient_Info_Selected_directory);

info_existing_patient = load(Patient_Info_Selected);

   
    check_patient_info = 9;
    
Patient_Info(info_existing_patient,check_patient_info);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%New patient
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --------------------------------------------------------------------
function New_CI_Patient_Callback(hObject, eventdata, handles)
% hObject    handle to New_CI_Patient (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

Patient_Info();

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Item used to inform the user whether or not the analysis started
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in Analyzing_button.
function Analyzing_button_Callback(hObject, eventdata, handles)
% hObject    handle to Analyzing_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of Analyzing_button

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Positive artifact rejection for DCA
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Art_DCA_pos_Callback(hObject, eventdata, handles)
% hObject    handle to Art_DCA_pos (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Art_DCA_pos as text
%        str2double(get(hObject,'String')) returns contents of Art_DCA_pos as a double


% --- Executes during object creation, after setting all properties.
function Art_DCA_pos_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Art_DCA_pos (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Negative artifact rejection for DCA
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Art_DCA_neg_Callback(hObject, eventdata, handles)
% hObject    handle to Art_DCA_neg (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Art_DCA_neg as text
%        str2double(get(hObject,'String')) returns contents of Art_DCA_neg as a double


% --- Executes during object creation, after setting all properties.
function Art_DCA_neg_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Art_DCA_neg (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Maximum number of trials to be averaged
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Numb_Trials_Callback(hObject, eventdata, handles)
% hObject    handle to Numb_Trials (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Numb_Trials as text
%        str2double(get(hObject,'String')) returns contents of Numb_Trials as a double


% --- Executes during object creation, after setting all properties.
function Numb_Trials_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Numb_Trials (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Reference channel for the data uploaded
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on selection change in Ref_Chan_CI.
function Ref_Chan_CI_Callback(hObject, eventdata, handles)
% hObject    handle to Ref_Chan_CI (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns Ref_Chan_CI contents as cell array
%        contents{get(hObject,'Value')} returns selected item from Ref_Chan_CI


% --- Executes during object creation, after setting all properties.
function Ref_Chan_CI_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Ref_Chan_CI (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Extension for the name of the file 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Extension_Name_File_Callback(hObject, eventdata, handles)
% hObject    handle to Extension_Name_File (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Extension_Name_File as text
%        str2double(get(hObject,'String')) returns contents of Extension_Name_File as a double


% --- Executes during object creation, after setting all properties.
function Extension_Name_File_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Extension_Name_File (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
