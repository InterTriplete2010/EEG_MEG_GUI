%% Polynomial model built with QR decomposition method
function [equation_dca_2_degree var_regr]= Polynomial_Regress_Model_CI(dep_var,ind_var,sf);
%This function remove the DCA by using a bivariate polynomial as described
%in Mc LAughlin et al. 2013  "Cochlear Implant artifact attenuation in late 
%auditory evoked potentials: A single channel approach", Hearing Research

%Creating an upper triangular matrix (R) and an unitary matrix (Q) so that
%ind_var = Q*R. A unitary matrix is a matrix that satisfies the following
%condition: QQ' = Q'Q = I; "e" is the permutation vector so that ind_var(:,e) = Q*R. 
%The Gram-Schmidt method is ustilized for this computation. 

%The code will look at the [-5 5]ms in the [-50 550]ms range to find the optimal fit based
%on MMSE

time_range = [round(0.40*sf):round(1.05*sf)];
time_shift = [-round(0.005*sf):round(0.005*sf)];

temp_dep_var = dep_var(:,time_range);

for tap_regr = time_shift(1):time_shift(end)

temp_ind_var = circshift(ind_var(time_range,:)',[size(ind_var',1) tap_regr]);    
    temp_ind_var = temp_ind_var';
    
  [Q,R,e] = qr(temp_ind_var,0);
  
b(:,tap_regr + time_shift(end) + 1) = R\(Q'*temp_dep_var');
equation_dca_2_degree_temp = temp_ind_var(:,e)*b(:,tap_regr + time_shift(end) + 1);
temp_mse(1,tap_regr + time_shift(end) + 1) = sqrt(mean((temp_dep_var' - equation_dca_2_degree_temp).^2));
   
end
%Find the optimal "b"
best_b = b(:,find(temp_mse == min(temp_mse)));
%Calculating the prediction vector with the "b" that minimizes the Mean Square Error(MSE);
equation_dca_2_degree = ind_var(:,e)*best_b;

%Saving the info about the coefficient that minimizes the MSE 
var_regr.best_mse = find(temp_mse == min(temp_mse));
var_regr.coefficients = b;
var_regr.mse = temp_mse;
