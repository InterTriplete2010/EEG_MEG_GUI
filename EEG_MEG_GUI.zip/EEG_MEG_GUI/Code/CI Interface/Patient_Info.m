function varargout = Patient_Info(varargin)
% PATIENT_INFO MATLAB code for Patient_Info.fig
%      PATIENT_INFO, by itself, creates a new PATIENT_INFO or raises the existing
%      singleton*.
%
%      H = PATIENT_INFO returns the handle to a new PATIENT_INFO or the handle to
%      the existing singleton*.
%
%      PATIENT_INFO('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in PATIENT_INFO.M with the given input arguments.
%
%      PATIENT_INFO('Property','Value',...) creates a new PATIENT_INFO or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before Patient_Info_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to Patient_Info_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help Patient_Info

% Last Modified by GUIDE v2.5 01-Jul-2016 13:27:08

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Patient_Info_OpeningFcn, ...
                   'gui_OutputFcn',  @Patient_Info_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before Patient_Info is made visible.
function Patient_Info_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to Patient_Info (see VARARGIN)

% Choose default command line output for Patient_Info
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes Patient_Info wait for user response (see UIRESUME)
% uiwait(handles.figure1);
global First_name_track;
global Last_name_track;
global ID_track;
global month_track;
global day_track;
global year_track;
global Sex_track;
global Ear_track;
global Appointment_Track;

First_name_track = 0;
Last_name_track = 0;
ID_track = 0;
month_track = 0;
day_track = 0;
year_track = 0;
Sex_track = 0;
Ear_track = 0;
Appointment_Track = 0;


        try
    
            info_existing_patient_uploaded = varargin{1,1};
    info_retrieved = info_existing_patient_uploaded.info_ci_patient;
        
    set(handles.First_Name_CI_Patient,'String',info_retrieved.first_name);
    set(handles.Middle_Name_CI_Patient,'String',info_retrieved.middle_name);
    set(handles.Last_Name_CI_Patient,'String',info_retrieved.last_name);    
    set(handles.Month_CI_Patient,'String',info_retrieved.month);
    set(handles.Day_CI_Patient,'String',info_retrieved.day);
    set(handles.Year_CI_Patient,'String',info_retrieved.year);
    set(handles.Sex_CI_Patient,'String',info_retrieved.sex);
    set(handles.Ear_CI_Patient,'String',info_retrieved.ear);
    set(handles.Appointment_Date_CI,'String',info_retrieved.app_date);
    set(handles.Medical_Record_Number_CI,'String',info_retrieved.medical_rec);
    set(handles.ID_CI_Patient,'String',info_retrieved.ID);
    set(handles.Personal_Notes_CI,'String',info_retrieved.experiment_notes);
    set(handles.Tech_Info_CI,'String',info_retrieved.tech_info);
    
    set(handles.First_Name_Patient,'ForegroundColor',[0 0 0])
    set(handles.Ear_implanted_Patient,'ForegroundColor',[0 0 0])
    set(handles.Last_Name_Patient,'ForegroundColor',[0 0 0])
    set(handles.ID_Patient,'ForegroundColor',[0 0 0])
    set(handles.DOB_Patient,'ForegroundColor',[0 0 0])
    set(handles.Sex_Patient,'ForegroundColor',[0 0 0])
    set(handles.Appointment_Text,'ForegroundColor',[0 0 0])
    
        
        end
    
% --- Outputs from this function are returned to the command line.
function varargout = Patient_Info_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%First of the patient
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function First_Name_CI_Patient_Callback(hObject, eventdata, handles)
% hObject    handle to First_Name_CI_Patient (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of First_Name_CI_Patient as text
%        str2double(get(hObject,'String')) returns contents of First_Name_CI_Patient as a double
global First_name_track;

if (~isempty(get(handles.First_Name_CI_Patient,'String')))
        
        set(handles.First_Name_Patient,'ForegroundColor',[0 0 0])
    
        First_name_track = 1;
        
        end

% --- Executes during object creation, after setting all properties.
function First_Name_CI_Patient_CreateFcn(hObject, eventdata, handles)
% hObject    handle to First_Name_CI_Patient (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Ear implanted 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on selection change in Ear_CI_Patient.
function Ear_CI_Patient_Callback(hObject, eventdata, handles)
% hObject    handle to Ear_CI_Patient (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns Ear_CI_Patient contents as cell array
%        contents{get(hObject,'Value')} returns selected item from Ear_CI_Patient
global Ear_track;

if (get(handles.Ear_CI_Patient,'Value') ~= 1)
        
        set(handles.Ear_implanted_Patient,'ForegroundColor',[0 0 0])
    
        Ear_track = 1;
        
        end

% --- Executes during object creation, after setting all properties.
function Ear_CI_Patient_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Ear_CI_Patient (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Middle name of the patient
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Middle_Name_CI_Patient_Callback(hObject, eventdata, handles)
% hObject    handle to Middle_Name_CI_Patient (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Middle_Name_CI_Patient as text
%        str2double(get(hObject,'String')) returns contents of Middle_Name_CI_Patient as a double


% --- Executes during object creation, after setting all properties.
function Middle_Name_CI_Patient_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Middle_Name_CI_Patient (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Last name of the patient
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Last_Name_CI_Patient_Callback(hObject, eventdata, handles)
% hObject    handle to Last_Name_CI_Patient (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Last_Name_CI_Patient as text
%        str2double(get(hObject,'String')) returns contents of Last_Name_CI_Patient as a double
global Last_name_track;

if (~isempty(get(handles.Last_Name_CI_Patient,'String')))
        
        set(handles.Last_Name_Patient,'ForegroundColor',[0 0 0])
    
        Last_name_track = 1;
        
        end

% --- Executes during object creation, after setting all properties.
function Last_Name_CI_Patient_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Last_Name_CI_Patient (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%ID of the patient
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function ID_CI_Patient_Callback(hObject, eventdata, handles)
% hObject    handle to ID_CI_Patient (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ID_CI_Patient as text
%        str2double(get(hObject,'String')) returns contents of ID_CI_Patient as a double
global ID_track;

if (~isempty(get(handles.ID_CI_Patient,'String')))
        
        set(handles.ID_Patient,'ForegroundColor',[0 0 0])
    
        ID_track = 1;
end
        
% --- Executes during object creation, after setting all properties.
function ID_CI_Patient_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ID_CI_Patient (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Month of birth of the patient
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Month_CI_Patient_Callback(hObject, eventdata, handles)
% hObject    handle to Month_CI_Patient (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Month_CI_Patient as text
%        str2double(get(hObject,'String')) returns contents of Month_CI_Patient as a double
global month_track;
global day_track;
global year_track;

month_track = 0;

if (~isempty(get(handles.Month_CI_Patient,'String')))
    
    if ( 0 < str2double(get(handles.Month_CI_Patient,'String')) & str2double(get(handles.Month_CI_Patient,'String')) < 13)
    
        month_track = 1;
    
    else
        
        message = 'Please enter a valid month (1 - 12)';

        msgbox(message,'Invalid entry','warn');
        
        set(handles.Month_CI_Patient,'String',[]);
        
        return;
        
    end
end

try
    if ((month_track + day_track + year_track) == 3)
   
    set(handles.DOB_Patient,'ForegroundColor',[0 0 0])
    
    end
catch
    
end
     
        
% --- Executes during object creation, after setting all properties.
function Month_CI_Patient_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Month_CI_Patient (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Day of birth of the patient
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Day_CI_Patient_Callback(hObject, eventdata, handles)
% hObject    handle to Day_CI_Patient (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Day_CI_Patient as text
%        str2double(get(hObject,'String')) returns contents of Day_CI_Patient as a double
global month_track;
global day_track;
global year_track;

day_track = 0;

if (~isempty(get(handles.Day_CI_Patient,'String')))
        
        if ( 0 < str2double(get(handles.Day_CI_Patient,'String')) & str2double(get(handles.Day_CI_Patient,'String')) < 31)
    
        day_track = 1;
    
    else
        
        message = 'Please enter a valid day (1 - 31)';
        msgbox(message,'Invalid entry','warn');
        
        set(handles.Day_CI_Patient,'String',[]);
        
        return;
        
    end
    
end

try
    if ((month_track + day_track + year_track) == 3)
   
        set(handles.DOB_Patient,'ForegroundColor',[0 0 0])
    
    end
    
catch
end
        
% --- Executes during object creation, after setting all properties.
function Day_CI_Patient_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Day_CI_Patient (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Year of birth of the patient
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Year_CI_Patient_Callback(hObject, eventdata, handles)
% hObject    handle to Year_CI_Patient (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Year_CI_Patient as text
%        str2double(get(hObject,'String')) returns contents of Year_CI_Patient as a double
global month_track;
global day_track;
global year_track;

year_track = 0;

if (~isempty(get(handles.Year_CI_Patient,'String')))
    
     if (length(get(handles.Year_CI_Patient,'String')) < 4)
    
         message = 'Please enter a valid year (i.e. 1977)';
        msgbox(message,'Invalid entry','warn');
        
        set(handles.Year_CI_Patient,'String',[]);
        
     else
         
            year_track = 1;
    
     end
        
end

try
    if ((month_track + day_track + year_track) == 3)
   
        set(handles.DOB_Patient,'ForegroundColor',[0 0 0])
    
    end
    
catch
    
end
        
% --- Executes during object creation, after setting all properties.
function Year_CI_Patient_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Year_CI_Patient (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Sex of the patient
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Sex_CI_Patient_Callback(hObject, eventdata, handles)
% hObject    handle to Sex_CI_Patient (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Sex_CI_Patient as text
%        str2double(get(hObject,'String')) returns contents of Sex_CI_Patient as a double
global Sex_track;

Sex_track = 0;

if (get(handles.Sex_CI_Patient,'Value') ~= 1)
        
        set(handles.Sex_Patient,'ForegroundColor',[0 0 0])
    
        Sex_track = 1;
        
        end
        
% --- Executes during object creation, after setting all properties.
function Sex_CI_Patient_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Sex_CI_Patient (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Checking if the info has been entered correctly and save them
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in Save_info_CI_Patient.
function Save_info_CI_Patient_Callback(hObject, eventdata, handles)
% hObject    handle to Save_info_CI_Patient (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global First_name_track;
global Last_name_track;
global ID_track;
global month_track;
global day_track;
global year_track;
global Sex_track;
global Ear_track;
global Appointment_Track;
global check_patient_info;
global ID_patient;
global appointment_date_info;


info_ci_patient = [];

%% Checking that each field has been filled out 

check_patient_info = (First_name_track + Last_name_track + ID_track + month_track + day_track + year_track + Sex_track + Ear_track + Appointment_Track);

if (check_patient_info == 9)
    
    info_ci_patient.first_name = get(handles.First_Name_CI_Patient,'String');
    info_ci_patient.middle_name = get(handles.Middle_Name_CI_Patient,'String');
    info_ci_patient.last_name = get(handles.Last_Name_CI_Patient,'String');
    info_ci_patient.ID = get(handles.ID_CI_Patient,'String');
    info_ci_patient.month = get(handles.Month_CI_Patient,'String');
    info_ci_patient.day = get(handles.Day_CI_Patient,'String');
    info_ci_patient.year = get(handles.Year_CI_Patient,'String');
    
    sex_options = get(handles.Sex_CI_Patient,'String');
    info_ci_patient.sex = cell2mat(sex_options(get(handles.Sex_CI_Patient,'Value')));
    
    ear_options = get(handles.Ear_CI_Patient,'String');
    info_ci_patient.ear = cell2mat(ear_options(get(handles.Ear_CI_Patient,'Value')));
     
    ID_patient = get(handles.ID_CI_Patient,'String');
    
    info_ci_patient.app_date = get(handles.Appointment_Date_CI,'String');
    
    info_ci_patient.medical_rec = get(handles.Medical_Record_Number_CI,'String');
    
    info_ci_patient.experiment_notes = get(handles.Personal_Notes_CI,'String');
    
    info_ci_patient.tech_info = get(handles.Tech_Info_CI,'String');
    
    save ([info_ci_patient.ID '_Patient_Info'],'info_ci_patient')
    
    message = 'Information for the patient has been saved';
        msgbox(message,'','warn');
    
else
    
    message = 'One or more fields have not been filled out.';
        msgbox(message,'Incomplete information','warn');
    
end
    

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Save the medical record number, if known
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in Medical_Record_Number_CI.
function Medical_Record_Number_CI_Callback(hObject, eventdata, handles)
% hObject    handle to Medical_Record_Number_CI (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes during object creation, after setting all properties.
function Medical_Record_Number_CI_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Medical_Record_Number_CI (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Save the date of the appointment
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Appointment_Date_CI_Callback(hObject, eventdata, handles)
% hObject    handle to Appointment_Date_CI (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Appointment_Date_CI as text
%        str2double(get(hObject,'String')) returns contents of Appointment_Date_CI as a double
global Appointment_Track;

Appointment_Track = 0;

if (~isempty(get(handles.Appointment_Date_CI,'String')))
           
             Appointment_Track = 1;
    
             set(handles.Appointment_Text,'ForegroundColor',[0 0 0])
     
end
        

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Notes about the experiment
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes during object creation, after setting all properties.
function Appointment_Date_CI_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Appointment_Date_CI (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function Personal_Notes_CI_Callback(hObject, eventdata, handles)
% hObject    handle to Personal_Notes_CI (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Personal_Notes_CI as text
%        str2double(get(hObject,'String')) returns contents of Personal_Notes_CI as a double


% --- Executes during object creation, after setting all properties.
function Personal_Notes_CI_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Personal_Notes_CI (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Notes about CI device
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Tech_Info_CI_Callback(hObject, eventdata, handles)
% hObject    handle to Tech_Info_CI (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Tech_Info_CI as text
%        str2double(get(hObject,'String')) returns contents of Tech_Info_CI as a double


% --- Executes during object creation, after setting all properties.
function Tech_Info_CI_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Tech_Info_CI (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
