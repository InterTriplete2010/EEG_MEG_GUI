function plot_av_circle(struct_eeg_circle,handles)

electrodes_averaged = struct_eeg_circle.data_exported.labels;

%% List of the available electrodes
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Left Hemisphere
%Fp1
temp_Fp1 = handles.Fp1;
prop_Fp1 = get(temp_Fp1);
tag_Fp1 = prop_Fp1.Tag;

clean_plot = get(temp_Fp1,'Children');
delete(clean_plot)

%AF3
temp_AF3 = handles.AF3;
prop_AF3 = get(temp_AF3);
tag_AF3 = prop_AF3.Tag;

clean_plot = get(temp_AF3,'Children');
delete(clean_plot)

%F7
temp_F7 = handles.F7;
prop_F7 = get(temp_F7);
tag_F7 = prop_F7.Tag;

clean_plot = get(temp_F7,'Children');
delete(clean_plot)

%F3
temp_F3 = handles.F3;
prop_F3 = get(temp_F3);
tag_F3 = prop_F3.Tag;

clean_plot = get(temp_F3,'Children');
delete(clean_plot)

%FC1
temp_FC1 = handles.FC1;
prop_FC1 = get(temp_FC1);
tag_FC1 = prop_FC1.Tag;

clean_plot = get(temp_FC1,'Children');
delete(clean_plot)

%FC5
temp_FC5 = handles.FC5;
prop_FC5 = get(temp_FC5);
tag_FC5 = prop_FC5.Tag;

clean_plot = get(temp_FC5,'Children');
delete(clean_plot)

%T7
temp_T7 = handles.T7;
prop_T7 = get(temp_T7);
tag_T7 = prop_T7.Tag;

clean_plot = get(temp_T7,'Children');
delete(clean_plot)

%C3
temp_C3 = handles.C3;
prop_C3 = get(temp_C3);
tag_C3 = prop_C3.Tag;

clean_plot = get(temp_C3,'Children');
delete(clean_plot)

%CP1
temp_CP1 = handles.CP1;
prop_CP1 = get(temp_CP1);
tag_CP1 = prop_CP1.Tag;

clean_plot = get(temp_CP1,'Children');
delete(clean_plot)

%CP5
temp_CP5 = handles.CP5;
prop_CP5 = get(temp_CP5);
tag_CP5 = prop_CP5.Tag;

clean_plot = get(temp_CP5,'Children');
delete(clean_plot)

%P7
temp_P7 = handles.P7;
prop_P7 = get(temp_P7);
tag_P7 = prop_P7.Tag;

clean_plot = get(temp_P7,'Children');
delete(clean_plot)

%P3
temp_P3 = handles.P3;
prop_P3 = get(temp_P3);
tag_P3 = prop_P3.Tag;

clean_plot = get(temp_P3,'Children');
delete(clean_plot)

%PO3
temp_PO3 = handles.PO3;
prop_PO3 = get(temp_PO3);
tag_PO3 = prop_PO3.Tag;

clean_plot = get(temp_PO3,'Children');
delete(clean_plot)

%O1
temp_O1 = handles.O1;
prop_O1 = get(temp_O1);
tag_O1 = prop_O1.Tag;

clean_plot = get(temp_O1,'Children');
delete(clean_plot)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Midline
%Pz
temp_Pz = handles.Pz;
prop_Pz = get(temp_Pz);
tag_Pz = prop_Pz.Tag;

clean_plot = get(temp_Pz,'Children');
delete(clean_plot)

%Fz
temp_Fz = handles.Fz;
prop_Fz = get(temp_Fz);
tag_Fz = prop_Fz.Tag;

clean_plot = get(temp_Fz,'Children');
delete(clean_plot)

%Cz
temp_Cz = handles.Cz;
prop_Cz = get(temp_Cz);
tag_Cz = prop_Cz.Tag;

clean_plot = get(temp_Cz,'Children');
delete(clean_plot)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Right Hemisphere
%O2
temp_O2 = handles.O2;
prop_O2 = get(temp_O2);
tag_O2 = prop_O2.Tag;

clean_plot = get(temp_O2,'Children');
delete(clean_plot)

%PO4
temp_PO4 = handles.PO4;
prop_PO4 = get(temp_PO4);
tag_PO4 = prop_PO4.Tag;

clean_plot = get(temp_PO4,'Children');
delete(clean_plot)

%P8
temp_P4 = handles.P4;
prop_P4 = get(temp_P4);
tag_P4 = prop_P4.Tag;

clean_plot = get(temp_P4,'Children');
delete(clean_plot)

%P8
temp_P8 = handles.P8;
prop_P8 = get(temp_P8);
tag_P8 = prop_P8.Tag;

clean_plot = get(temp_P8,'Children');
delete(clean_plot)

%CP6
temp_CP6 = handles.CP6;
prop_CP6 = get(temp_CP6);
tag_CP6 = prop_CP6.Tag;

clean_plot = get(temp_CP6,'Children');
delete(clean_plot)

%CP2
temp_CP2 = handles.CP2;
prop_CP2 = get(temp_CP2);
tag_CP2 = prop_CP2.Tag;

clean_plot = get(temp_CP2,'Children');
delete(clean_plot)

%C4
temp_C4 = handles.C4;
prop_C4 = get(temp_C4);
tag_C4 = prop_C4.Tag;

clean_plot = get(temp_C4,'Children');
delete(clean_plot)

%T8
temp_T8 = handles.T8;
prop_T8 = get(temp_T8);
tag_T8 = prop_T8.Tag;

clean_plot = get(temp_T8,'Children');
delete(clean_plot)

%FC6
temp_FC6 = handles.FC6;
prop_FC6 = get(temp_FC6);
tag_FC6 = prop_FC6.Tag;

clean_plot = get(temp_FC6,'Children');
delete(clean_plot)

%FC2
temp_FC2 = handles.FC2;
prop_FC2 = get(temp_FC2);
tag_FC2 = prop_FC2.Tag;

clean_plot = get(temp_FC2,'Children');
delete(clean_plot)

%F4
temp_F4 = handles.F4;
prop_F4 = get(temp_F4);
tag_F4 = prop_F4.Tag;

clean_plot = get(temp_F4,'Children');
delete(clean_plot)

%F8
temp_F8 = handles.F8;
prop_F8 = get(temp_F8);
tag_F8 = prop_F8.Tag;

clean_plot = get(temp_F8,'Children');
delete(clean_plot)

%AF4
temp_AF4 = handles.AF4;
prop_AF4 = get(temp_AF4);
tag_AF4 = prop_AF4.Tag;

clean_plot = get(temp_AF4,'Children');
delete(clean_plot)

%Fp2
temp_FP2 = handles.FP2;
prop_FP2 = get(temp_FP2);
tag_FP2 = prop_FP2.Tag;

clean_plot = get(temp_FP2,'Children');
delete(clean_plot)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Eye electrodes
%VEOG
temp_VEOG = handles.VEOG;
prop_VEOG = get(temp_VEOG);
tag_VEOG = prop_VEOG.Tag;

clean_plot = get(temp_VEOG,'Children');
delete(clean_plot)

%HEOG
temp_HEOG = handles.HEOG;
prop_HEOG = get(temp_HEOG);
tag_HEOG = prop_HEOG.Tag;

clean_plot = get(temp_HEOG,'Children');
delete(clean_plot)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Reference electrodes
%A1
temp_A1 = handles.A1;
prop_A1 = get(temp_A1);
tag_A1 = prop_A1.Tag;

clean_plot = get(temp_A1,'Children');
delete(clean_plot)

%A2
temp_A2 = handles.A2;
prop_A2 = get(temp_A2);
tag_A2 = prop_A2.Tag;

clean_plot = get(temp_A2,'Children');
delete(clean_plot)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Detrmining which electrodes need to be plotted
for kk = 1:length(electrodes_averaged)    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %Fp1
    if (strcmp(tag_Fp1,cell2mat(electrodes_averaged(kk)))) 
        
    set(temp_Fp1,'Visible','on');
        set(gcf,'CurrentAxes',temp_Fp1);
            plot(struct_eeg_circle.data_exported.time_average,struct_eeg_circle.data_exported.average_trials(kk,:))
       
            axis tight
               
               find_onset = find(struct_eeg_circle.data_exported.time_average >= 0,1,'First');
               
               hold on
               
               plot([struct_eeg_circle.data_exported.time_average(find_onset) struct_eeg_circle.data_exported.time_average(find_onset)],[min(struct_eeg_circle.data_exported.average_trials(kk,:)) max(struct_eeg_circle.data_exported.average_trials(kk,:))],'k')
            
               hold off
            
            set(temp_Fp1,'Box','off')
             title('\bfFp1')           
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %AF3
    elseif (strcmp(tag_AF3,cell2mat(electrodes_averaged(kk)))) 
        
    set(temp_AF3,'Visible','on');
        set(gcf,'CurrentAxes',temp_AF3);
            plot(struct_eeg_circle.data_exported.time_average,struct_eeg_circle.data_exported.average_trials(kk,:))
       
            axis tight
               
               find_onset = find(struct_eeg_circle.data_exported.time_average >= 0,1,'First');
               
               hold on
               
               plot([struct_eeg_circle.data_exported.time_average(find_onset) struct_eeg_circle.data_exported.time_average(find_onset)],[min(struct_eeg_circle.data_exported.average_trials(kk,:)) max(struct_eeg_circle.data_exported.average_trials(kk,:))],'k')
            
               hold off
            
            set(temp_AF3,'Box','off')
            title('\bfAF3')
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %F7
    elseif (strcmp(tag_F7,cell2mat(electrodes_averaged(kk)))) 
        
    set(temp_F7,'Visible','on');
        set(gcf,'CurrentAxes',temp_F7);
            plot(struct_eeg_circle.data_exported.time_average,struct_eeg_circle.data_exported.average_trials(kk,:))
            
            axis tight
               
               find_onset = find(struct_eeg_circle.data_exported.time_average >= 0,1,'First');
               
               hold on
               
               plot([struct_eeg_circle.data_exported.time_average(find_onset) struct_eeg_circle.data_exported.time_average(find_onset)],[min(struct_eeg_circle.data_exported.average_trials(kk,:)) max(struct_eeg_circle.data_exported.average_trials(kk,:))],'k')
            
               hold off
            
            set(temp_F7,'Box','off')
    title('\bfF7')
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %F3
    elseif (strcmp(tag_F3,cell2mat(electrodes_averaged(kk)))) 
        
    set(temp_F3,'Visible','on');
        set(gcf,'CurrentAxes',temp_F3);
            plot(struct_eeg_circle.data_exported.time_average,struct_eeg_circle.data_exported.average_trials(kk,:))
       
            axis tight
               
               find_onset = find(struct_eeg_circle.data_exported.time_average >= 0,1,'First');
               
               hold on
               
               plot([struct_eeg_circle.data_exported.time_average(find_onset) struct_eeg_circle.data_exported.time_average(find_onset)],[min(struct_eeg_circle.data_exported.average_trials(kk,:)) max(struct_eeg_circle.data_exported.average_trials(kk,:))],'k')
            
               hold off
            
            set(temp_F3,'Box','off')
              title('\bfF3')          
   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%       
           
   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %FC1
    elseif (strcmp(tag_FC1,cell2mat(electrodes_averaged(kk)))) 
        
    set(temp_FC1,'Visible','on');
        set(gcf,'CurrentAxes',temp_FC1);
            plot(struct_eeg_circle.data_exported.time_average,struct_eeg_circle.data_exported.average_trials(kk,:))
       
            axis tight
               
               find_onset = find(struct_eeg_circle.data_exported.time_average >= 0,1,'First');
               
               hold on
               
               plot([struct_eeg_circle.data_exported.time_average(find_onset) struct_eeg_circle.data_exported.time_average(find_onset)],[min(struct_eeg_circle.data_exported.average_trials(kk,:)) max(struct_eeg_circle.data_exported.average_trials(kk,:))],'k')
            
               hold off
            
            set(temp_FC1,'Box','off')
                      title('\bfFC1')  
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%       
   
   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %FC5
    elseif (strcmp(tag_FC5,cell2mat(electrodes_averaged(kk)))) 
        
    set(temp_FC5,'Visible','on');
        set(gcf,'CurrentAxes',temp_FC5);
            plot(struct_eeg_circle.data_exported.time_average,struct_eeg_circle.data_exported.average_trials(kk,:))
       
            axis tight
               
               find_onset = find(struct_eeg_circle.data_exported.time_average >= 0,1,'First');
               
               hold on
               
               plot([struct_eeg_circle.data_exported.time_average(find_onset) struct_eeg_circle.data_exported.time_average(find_onset)],[min(struct_eeg_circle.data_exported.average_trials(kk,:)) max(struct_eeg_circle.data_exported.average_trials(kk,:))],'k')
            
               hold off
            
            set(temp_FC5,'Box','off')
                        title('\bfFC5')
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%       
   
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %T7
    elseif (strcmp(tag_T7,cell2mat(electrodes_averaged(kk)))) 
        
    set(temp_T7,'Visible','on');
        set(gcf,'CurrentAxes',temp_T7);
            plot(struct_eeg_circle.data_exported.time_average,struct_eeg_circle.data_exported.average_trials(kk,:))
       
            axis tight
               
               find_onset = find(struct_eeg_circle.data_exported.time_average >= 0,1,'First');
               
               hold on
               
               plot([struct_eeg_circle.data_exported.time_average(find_onset) struct_eeg_circle.data_exported.time_average(find_onset)],[min(struct_eeg_circle.data_exported.average_trials(kk,:)) max(struct_eeg_circle.data_exported.average_trials(kk,:))],'k')
            
               hold off
            
            set(temp_T7,'Box','off')
                 title('\bfT7')       
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%       
   
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %C3
    elseif (strcmp(tag_C3,cell2mat(electrodes_averaged(kk)))) 
        
    set(temp_C3,'Visible','on');
        set(gcf,'CurrentAxes',temp_C3);
            plot(struct_eeg_circle.data_exported.time_average,struct_eeg_circle.data_exported.average_trials(kk,:))
       
            axis tight
               
               find_onset = find(struct_eeg_circle.data_exported.time_average >= 0,1,'First');
               
               hold on
               
               plot([struct_eeg_circle.data_exported.time_average(find_onset) struct_eeg_circle.data_exported.time_average(find_onset)],[min(struct_eeg_circle.data_exported.average_trials(kk,:)) max(struct_eeg_circle.data_exported.average_trials(kk,:))],'k')
            
               hold off
            
            set(temp_C3,'Box','off')
                 title('\bfC3')       
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%       
   
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %CP1
    elseif (strcmp(tag_CP1,cell2mat(electrodes_averaged(kk)))) 
        
    set(temp_CP1,'Visible','on');
        set(gcf,'CurrentAxes',temp_CP1);
            plot(struct_eeg_circle.data_exported.time_average,struct_eeg_circle.data_exported.average_trials(kk,:))
       
            axis tight
               
               find_onset = find(struct_eeg_circle.data_exported.time_average >= 0,1,'First');
               
               hold on
               
               plot([struct_eeg_circle.data_exported.time_average(find_onset) struct_eeg_circle.data_exported.time_average(find_onset)],[min(struct_eeg_circle.data_exported.average_trials(kk,:)) max(struct_eeg_circle.data_exported.average_trials(kk,:))],'k')
            
               hold off
            
            set(temp_CP1,'Box','off')
                  title('\bfCP1')      
   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%       
   
   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %CP5
    elseif (strcmp(tag_CP5,cell2mat(electrodes_averaged(kk)))) 
        
    set(temp_CP5,'Visible','on');
        set(gcf,'CurrentAxes',temp_CP5);
            plot(struct_eeg_circle.data_exported.time_average,struct_eeg_circle.data_exported.average_trials(kk,:))
       
            axis tight
               
               find_onset = find(struct_eeg_circle.data_exported.time_average >= 0,1,'First');
               
               hold on
               
               plot([struct_eeg_circle.data_exported.time_average(find_onset) struct_eeg_circle.data_exported.time_average(find_onset)],[min(struct_eeg_circle.data_exported.average_trials(kk,:)) max(struct_eeg_circle.data_exported.average_trials(kk,:))],'k')
            
               hold off
            
            set(temp_CP5,'Box','off')
                  title('\bfCP5')      
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%       
   
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %P7
    elseif (strcmp(tag_P7,cell2mat(electrodes_averaged(kk)))) 
        
    set(temp_P7,'Visible','on');
        set(gcf,'CurrentAxes',temp_P7);
            plot(struct_eeg_circle.data_exported.time_average,struct_eeg_circle.data_exported.average_trials(kk,:))
       
            axis tight
               
               find_onset = find(struct_eeg_circle.data_exported.time_average >= 0,1,'First');
               
               hold on
               
               plot([struct_eeg_circle.data_exported.time_average(find_onset) struct_eeg_circle.data_exported.time_average(find_onset)],[min(struct_eeg_circle.data_exported.average_trials(kk,:)) max(struct_eeg_circle.data_exported.average_trials(kk,:))],'k')
            
               hold off
            
            set(temp_P7,'Box','off')
                  title('\bfP7')      
   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%       
   
   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %P3
    elseif (strcmp(tag_P3,cell2mat(electrodes_averaged(kk)))) 
        
    set(temp_P3,'Visible','on');
        set(gcf,'CurrentAxes',temp_P3);
            plot(struct_eeg_circle.data_exported.time_average,struct_eeg_circle.data_exported.average_trials(kk,:))
       
            axis tight
               
               find_onset = find(struct_eeg_circle.data_exported.time_average >= 0,1,'First');
               
               hold on
               
               plot([struct_eeg_circle.data_exported.time_average(find_onset) struct_eeg_circle.data_exported.time_average(find_onset)],[min(struct_eeg_circle.data_exported.average_trials(kk,:)) max(struct_eeg_circle.data_exported.average_trials(kk,:))],'k')
            
               hold off
            
            set(temp_P3,'Box','off')
                  title('\bfP3')      
   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%       
   
   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %PO3
    elseif (strcmp(tag_PO3,cell2mat(electrodes_averaged(kk)))) 
        
    set(temp_PO3,'Visible','on');
        set(gcf,'CurrentAxes',temp_PO3);
            plot(struct_eeg_circle.data_exported.time_average,struct_eeg_circle.data_exported.average_trials(kk,:))
       
            axis tight
               
               find_onset = find(struct_eeg_circle.data_exported.time_average >= 0,1,'First');
               
               hold on
               
               plot([struct_eeg_circle.data_exported.time_average(find_onset) struct_eeg_circle.data_exported.time_average(find_onset)],[min(struct_eeg_circle.data_exported.average_trials(kk,:)) max(struct_eeg_circle.data_exported.average_trials(kk,:))],'k')
            
               hold off
            
            set(temp_PO3,'Box','off')
                   title('\bfPO3')     
   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%       
   
   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %O1
    elseif (strcmp(tag_O1,cell2mat(electrodes_averaged(kk)))) 
        
    set(temp_O1,'Visible','on');
        set(gcf,'CurrentAxes',temp_O1);
            plot(struct_eeg_circle.data_exported.time_average,struct_eeg_circle.data_exported.average_trials(kk,:))
       
            axis tight
               
               find_onset = find(struct_eeg_circle.data_exported.time_average >= 0,1,'First');
               
               hold on
               
               plot([struct_eeg_circle.data_exported.time_average(find_onset) struct_eeg_circle.data_exported.time_average(find_onset)],[min(struct_eeg_circle.data_exported.average_trials(kk,:)) max(struct_eeg_circle.data_exported.average_trials(kk,:))],'k')
            
               hold off
            
            set(temp_O1,'Box','off')
                   title('\bfO1')     
   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%       
   
   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %O2
    elseif (strcmp(tag_O2,cell2mat(electrodes_averaged(kk)))) 
        
    set(temp_O2,'Visible','on');
        set(gcf,'CurrentAxes',temp_O2);
            plot(struct_eeg_circle.data_exported.time_average,struct_eeg_circle.data_exported.average_trials(kk,:))
       
            axis tight
               
               find_onset = find(struct_eeg_circle.data_exported.time_average >= 0,1,'First');
               
               hold on
               
               plot([struct_eeg_circle.data_exported.time_average(find_onset) struct_eeg_circle.data_exported.time_average(find_onset)],[min(struct_eeg_circle.data_exported.average_trials(kk,:)) max(struct_eeg_circle.data_exported.average_trials(kk,:))],'k')
            
               hold off
            
            set(temp_O2,'Box','off')
                    title('\bfO2')    
   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%       
   
   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %PO4
    elseif (strcmp(tag_PO4,cell2mat(electrodes_averaged(kk)))) 
        
    set(temp_PO4,'Visible','on');
        set(gcf,'CurrentAxes',temp_PO4);
            plot(struct_eeg_circle.data_exported.time_average,struct_eeg_circle.data_exported.average_trials(kk,:))
       
            axis tight
               
               find_onset = find(struct_eeg_circle.data_exported.time_average >= 0,1,'First');
               
               hold on
               
               plot([struct_eeg_circle.data_exported.time_average(find_onset) struct_eeg_circle.data_exported.time_average(find_onset)],[min(struct_eeg_circle.data_exported.average_trials(kk,:)) max(struct_eeg_circle.data_exported.average_trials(kk,:))],'k')
            
               hold off
            
            set(temp_PO4,'Box','off')         
                title('\bfPO4')
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %P4
    elseif (strcmp(tag_P4,cell2mat(electrodes_averaged(kk)))) 
        
    set(temp_P4,'Visible','on');
        set(gcf,'CurrentAxes',temp_P4);
            plot(struct_eeg_circle.data_exported.time_average,struct_eeg_circle.data_exported.average_trials(kk,:))
       
            axis tight
               
               find_onset = find(struct_eeg_circle.data_exported.time_average >= 0,1,'First');
               
               hold on
               
               plot([struct_eeg_circle.data_exported.time_average(find_onset) struct_eeg_circle.data_exported.time_average(find_onset)],[min(struct_eeg_circle.data_exported.average_trials(kk,:)) max(struct_eeg_circle.data_exported.average_trials(kk,:))],'k')
            
               hold off
            
            set(temp_P4,'Box','off')         
                    title('\bfP4')
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %P8
    elseif (strcmp(tag_P8,cell2mat(electrodes_averaged(kk)))) 
        
    set(temp_P8,'Visible','on');
        set(gcf,'CurrentAxes',temp_P8);
            plot(struct_eeg_circle.data_exported.time_average,struct_eeg_circle.data_exported.average_trials(kk,:))
       
            axis tight
               
               find_onset = find(struct_eeg_circle.data_exported.time_average >= 0,1,'First');
               
               hold on
               
               plot([struct_eeg_circle.data_exported.time_average(find_onset) struct_eeg_circle.data_exported.time_average(find_onset)],[min(struct_eeg_circle.data_exported.average_trials(kk,:)) max(struct_eeg_circle.data_exported.average_trials(kk,:))],'k')
            
               hold off
            
            set(temp_P8,'Box','off')
                    title('\bfP8')
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %CP6
    elseif (strcmp(tag_CP6,cell2mat(electrodes_averaged(kk)))) 
        
    set(temp_CP6,'Visible','on');
        set(gcf,'CurrentAxes',temp_CP6);
            plot(struct_eeg_circle.data_exported.time_average,struct_eeg_circle.data_exported.average_trials(kk,:))
       
            axis tight
               
               find_onset = find(struct_eeg_circle.data_exported.time_average >= 0,1,'First');
               
               hold on
               
               plot([struct_eeg_circle.data_exported.time_average(find_onset) struct_eeg_circle.data_exported.time_average(find_onset)],[min(struct_eeg_circle.data_exported.average_trials(kk,:)) max(struct_eeg_circle.data_exported.average_trials(kk,:))],'k')
            
               hold off
            
            set(temp_CP6,'Box','off') 
                        title('\bfCP6')
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %CP2
    elseif (strcmp(tag_CP2,cell2mat(electrodes_averaged(kk)))) 
        
    set(temp_CP2,'Visible','on');
        set(gcf,'CurrentAxes',temp_CP2);
            plot(struct_eeg_circle.data_exported.time_average,struct_eeg_circle.data_exported.average_trials(kk,:))
       
            axis tight
               
               find_onset = find(struct_eeg_circle.data_exported.time_average >= 0,1,'First');
               
               hold on
               
               plot([struct_eeg_circle.data_exported.time_average(find_onset) struct_eeg_circle.data_exported.time_average(find_onset)],[min(struct_eeg_circle.data_exported.average_trials(kk,:)) max(struct_eeg_circle.data_exported.average_trials(kk,:))],'k')
            
               hold off
            
            set(temp_CP2,'Box','off')
                    title('\bfCP2')
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %C4
    elseif (strcmp(tag_C4,cell2mat(electrodes_averaged(kk)))) 
        
    set(temp_C4,'Visible','on');
        set(gcf,'CurrentAxes',temp_C4);
            plot(struct_eeg_circle.data_exported.time_average,struct_eeg_circle.data_exported.average_trials(kk,:))
       
            axis tight
               
               find_onset = find(struct_eeg_circle.data_exported.time_average >= 0,1,'First');
               
               hold on
               
               plot([struct_eeg_circle.data_exported.time_average(find_onset) struct_eeg_circle.data_exported.time_average(find_onset)],[min(struct_eeg_circle.data_exported.average_trials(kk,:)) max(struct_eeg_circle.data_exported.average_trials(kk,:))],'k')
            
               hold off
            
            set(temp_C4,'Box','off')         
                    title('\bfC4')
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %T8
    elseif (strcmp(tag_T8,cell2mat(electrodes_averaged(kk)))) 
        
    set(temp_T8,'Visible','on');
        set(gcf,'CurrentAxes',temp_T8);
            plot(struct_eeg_circle.data_exported.time_average,struct_eeg_circle.data_exported.average_trials(kk,:))
       
            axis tight
               
               find_onset = find(struct_eeg_circle.data_exported.time_average >= 0,1,'First');
               
               hold on
               
               plot([struct_eeg_circle.data_exported.time_average(find_onset) struct_eeg_circle.data_exported.time_average(find_onset)],[min(struct_eeg_circle.data_exported.average_trials(kk,:)) max(struct_eeg_circle.data_exported.average_trials(kk,:))],'k')
            
               hold off
            
            set(temp_T8,'Box','off')         
                    title('\bfT8')
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %FC6
    elseif (strcmp(tag_FC6,cell2mat(electrodes_averaged(kk)))) 
        
    set(temp_FC6,'Visible','on');
        set(gcf,'CurrentAxes',temp_FC6);
            plot(struct_eeg_circle.data_exported.time_average,struct_eeg_circle.data_exported.average_trials(kk,:))
       
            axis tight
               
               find_onset = find(struct_eeg_circle.data_exported.time_average >= 0,1,'First');
               
               hold on
               
               plot([struct_eeg_circle.data_exported.time_average(find_onset) struct_eeg_circle.data_exported.time_average(find_onset)],[min(struct_eeg_circle.data_exported.average_trials(kk,:)) max(struct_eeg_circle.data_exported.average_trials(kk,:))],'k')
            
               hold off
            
            set(temp_FC6,'Box','off')  
                title('\bfFC6')
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %FC2
    elseif (strcmp(tag_FC2,cell2mat(electrodes_averaged(kk)))) 
        
    set(temp_FC2,'Visible','on');
        set(gcf,'CurrentAxes',temp_FC2);
            plot(struct_eeg_circle.data_exported.time_average,struct_eeg_circle.data_exported.average_trials(kk,:))
       
            axis tight
               
               find_onset = find(struct_eeg_circle.data_exported.time_average >= 0,1,'First');
               
               hold on
               
               plot([struct_eeg_circle.data_exported.time_average(find_onset) struct_eeg_circle.data_exported.time_average(find_onset)],[min(struct_eeg_circle.data_exported.average_trials(kk,:)) max(struct_eeg_circle.data_exported.average_trials(kk,:))],'k')
            
               hold off
            
            set(temp_FC2,'Box','off')
                title('\bfFC2')
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %F4
    elseif (strcmp(tag_F4,cell2mat(electrodes_averaged(kk)))) 
        
    set(temp_F4,'Visible','on');
        set(gcf,'CurrentAxes',temp_F4);
            plot(struct_eeg_circle.data_exported.time_average,struct_eeg_circle.data_exported.average_trials(kk,:))
       
            axis tight
               
               find_onset = find(struct_eeg_circle.data_exported.time_average >= 0,1,'First');
               
               hold on
               
               plot([struct_eeg_circle.data_exported.time_average(find_onset) struct_eeg_circle.data_exported.time_average(find_onset)],[min(struct_eeg_circle.data_exported.average_trials(kk,:)) max(struct_eeg_circle.data_exported.average_trials(kk,:))],'k')
            
               hold off
            
            set(temp_F4,'Box','off')  
                        title('\bfF4')
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %F8
    elseif (strcmp(tag_F8,cell2mat(electrodes_averaged(kk)))) 
        
    set(temp_F8,'Visible','on');
        set(gcf,'CurrentAxes',temp_F8);
            plot(struct_eeg_circle.data_exported.time_average,struct_eeg_circle.data_exported.average_trials(kk,:))
       
            axis tight
               
               find_onset = find(struct_eeg_circle.data_exported.time_average >= 0,1,'First');
               
               hold on
               
               plot([struct_eeg_circle.data_exported.time_average(find_onset) struct_eeg_circle.data_exported.time_average(find_onset)],[min(struct_eeg_circle.data_exported.average_trials(kk,:)) max(struct_eeg_circle.data_exported.average_trials(kk,:))],'k')
            
               hold off
            
            set(temp_F8,'Box','off')  
                        title('\bfF8')
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %AF4
    elseif (strcmp(tag_AF4,cell2mat(electrodes_averaged(kk)))) 
        
    set(temp_AF4,'Visible','on');
        set(gcf,'CurrentAxes',temp_AF4);
            plot(struct_eeg_circle.data_exported.time_average,struct_eeg_circle.data_exported.average_trials(kk,:))
       
            axis tight
               
               find_onset = find(struct_eeg_circle.data_exported.time_average >= 0,1,'First');
               
               hold on
               
               plot([struct_eeg_circle.data_exported.time_average(find_onset) struct_eeg_circle.data_exported.time_average(find_onset)],[min(struct_eeg_circle.data_exported.average_trials(kk,:)) max(struct_eeg_circle.data_exported.average_trials(kk,:))],'k')
            
               hold off
            
            set(temp_AF4,'Box','off') 
                            title('\bfAF4')
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %FP2
    elseif (strcmp(tag_FP2,cell2mat(electrodes_averaged(kk)))) 
        
    set(temp_FP2,'Visible','on');
        set(gcf,'CurrentAxes',temp_FP2);
            plot(struct_eeg_circle.data_exported.time_average,struct_eeg_circle.data_exported.average_trials(kk,:))
       
            axis tight
               
               find_onset = find(struct_eeg_circle.data_exported.time_average >= 0,1,'First');
               
               hold on
               
               plot([struct_eeg_circle.data_exported.time_average(find_onset) struct_eeg_circle.data_exported.time_average(find_onset)],[min(struct_eeg_circle.data_exported.average_trials(kk,:)) max(struct_eeg_circle.data_exported.average_trials(kk,:))],'k')
            
               hold off
            
            set(temp_FP2,'Box','off')
                        title('\bfFp2')
   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %Pz
            elseif (strcmp(tag_Pz,cell2mat(electrodes_averaged(kk)))) 
        
    set(temp_Pz,'Visible','on');
        set(gcf,'CurrentAxes',temp_Pz);
            plot(struct_eeg_circle.data_exported.time_average,struct_eeg_circle.data_exported.average_trials(kk,:))
               axis tight
               
               find_onset = find(struct_eeg_circle.data_exported.time_average >= 0,1,'First');
               
               hold on
               
               plot([struct_eeg_circle.data_exported.time_average(find_onset) struct_eeg_circle.data_exported.time_average(find_onset)],[min(struct_eeg_circle.data_exported.average_trials(kk,:)) max(struct_eeg_circle.data_exported.average_trials(kk,:))],'k')
            
               hold off
               
               set(temp_Pz,'Box','off')         
                        title('\bfPz')
   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   %Fz
            elseif (strcmp(tag_Fz,cell2mat(electrodes_averaged(kk)))) 
        
    set(temp_Fz,'Visible','on');
        set(gcf,'CurrentAxes',temp_Fz);
            plot(struct_eeg_circle.data_exported.time_average,struct_eeg_circle.data_exported.average_trials(kk,:))
               axis tight
               
               find_onset = find(struct_eeg_circle.data_exported.time_average >= 0,1,'First');
               
               hold on
               
               plot([struct_eeg_circle.data_exported.time_average(find_onset) struct_eeg_circle.data_exported.time_average(find_onset)],[min(struct_eeg_circle.data_exported.average_trials(kk,:)) max(struct_eeg_circle.data_exported.average_trials(kk,:))],'k')
            
               hold off
               
               set(temp_Fz,'Box','off')
                        title('\bfFz')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %Cz
            elseif (strcmp(tag_Cz,cell2mat(electrodes_averaged(kk)))) 
        
    set(temp_Cz,'Visible','on');
        set(gcf,'CurrentAxes',temp_Cz);
            plot(struct_eeg_circle.data_exported.time_average,struct_eeg_circle.data_exported.average_trials(kk,:))
               axis tight
               
               find_onset = find(struct_eeg_circle.data_exported.time_average >= 0,1,'First');
               
               hold on
               
               plot([struct_eeg_circle.data_exported.time_average(find_onset) struct_eeg_circle.data_exported.time_average(find_onset)],[min(struct_eeg_circle.data_exported.average_trials(kk,:)) max(struct_eeg_circle.data_exported.average_trials(kk,:))],'k')
            
               hold off
               
               set(temp_Cz,'Box','off') 
                        title('\bfCz')
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %VEOG
            elseif (strcmp(tag_VEOG,cell2mat(electrodes_averaged(kk)))) 
        
    set(temp_VEOG,'Visible','on');
        set(gcf,'CurrentAxes',temp_VEOG);
            plot(struct_eeg_circle.data_exported.time_average,struct_eeg_circle.data_exported.average_trials(kk,:))
               axis tight
               
               find_onset = find(struct_eeg_circle.data_exported.time_average >= 0,1,'First');
               
               hold on
               
               plot([struct_eeg_circle.data_exported.time_average(find_onset) struct_eeg_circle.data_exported.time_average(find_onset)],[min(struct_eeg_circle.data_exported.average_trials(kk,:)) max(struct_eeg_circle.data_exported.average_trials(kk,:))],'k')
            
               hold off
               
               set(temp_VEOG,'Box','off')              
                        title('\bfVEOG')
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %HEOG
            elseif (strcmp(tag_HEOG,cell2mat(electrodes_averaged(kk)))) 
        
    set(temp_HEOG,'Visible','on');
        set(gcf,'CurrentAxes',temp_HEOG);
            plot(struct_eeg_circle.data_exported.time_average,struct_eeg_circle.data_exported.average_trials(kk,:))
               axis tight
               
               find_onset = find(struct_eeg_circle.data_exported.time_average >= 0,1,'First');
               
               hold on
               
               plot([struct_eeg_circle.data_exported.time_average(find_onset) struct_eeg_circle.data_exported.time_average(find_onset)],[min(struct_eeg_circle.data_exported.average_trials(kk,:)) max(struct_eeg_circle.data_exported.average_trials(kk,:))],'k')
            
               hold off
               
               set(temp_HEOG,'Box','off')              
                        title('\bfHEOG')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %A1
            elseif (strcmp(tag_A1,cell2mat(electrodes_averaged(kk)))) 
        
    set(temp_A1,'Visible','on');
        set(gcf,'CurrentAxes',temp_A1);
            plot(struct_eeg_circle.data_exported.time_average,struct_eeg_circle.data_exported.average_trials(kk,:))
               axis tight
               
               find_onset = find(struct_eeg_circle.data_exported.time_average >= 0,1,'First');
               
               hold on
               
               plot([struct_eeg_circle.data_exported.time_average(find_onset) struct_eeg_circle.data_exported.time_average(find_onset)],[min(struct_eeg_circle.data_exported.average_trials(kk,:)) max(struct_eeg_circle.data_exported.average_trials(kk,:))],'k')
            
               hold off
               
               set(temp_A1,'Box','off')               
                        title('\bfA1')
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %A2
            elseif (strcmp(tag_A2,cell2mat(electrodes_averaged(kk)))) 
        
    set(temp_A2,'Visible','on');
        set(gcf,'CurrentAxes',temp_A2);
            plot(struct_eeg_circle.data_exported.time_average,struct_eeg_circle.data_exported.average_trials(kk,:))
               axis tight
               
               find_onset = find(struct_eeg_circle.data_exported.time_average >= 0,1,'First');
               
               hold on
               
               plot([struct_eeg_circle.data_exported.time_average(find_onset) struct_eeg_circle.data_exported.time_average(find_onset)],[min(struct_eeg_circle.data_exported.average_trials(kk,:)) max(struct_eeg_circle.data_exported.average_trials(kk,:))],'k')
            
               hold off
               
               set(temp_A2,'Box','off')              
                        title('\bfA2')
    end

end

%axis off