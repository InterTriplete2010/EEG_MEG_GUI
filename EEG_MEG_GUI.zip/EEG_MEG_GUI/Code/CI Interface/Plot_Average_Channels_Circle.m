function varargout = Plot_Average_Channels_Circle(varargin)
% PLOT_AVERAGE_CHANNELS_CIRCLE MATLAB code for Plot_Average_Channels_Circle.fig
%      PLOT_AVERAGE_CHANNELS_CIRCLE, by itself, creates a new PLOT_AVERAGE_CHANNELS_CIRCLE or raises the existing
%      singleton*.
%
%      H = PLOT_AVERAGE_CHANNELS_CIRCLE returns the handle to a new PLOT_AVERAGE_CHANNELS_CIRCLE or the handle to
%      the existing singleton*.
%
%      PLOT_AVERAGE_CHANNELS_CIRCLE('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in PLOT_AVERAGE_CHANNELS_CIRCLE.M with the given input arguments.
%
%      PLOT_AVERAGE_CHANNELS_CIRCLE('Property','Value',...) creates a new PLOT_AVERAGE_CHANNELS_CIRCLE or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before Plot_Average_Channels_Circle_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to Plot_Average_Channels_Circle_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help Plot_Average_Channels_Circle

% Last Modified by GUIDE v2.5 29-Jun-2015 23:00:42

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Plot_Average_Channels_Circle_OpeningFcn, ...
                   'gui_OutputFcn',  @Plot_Average_Channels_Circle_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before Plot_Average_Channels_Circle is made visible.
function Plot_Average_Channels_Circle_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to Plot_Average_Channels_Circle (see VARARGIN)

% Choose default command line output for Plot_Average_Channels_Circle
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes Plot_Average_Channels_Circle wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = Plot_Average_Channels_Circle_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Plots the average of each electrode in a scalp map configuration
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in Plot_av_Scalp.
function Plot_av_Scalp_Callback(hObject, eventdata, handles)
% hObject    handle to Plot_av_Scalp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global struct_eeg_circle;

plot_av_circle(struct_eeg_circle,handles)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Upload the EEG file
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in Select_EEG_Circle.
function Select_EEG_Circle_Callback(hObject, eventdata, handles)
% hObject    handle to Select_EEG_Circle (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global struct_eeg_circle; 

[EEG_File_Circle,EEG_directory_Circle] = uigetfile('*.mat','Select the CI file');

cd(EEG_directory_Circle)
struct_eeg_circle = load(EEG_File_Circle);

set(handles.EEG_Selected_Circle,'String',EEG_File_Circle);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%EEG file selected
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function EEG_Selected_Circle_Callback(hObject, eventdata, handles)
% hObject    handle to EEG_Selected_Circle (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of EEG_Selected_Circle as text
%        str2double(get(hObject,'String')) returns contents of EEG_Selected_Circle as a double


% --- Executes during object creation, after setting all properties.
function EEG_Selected_Circle_CreateFcn(hObject, eventdata, handles)
% hObject    handle to EEG_Selected_Circle (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

   

% --- Executes on mouse press over axes background.
function Pz_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to Pz (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

zz = get(handles.Pz,'selectiontype');