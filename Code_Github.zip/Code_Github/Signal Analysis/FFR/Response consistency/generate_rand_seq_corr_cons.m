function generate_rand_seq_corr_cons (regions_limits,sweeps_needed,regions_to_be_created)

curr_dir = what;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Generating 4 different regions
if (regions_to_be_created == 2)
length_sequence = sweeps_needed;

r1_choices_odd = [1:2:regions_limits(1)];
r1_choices_even = [2:2:regions_limits(1)];

r2_choices_odd = [regions_limits(1) + 1:2:regions_limits(2)];
r2_choices_even = [regions_limits(1) + 2:2:regions_limits(2)];

r3_choices_odd = [regions_limits(2) + 1:2:regions_limits(3)];
r3_choices_even = [regions_limits(2) + 2:2:regions_limits(3)];

r4_choices_odd = [regions_limits(3) + 1:2:regions_limits(4)];
r4_choices_even = [regions_limits(3) + 2:2:regions_limits(4)];

%% Generating "N" unique integers for both rar and cond
r1_even = r1_choices_even((sort(randperm(length(r1_choices_even),length_sequence/2))));
r1_odd = r1_choices_odd((sort(randperm(length(r1_choices_even),length_sequence/2))));

r2_even = r2_choices_even((sort(randperm(length(r2_choices_even),length_sequence/2))));
r2_odd = r2_choices_odd((sort(randperm(length(r2_choices_even),length_sequence/2))));

r3_even = r3_choices_even((sort(randperm(length(r3_choices_even),length_sequence/2))));
r3_odd = r3_choices_odd((sort(randperm(length(r3_choices_even),length_sequence/2))));

r4_even = r4_choices_even((sort(randperm(length(r4_choices_even),length_sequence/2))));
r4_odd = r4_choices_odd((sort(randperm(length(r4_choices_even),length_sequence/2))));

save_seq = sort([r1_even r1_odd r2_even r2_odd r3_even r3_odd r4_even r4_odd])';

%Creating a folder where to save the randomized sequence
new_dir_seq = 'Randomized Seq (4 regions)';
mkdir(new_dir_seq)
cd([curr_dir.path '\' new_dir_seq])
save ('Random_Seq_Resp_cons_4_regions.mat','save_seq')
cd ..
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Generating 2 different regions with 300 interactions
else
   
    length_sequence = regions_limits(4);
save_seq = zeros(sweeps_needed,length_sequence/2);

   for kk = 1:sweeps_needed*2
   
r1_choices_odd = [1:2:regions_limits(4)];
r1_choices_even = [2:2:regions_limits(4)];
 
r1_even = r1_choices_even((sort(randperm(length(r1_choices_even),length_sequence/4))));
r1_odd = r1_choices_odd((sort(randperm(length(r1_choices_even),length_sequence/4))));
    
save_seq(kk,:) = sort([r1_even r1_odd])';

   end
 
%Creating a folder where to save the randomized sequence  
new_dir_seq = 'Randomized Seq (2 regions)';
mkdir(new_dir_seq)
cd([curr_dir.path '\' new_dir_seq]) 
save ('Random_Seq_Resp_cons_2_regions.mat','save_seq')
cd ..
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

end

message = 'The random sequence has been created and saved';

        msgbox(message,'Calculations completed','warn');


