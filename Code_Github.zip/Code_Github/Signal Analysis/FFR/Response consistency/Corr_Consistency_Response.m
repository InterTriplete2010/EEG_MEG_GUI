function Corr_Consistency_Response(Signal_directory,randomized_seq,regions_limits,start_t,end_t,region_selected_name)

cd(Signal_directory)

mat_files = dir;

[files_number] = size(mat_files,1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
%% Data are divided into 4 regions => The binomial of (4 2) is used to 
%% calcuate the number of comination without repetitions
num_regions = length(regions_limits);
num_corr_elem = 2;
num_comb = (factorial(num_regions)/(factorial(num_regions - num_corr_elem)*factorial(num_corr_elem)));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    

%% Uploading the sweeps that will be used for the analysis
reg_I = randomized_seq(find(randomized_seq <= regions_limits(1)));
reg_II = randomized_seq(find(randomized_seq > regions_limits(1),1,'First'):find(randomized_seq <= regions_limits(2),1,'Last'));
reg_III = randomized_seq(find(randomized_seq > regions_limits(2),1,'First'):find(randomized_seq <= regions_limits(3),1,'Last'));
reg_IV = randomized_seq(find(randomized_seq > regions_limits(3),1,'First'):find(randomized_seq <= regions_limits(4),1,'Last'));

%% Initializing the matrix where the results will be saved
corr_files = {zeros(files_number,num_comb + 1)};
corr_files(1,1) = {'File Name'};
corr_files(1,2) = {'Region I-II'};
corr_files(1,3) = {'Region I-III'};
corr_files(1,4) = {'Region I-IV'};
corr_files(1,5) = {'Region II-III'};
corr_files(1,6) = {'Region II-IV'};
corr_files(1,7) = {'Region III-IV'};

track_files = 0;

message = 'Data are being analyzed...';

        msgbox(message,'Calculations in progress...','warn');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%        
%% Calculating the correlation
for ii = 3:files_number
    
    if (strcmp(mat_files(ii).name(end-3:end), '.mat') == 1)

        track_files = track_files + 1;
        
  matrix_file = mat_files(ii).name;      
  
  load(matrix_file);

  %% Checking that the file has same number of sweeps for the two polarities
  
  if (size(data_exported.rar_sweeps,1) > size(data_exported.compr_sweeps,1))
      
      diff_pol = size(data_exported.rar_sweeps,1) - size(data_exported.compr_sweeps,1);
      data_exported.rar_sweeps(end-diff_pol + 1:end,:) = [];
      
  elseif (size(data_exported.rar_sweeps,1) < size(data_exported.compr_sweeps,1))
      
      diff_pol = size(data_exported.compr_sweeps,1) - size(data_exported.rar_sweeps,1);
      data_exported.compr_sweeps(end-diff_pol + 1:end,:) = [];
      
  end
  
  file_to_be_anal = zeros(size(data_exported.rar_sweeps,1) + size(data_exported.compr_sweeps,1),size(data_exported.rar_sweeps,2));
  file_to_be_anal(1:2:end,:) = data_exported.rar_sweeps;
  file_to_be_anal(2:2:end,:) = data_exported.compr_sweeps;
  
  try
  corr_files(track_files + 1,1) = {matrix_file};
    corr_files(track_files + 1,2) = {corr2(mean(file_to_be_anal(reg_I,start_t:end_t)),mean(file_to_be_anal(reg_II,start_t:end_t)))};
        corr_files(track_files + 1,3) = {corr2(mean(file_to_be_anal(reg_I,start_t:end_t)),mean(file_to_be_anal(reg_III,start_t:end_t)))};
            corr_files(track_files + 1,4) = {corr2(mean(file_to_be_anal(reg_I,start_t:end_t)),mean(file_to_be_anal(reg_IV,start_t:end_t)))};
                corr_files(track_files + 1,5) = {corr2(mean(file_to_be_anal(reg_II,start_t:end_t)),mean(file_to_be_anal(reg_III,start_t:end_t)))};
                    corr_files(track_files + 1,6) = {corr2(mean(file_to_be_anal(reg_II,start_t:end_t)),mean(file_to_be_anal(reg_IV,start_t:end_t)))};
                        corr_files(track_files + 1,7) = {corr2(mean(file_to_be_anal(reg_III,start_t:end_t)),mean(file_to_be_anal(reg_IV,start_t:end_t)))};
     
  catch
      
  end
  
    end
  
      
end  

xlswrite (['Corr_Consistency_' cell2mat(region_selected_name)],corr_files)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%               
 %% Plotting the results in a 2-D figure       
 pcolor_matrix = cell2mat(corr_files(2:end,2:end));
 pcolor_matrix(:,end + 1) = 0;
 pcolor_matrix(end + 1,:) = 0;
 
 figure
 pcolor(pcolor_matrix)
 title('\bfPlot of the color-coded results. Each square represents a r value for each subject and each region')
 xlabel('\bfRegion analyzed')
 ylabel('\bfSubject # analyzed')
 colorbar
        
 saveas(gcf,['Corr_Consistency_' cell2mat(region_selected_name) '.fig'])
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%     
 
 message = 'The Correlation consistency has been calculated for all the files saved in the chosen directory';

        msgbox(message,'Calculations completed','warn');
