function varargout = Resp_Consistency_GUI(varargin)
% RESP_CONSISTENCY_GUI MATLAB code for Resp_Consistency_GUI.fig
%      RESP_CONSISTENCY_GUI, by itself, creates a new RESP_CONSISTENCY_GUI or raises the existing
%      singleton*.
%
%      H = RESP_CONSISTENCY_GUI returns the handle to a new RESP_CONSISTENCY_GUI or the handle to
%      the existing singleton*.
%
%      RESP_CONSISTENCY_GUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in RESP_CONSISTENCY_GUI.M with the given input arguments.
%
%      RESP_CONSISTENCY_GUI('Property','Value',...) creates a new RESP_CONSISTENCY_GUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before Resp_Consistency_GUI_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to Resp_Consistency_GUI_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help Resp_Consistency_GUI

% Last Modified by GUIDE v2.5 18-May-2015 10:45:05

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Resp_Consistency_GUI_OpeningFcn, ...
                   'gui_OutputFcn',  @Resp_Consistency_GUI_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before Resp_Consistency_GUI is made visible.
function Resp_Consistency_GUI_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to Resp_Consistency_GUI (see VARARGIN)

% Choose default command line output for Resp_Consistency_GUI
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes Resp_Consistency_GUI wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = Resp_Consistency_GUI_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Upload the txt file with the randomized sequence
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in Upload_Dir_URS.
function Upload_Dir_URS_Callback(hObject, eventdata, handles)
% hObject    handle to Upload_Dir_URS (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global RSF_selected;
global RSF_directory;
global randomized_seq;

[RSF_selected,RSF_directory] = uigetfile('*.mat','Select the mat file with the random sequence');

set(handles.Sequence_Uploaded,'String',RSF_selected);

cd(RSF_directory)

load(RSF_selected);

randomized_seq = save_seq;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Sequence Uploaded
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Sequence_Uploaded_Callback(hObject, eventdata, handles)
% hObject    handle to Sequence_Uploaded (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Sequence_Uploaded as text
%        str2double(get(hObject,'String')) returns contents of Sequence_Uploaded as a double


% --- Executes during object creation, after setting all properties.
function Sequence_Uploaded_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Sequence_Uploaded (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Calculate correlation Quiet/Noise
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in Corr_Consistency_S.
function Corr_Consistency_S_Callback(hObject, eventdata, handles)
% hObject    handle to Corr_Consistency_S (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global Signal_directory;
global randomized_seq;

if (get(handles.Analysis_Type_Sweeps_Cons,'Value') == 2)
    
regions_limits = [str2double(get(handles.Region_I_Corr_Cons,'String')) str2double(get(handles.Region_II_Corr_Cons,'String')) str2double(get(handles.Region_III_Corr_Cons,'String')) str2double(get(handles.Region_IV_Corr_Cons,'String'))];

else
    
    regions_limits = [str2double(get(handles.Region_IV_Corr_Cons,'String'))/2];

end

start_t = str2double(get(handles.Start_time_corr_cons,'String'));
end_t = str2double(get(handles.End_time_corr_cons,'String'));

region_choices = get(handles.Region_Corr_Cons,'String');
region_selected = get(handles.Region_Corr_Cons,'Value');
region_selected_name = region_choices(region_selected);

if (get(handles.Analysis_Type_Sweeps_Cons,'Value') == 2)

Corr_Consistency_Response(Signal_directory,randomized_seq,regions_limits,start_t,end_t,region_selected_name)

else
   
  Corr_Consistency_Response_2_regions(Signal_directory,randomized_seq,regions_limits,start_t,end_t,region_selected_name)  
    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Upload the Dir for Quiet
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in Upload_Dir_S.
function Upload_Dir_S_Callback(hObject, eventdata, handles)
% hObject    handle to Upload_Dir_S (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global Signal_file_selected;
global Signal_directory;

[Signal_file_selected,Signal_directory] = uigetfile('*.mat','Select the mat file');

set(handles.Dir_Uploaded_S,'String',Signal_directory);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Dir uploaded for Quiet
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Dir_Uploaded_S_Callback(hObject, eventdata, handles)
% hObject    handle to Dir_Uploaded_S (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Dir_Uploaded_S as text
%        str2double(get(hObject,'String')) returns contents of Dir_Uploaded_S as a double


% --- Executes during object creation, after setting all properties.
function Dir_Uploaded_S_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Dir_Uploaded_S (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Region I
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Region_I_Corr_Cons_Callback(hObject, eventdata, handles)
% hObject    handle to Region_I_Corr_Cons (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Region_I_Corr_Cons as text
%        str2double(get(hObject,'String')) returns contents of Region_I_Corr_Cons as a double


% --- Executes during object creation, after setting all properties.
function Region_I_Corr_Cons_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Region_I_Corr_Cons (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Region II
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Region_II_Corr_Cons_Callback(hObject, eventdata, handles)
% hObject    handle to Region_II_Corr_Cons (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Region_II_Corr_Cons as text
%        str2double(get(hObject,'String')) returns contents of Region_II_Corr_Cons as a double


% --- Executes during object creation, after setting all properties.
function Region_II_Corr_Cons_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Region_II_Corr_Cons (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Region III
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Region_III_Corr_Cons_Callback(hObject, eventdata, handles)
% hObject    handle to Region_III_Corr_Cons (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Region_III_Corr_Cons as text
%        str2double(get(hObject,'String')) returns contents of Region_III_Corr_Cons as a double


% --- Executes during object creation, after setting all properties.
function Region_III_Corr_Cons_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Region_III_Corr_Cons (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Region IV
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Region_IV_Corr_Cons_Callback(hObject, eventdata, handles)
% hObject    handle to Region_IV_Corr_Cons (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Region_IV_Corr_Cons as text
%        str2double(get(hObject,'String')) returns contents of Region_IV_Corr_Cons as a double


% --- Executes during object creation, after setting all properties.
function Region_IV_Corr_Cons_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Region_IV_Corr_Cons (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Generate the random sequence
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in Generate_Randomized_Sequence_file.
function Generate_Randomized_Sequence_file_Callback(hObject, eventdata, handles)
% hObject    handle to Generate_Randomized_Sequence_file (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

sweeps_needed = str2double(get(handles.Sweeps_Random_Seq,'String'));
regions_limits = [str2double(get(handles.Region_I_Corr_Cons,'String')) str2double(get(handles.Region_II_Corr_Cons,'String')) str2double(get(handles.Region_III_Corr_Cons,'String')) str2double(get(handles.Region_IV_Corr_Cons,'String'))];
regions_to_be_created = get(handles.Analysis_Type_Sweeps_Cons,'Value');

generate_rand_seq_corr_cons (regions_limits,sweeps_needed,regions_to_be_created);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Number of sweeps generated
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Sweeps_Random_Seq_Callback(hObject, eventdata, handles)
% hObject    handle to Sweeps_Random_Seq (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Sweeps_Random_Seq as text
%        str2double(get(hObject,'String')) returns contents of Sweeps_Random_Seq as a double


% --- Executes during object creation, after setting all properties.
function Sweeps_Random_Seq_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Sweeps_Random_Seq (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Start time for the correlation analysis
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Start_time_corr_cons_Callback(hObject, eventdata, handles)
% hObject    handle to Start_time_corr_cons (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Start_time_corr_cons as text
%        str2double(get(hObject,'String')) returns contents of Start_time_corr_cons as a double


% --- Executes during object creation, after setting all properties.
function Start_time_corr_cons_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Start_time_corr_cons (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%End time for the correlation analysis
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function End_time_corr_cons_Callback(hObject, eventdata, handles)
% hObject    handle to End_time_corr_cons (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of End_time_corr_cons as text
%        str2double(get(hObject,'String')) returns contents of End_time_corr_cons as a double


% --- Executes during object creation, after setting all properties.
function End_time_corr_cons_CreateFcn(hObject, eventdata, handles)
% hObject    handle to End_time_corr_cons (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Region analized
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on selection change in Region_Corr_Cons.
function Region_Corr_Cons_Callback(hObject, eventdata, handles)
% hObject    handle to Region_Corr_Cons (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns Region_Corr_Cons contents as cell array
%        contents{get(hObject,'Value')} returns selected item from Region_Corr_Cons


% --- Executes during object creation, after setting all properties.
function Region_Corr_Cons_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Region_Corr_Cons (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Regions to be created
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on selection change in Analysis_Type_Sweeps_Cons.
function Analysis_Type_Sweeps_Cons_Callback(hObject, eventdata, handles)
% hObject    handle to Analysis_Type_Sweeps_Cons (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns Analysis_Type_Sweeps_Cons contents as cell array
%        contents{get(hObject,'Value')} returns selected item from Analysis_Type_Sweeps_Cons


% --- Executes during object creation, after setting all properties.
function Analysis_Type_Sweeps_Cons_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Analysis_Type_Sweeps_Cons (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
