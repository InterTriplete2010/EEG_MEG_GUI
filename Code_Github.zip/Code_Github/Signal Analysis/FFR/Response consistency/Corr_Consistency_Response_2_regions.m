function Corr_Consistency_Response_2_regions(Signal_directory,randomized_seq,regions_limits,start_t,end_t,region_selected_name)

clear corr_files;

cd(Signal_directory)

mat_files = dir;

[files_number] = size(mat_files,1);

num_regions = length(regions_limits);



%% Initializing the matrix where the results will be saved
corr_files = {zeros(files_number,num_regions + 1)};
corr_files(1,1) = {'File Name'};
corr_files(1,2) = {'Mean Region I-II'};
corr_files(1,3) = {'Std Region I-II'};
corr_files(1,4) = {'CV Region I-II'};

track_files = 0;

message = 'Data are being analyzed...';

        msgbox(message,'Calculations in progress...','warn');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%        
%% Calculating the correlation
for ii = 3:files_number
    
    if (strcmp(mat_files(ii).name(end-3:end), '.mat') == 1)

        track_files = track_files + 1;
        
  matrix_file = mat_files(ii).name;      
  
  load(matrix_file);

  %% Checking that the file has same number of sweeps for the two polarities
  
  if (size(data_exported.rar_sweeps,1) > size(data_exported.compr_sweeps,1))
      
      diff_pol = size(data_exported.rar_sweeps,1) - size(data_exported.compr_sweeps,1);
      data_exported.rar_sweeps(end-diff_pol + 1:end,:) = [];
      
  elseif (size(data_exported.rar_sweeps,1) < size(data_exported.compr_sweeps,1))
      
      diff_pol = size(data_exported.compr_sweeps,1) - size(data_exported.rar_sweeps,1);
      data_exported.compr_sweeps(end-diff_pol + 1:end,:) = [];
      
  end
  
  file_to_be_anal = zeros(size(data_exported.rar_sweeps,1) + size(data_exported.compr_sweeps,1),size(data_exported.rar_sweeps,2));
  file_to_be_anal(1:2:end,:) = data_exported.rar_sweeps;
  file_to_be_anal(2:2:end,:) = data_exported.compr_sweeps;
  
  try
      
            for oo = 1:size(randomized_seq,1)/2
          
  corr_files(track_files + 1,1) = {matrix_file};
   save_corr(oo,track_files) = corr2(mean(file_to_be_anal(randomized_seq(oo,:),start_t:end_t)),mean(file_to_be_anal(randomized_seq(oo + 1,:),start_t:end_t)));
             
            end
    
    corr_files(track_files + 1,2) = {mean(save_corr(:,track_files))};
        corr_files(track_files + 1,3) = {std(save_corr(:,track_files))};
            corr_files(track_files + 1,4) = {std(save_corr(:,track_files))/mean(save_corr(:,track_files))};
        
  catch
      
  end
  
    end
  
      
end  

xlswrite (['Corr_Consistency_' cell2mat(region_selected_name)],corr_files)
save(['Corr_Consistency_' cell2mat(region_selected_name)],'save_corr')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%               
 %% Plotting the results with a box plot       
 figure
 subplot(2,1,1)
 boxplot(save_corr)
 title('\bfBox plot for each subject for the 300 repetitions')
 xlabel('\bfSubject')
 ylabel('\bfr-value')
 
 subplot(2,1,2)
 bar(cell2mat(corr_files(2:end,4)))
 title('\bfCoefficient of variation for each subject')
 xlabel('\bfSubject')
 ylabel('\bfCV')
 
        
 saveas(gcf,['Corr_Consistency_' cell2mat(region_selected_name) '.fig'])
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
 
 message = 'The Correlation consistency has been calculated for all the files saved in the chosen directory';

        msgbox(message,'Calculations completed','warn');

