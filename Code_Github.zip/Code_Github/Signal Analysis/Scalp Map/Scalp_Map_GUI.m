function varargout = Scalp_Map_GUI(varargin)
% SCALP_MAP_GUI MATLAB code for Scalp_Map_GUI.fig
%      SCALP_MAP_GUI, by itself, creates a new SCALP_MAP_GUI or raises the existing
%      singleton*.
%
%      H = SCALP_MAP_GUI returns the handle to a new SCALP_MAP_GUI or the handle to
%      the existing singleton*.
%
%      SCALP_MAP_GUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in SCALP_MAP_GUI.M with the given input arguments.
%
%      SCALP_MAP_GUI('Property','Value',...) creates a new SCALP_MAP_GUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before Scalp_Map_GUI_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to Scalp_Map_GUI_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help Scalp_Map_GUI

% Last Modified by GUIDE v2.5 21-Mar-2018 10:07:25

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Scalp_Map_GUI_OpeningFcn, ...
                   'gui_OutputFcn',  @Scalp_Map_GUI_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before Scalp_Map_GUI is made visible.
function Scalp_Map_GUI_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to Scalp_Map_GUI (see VARARGIN)

% Choose default command line output for Scalp_Map_GUI
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes Scalp_Map_GUI wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = Scalp_Map_GUI_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Create the scalp map
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in Create_Scalp_Map.
function Create_Scalp_Map_Callback(hObject, eventdata, handles)
% hObject    handle to Create_Scalp_Map (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global Files_Mat_file_selected;
global Files_Mat_file_directory;

%Extracting the values for the peak analysis
P1_start_window = str2double(get(handles.P1_S_SM,'String'));
P1_end_window = str2double(get(handles.P1_E_SM,'String'));
 
N1_start_window = str2double(get(handles.N1_S_SM,'String'));
N1_end_window = str2double(get(handles.N1_E_SM,'String'));
    
P2_start_window = str2double(get(handles.P2_S_SM,'String'));
P2_end_window = str2double(get(handles.P2_E_SM,'String'));
 
     scalp_map_only_Biosemi(Files_Mat_file_directory,...
            P1_start_window,P1_end_window,N1_start_window,N1_end_window,P2_start_window,P2_end_window);
   
 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Upload the grand av directory
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in Upload_Grand_Av_SM.
function Upload_Grand_Av_SM_Callback(hObject, eventdata, handles)
% hObject    handle to Upload_Grand_Av_SM (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global Files_Mat_file_selected;
global Files_Mat_file_directory;

[Files_Mat_file_selected,Files_Mat_file_directory] = uigetfile('*.mat','Select the mat file');

cd(Files_Mat_file_directory)

set(handles.Grand_Av_SM_Uploaded,'String',Files_Mat_file_directory);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Grand av directory uploaded
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Grand_Av_SM_Uploaded_Callback(hObject, eventdata, handles)
% hObject    handle to Grand_Av_SM_Uploaded (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Grand_Av_SM_Uploaded as text
%        str2double(get(hObject,'String')) returns contents of Grand_Av_SM_Uploaded as a double


% --- Executes during object creation, after setting all properties.
function Grand_Av_SM_Uploaded_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Grand_Av_SM_Uploaded (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Start Window of the N1
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function N1_S_SM_Callback(hObject, eventdata, handles)
% hObject    handle to N1_S_SM (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of N1_S_SM as text
%        str2double(get(hObject,'String')) returns contents of N1_S_SM as a double


% --- Executes during object creation, after setting all properties.
function N1_S_SM_CreateFcn(hObject, eventdata, handles)
% hObject    handle to N1_S_SM (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%End Window of the N1
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function N1_E_SM_Callback(hObject, eventdata, handles)
% hObject    handle to N1_E_SM (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of N1_E_SM as text
%        str2double(get(hObject,'String')) returns contents of N1_E_SM as a double


% --- Executes during object creation, after setting all properties.
function N1_E_SM_CreateFcn(hObject, eventdata, handles)
% hObject    handle to N1_E_SM (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Start Window of the P2
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function P2_S_SM_Callback(hObject, eventdata, handles)
% hObject    handle to P2_S_SM (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of P2_S_SM as text
%        str2double(get(hObject,'String')) returns contents of P2_S_SM as a double


% --- Executes during object creation, after setting all properties.
function P2_S_SM_CreateFcn(hObject, eventdata, handles)
% hObject    handle to P2_S_SM (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%End Window of the P2
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function P2_E_SM_Callback(hObject, eventdata, handles)
% hObject    handle to P2_E_SM (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of P2_E_SM as text
%        str2double(get(hObject,'String')) returns contents of P2_E_SM as a double


% --- Executes during object creation, after setting all properties.
function P2_E_SM_CreateFcn(hObject, eventdata, handles)
% hObject    handle to P2_E_SM (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Start Window of the P1
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function P1_S_SM_Callback(hObject, eventdata, handles)
% hObject    handle to P1_S_SM (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of P1_S_SM as text
%        str2double(get(hObject,'String')) returns contents of P1_S_SM as a double


% --- Executes during object creation, after setting all properties.
function P1_S_SM_CreateFcn(hObject, eventdata, handles)
% hObject    handle to P1_S_SM (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%End Window of the P1
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function P1_E_SM_Callback(hObject, eventdata, handles)
% hObject    handle to P1_E_SM (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of P1_E_SM as text
%        str2double(get(hObject,'String')) returns contents of P1_E_SM as a double


% --- Executes during object creation, after setting all properties.
function P1_E_SM_CreateFcn(hObject, eventdata, handles)
% hObject    handle to P1_E_SM (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
