function varargout = Coherence_FFT(varargin)
% COHERENCE_FFT MATLAB code for Coherence_FFT.fig
%      COHERENCE_FFT, by itself, creates a new COHERENCE_FFT or raises the existing
%      singleton*.
%
%      H = COHERENCE_FFT returns the handle to a new COHERENCE_FFT or the handle to
%      the existing singleton*.
%
%      COHERENCE_FFT('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in COHERENCE_FFT.M with the given input arguments.
%
%      COHERENCE_FFT('Property','Value',...) creates a new COHERENCE_FFT or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before Coherence_FFT_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to Coherence_FFT_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help Coherence_FFT

% Last Modified by GUIDE v2.5 09-Jun-2015 14:02:05

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Coherence_FFT_OpeningFcn, ...
                   'gui_OutputFcn',  @Coherence_FFT_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before Coherence_FFT is made visible.
function Coherence_FFT_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to Coherence_FFT (see VARARGIN)

% Choose default command line output for Coherence_FFT
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes Coherence_FFT wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = Coherence_FFT_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in Coherence_FFT_Button.
function Coherence_FFT_Button_Callback(hObject, eventdata, handles)
% hObject    handle to Coherence_FFT_Button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global Signal_I_selected;
global Signal_I_directory;
global Signal_II_selected;
global Signal_II_directory;

freq_bin = str2double(get(handles.Freq_Bin_Coherence_FFT,'String'));
freq_range = str2double(get(handles.Frequencies_Coherence_FFT,'String'));

start_point_t = str2double(get(handles.Start_T_Coherence_FFT,'String'));
end_point_t = str2double(get(handles.End_T_Coherence_FFT,'String'));

start_point_ss = str2double(get(handles.Start_SS_Coherence_FFT,'String'));
end_point_ss = str2double(get(handles.End_SS_Coherence_FFT,'String'));

Coherence_Function_FFT(Signal_I_selected,Signal_II_selected,Signal_I_directory,Signal_II_directory,freq_bin,freq_range,start_point_t,end_point_t,start_point_ss,end_point_ss)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Upload signal I
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in Upload_Signal_I_Coherence_FFT.
function Upload_Signal_I_Coherence_FFT_Callback(hObject, eventdata, handles)
% hObject    handle to Upload_Signal_I_Coherence_FFT (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global Signal_I_selected;
global Signal_I_directory;

[Signal_I_selected,Signal_I_directory] = uigetfile('*.mat','Select the mat file');

set(handles.Dir_Signal_I_Uploaded,'String',Signal_I_selected);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Signal I uploaded
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Dir_Signal_I_Uploaded_Callback(hObject, eventdata, handles)
% hObject    handle to Dir_Signal_I_Uploaded (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Dir_Signal_I_Uploaded as text
%        str2double(get(hObject,'String')) returns contents of Dir_Signal_I_Uploaded as a double


% --- Executes during object creation, after setting all properties.
function Dir_Signal_I_Uploaded_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Dir_Signal_I_Uploaded (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Frequency bin for the coherence analysis
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Freq_Bin_Coherence_FFT_Callback(hObject, eventdata, handles)
% hObject    handle to Freq_Bin_Coherence_FFT (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Freq_Bin_Coherence_FFT as text
%        str2double(get(hObject,'String')) returns contents of Freq_Bin_Coherence_FFT as a double


% --- Executes during object creation, after setting all properties.
function Freq_Bin_Coherence_FFT_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Freq_Bin_Coherence_FFT (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Frequency interval for the coherence analysis
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Frequencies_Coherence_FFT_Callback(hObject, eventdata, handles)
% hObject    handle to Frequencies_Coherence_FFT (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Frequencies_Coherence_FFT as text
%        str2double(get(hObject,'String')) returns contents of Frequencies_Coherence_FFT as a double


% --- Executes during object creation, after setting all properties.
function Frequencies_Coherence_FFT_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Frequencies_Coherence_FFT (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%End analysis for the Transition region
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function End_T_Coherence_FFT_Callback(hObject, eventdata, handles)
% hObject    handle to End_T_Coherence_FFT (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of End_T_Coherence_FFT as text
%        str2double(get(hObject,'String')) returns contents of End_T_Coherence_FFT as a double


% --- Executes during object creation, after setting all properties.
function End_T_Coherence_FFT_CreateFcn(hObject, eventdata, handles)
% hObject    handle to End_T_Coherence_FFT (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Start analysis for the Transition region
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Start_SS_Coherence_FFT_Callback(hObject, eventdata, handles)
% hObject    handle to Start_SS_Coherence_FFT (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Start_SS_Coherence_FFT as text
%        str2double(get(hObject,'String')) returns contents of Start_SS_Coherence_FFT as a double


% --- Executes during object creation, after setting all properties.
function Start_SS_Coherence_FFT_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Start_SS_Coherence_FFT (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%End analysis for the Steady-State region
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function End_SS_Coherence_FFT_Callback(hObject, eventdata, handles)
% hObject    handle to End_SS_Coherence_FFT (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of End_SS_Coherence_FFT as text
%        str2double(get(hObject,'String')) returns contents of End_SS_Coherence_FFT as a double


% --- Executes during object creation, after setting all properties.
function End_SS_Coherence_FFT_CreateFcn(hObject, eventdata, handles)
% hObject    handle to End_SS_Coherence_FFT (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Start analysis for the Steady-State region
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Start_T_Coherence_FFT_Callback(hObject, eventdata, handles)
% hObject    handle to Start_T_Coherence_FFT (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Start_T_Coherence_FFT as text
%        str2double(get(hObject,'String')) returns contents of Start_T_Coherence_FFT as a double


% --- Executes during object creation, after setting all properties.
function Start_T_Coherence_FFT_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Start_T_Coherence_FFT (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Upload signal II
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in Upload_Signal_II_Coherence_FFT.
function Upload_Signal_II_Coherence_FFT_Callback(hObject, eventdata, handles)
% hObject    handle to Upload_Signal_II_Coherence_FFT (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global Signal_II_selected;
global Signal_II_directory;

[Signal_II_selected,Signal_II_directory] = uigetfile('*.mat','Select the mat file');

set(handles.Signal_II_FFT_Uploaded,'String',Signal_II_selected);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Signal II uploaded
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Signal_II_FFT_Uploaded_Callback(hObject, eventdata, handles)
% hObject    handle to Signal_II_FFT_Uploaded (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Signal_II_FFT_Uploaded as text
%        str2double(get(hObject,'String')) returns contents of Signal_II_FFT_Uploaded as a double


% --- Executes during object creation, after setting all properties.
function Signal_II_FFT_Uploaded_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Signal_II_FFT_Uploaded (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
