function Coherence_Function_FFT(Signal_I_selected,Signal_II_selected,Signal_I_directory,Signal_II_directory,...
    freq_bin,freq_range,start_point_t,end_point_t,start_point_ss,end_point_ss)

%% Uploading the two signals that will be analyzed
cd(Signal_I_directory)
sign_I = load(Signal_I_selected);
sign_I_data = [sign_I.data_exported.rar_sweeps;sign_I.data_exported.compr_sweeps];
mean_data_I = mean(sign_I_data);

cd(Signal_II_directory)
sign_II = load(Signal_II_selected);
sign_II_data = [sign_II.data_exported.rar_sweeps;sign_II.data_exported.compr_sweeps];
mean_data_II = mean(sign_II_data);

range_values = round((40/1000)*sign_I.data_exported.sampling_frequency); %40ms have converted into samples

start_analysis = 1;
end_analysis = range_values;

save_coherence_values(1,1) = {'Signal I'};
save_coherence_values(1,2) = {'Signal II'}; 
save_coherence_values(1,1) = {'Transition'};
save_coherence_values(1,2) = {'Steady-State'}; 

 %while (end_analysis <= size(mean_data_I,2))
for gg = 1:size(mean_data_I,2)

    try
        
    temp_sign_I = mean_data_I(1,start_analysis:end_analysis);
    temp_sign_II = mean_data_II(1,start_analysis:end_analysis);
    
    [Cxy_coherence,F] = mscohere(temp_sign_I,temp_sign_II,round(length(temp_sign_I)/8),round(length(temp_sign_I)/16),sign_I.data_exported.sampling_frequency,sign_I.data_exported.sampling_frequency);
[Cxy_power,F] = cpsd(temp_sign_I,temp_sign_II,round(length(temp_sign_I)/8),round(length(temp_sign_I)/16),sign_I.data_exported.sampling_frequency,sign_I.data_exported.sampling_frequency);

save_coherence_image(:,gg) = Cxy_coherence;
    save_power_image(:,gg) = angle(Cxy_power);
   
%% Updating the range of data to be analyzed    
    start_analysis = start_analysis + 1;
end_analysis = end_analysis + 1
   
%% Terminates the program if the index is out of boundary
    catch
    %time_domain = [0:size(save_coherence_image]
    figure
    subplot(2,1,1)
       contourf(save_coherence_image(:,1:1000)) 
       
       subplot(2,1,2)
       contourf(save_power_image(:,1:1000))
        
        return;
        
    end
    
end


