function varargout = Extract_Peaks_DCA_Removed(varargin)
% EXTRACT_PEAKS_DCA_REMOVED MATLAB code for Extract_Peaks_DCA_Removed.fig
%      EXTRACT_PEAKS_DCA_REMOVED, by itself, creates a new EXTRACT_PEAKS_DCA_REMOVED or raises the existing
%      singleton*.
%
%      H = EXTRACT_PEAKS_DCA_REMOVED returns the handle to a new EXTRACT_PEAKS_DCA_REMOVED or the handle to
%      the existing singleton*.
%
%      EXTRACT_PEAKS_DCA_REMOVED('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in EXTRACT_PEAKS_DCA_REMOVED.M with the given input arguments.
%
%      EXTRACT_PEAKS_DCA_REMOVED('Property','Value',...) creates a new EXTRACT_PEAKS_DCA_REMOVED or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before Extract_Peaks_DCA_Removed_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to Extract_Peaks_DCA_Removed_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help Extract_Peaks_DCA_Removed

% Last Modified by GUIDE v2.5 06-Jul-2017 16:18:00

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Extract_Peaks_DCA_Removed_OpeningFcn, ...
                   'gui_OutputFcn',  @Extract_Peaks_DCA_Removed_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before Extract_Peaks_DCA_Removed is made visible.
function Extract_Peaks_DCA_Removed_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to Extract_Peaks_DCA_Removed (see VARARGIN)

% Choose default command line output for Extract_Peaks_DCA_Removed
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes Extract_Peaks_DCA_Removed wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = Extract_Peaks_DCA_Removed_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Upload the DIR for the analysis of the peaks
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in Upload_DIR_EEG.
function Upload_DIR_EEG_Callback(hObject, eventdata, handles)
% hObject    handle to Upload_DIR_EEG (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global Mat_file_selected;
global Mat_file_directory;

[Mat_file_selected,Mat_file_directory] = uigetfile('*.mat','Select the mat file');

set(handles.DIR_EEG_Uploaded,'String',Mat_file_directory)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%DIR uploaded 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function DIR_EEG_Uploaded_Callback(hObject, eventdata, handles)
% hObject    handle to DIR_EEG_Uploaded (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of DIR_EEG_Uploaded as text
%        str2double(get(hObject,'String')) returns contents of DIR_EEG_Uploaded as a double


% --- Executes during object creation, after setting all properties.
function DIR_EEG_Uploaded_CreateFcn(hObject, eventdata, handles)
% hObject    handle to DIR_EEG_Uploaded (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Extract the peaks
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in Extract_Peaks_CI_Data.
function Extract_Peaks_CI_Data_Callback(hObject, eventdata, handles)
% hObject    handle to Extract_Peaks_CI_Data (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global Mat_file_selected;
global Mat_file_directory;

P1_start_window = str2double(get(handles.P1_Start_DCA,'String'));
P1_end_window = str2double(get(handles.P1_End_DCA,'String'));
 
 N1_start_window = str2double(get(handles.N1_Start_DCA,'String'));
 N1_end_window = str2double(get(handles.N1_End_DCA,'String'));
    
 P2_start_window = str2double(get(handles.P2_Start_DCA,'String'));
 P2_end_window = str2double(get(handles.P2_End_DCA,'String'));

 cd(Mat_file_directory)

dir_files = dir;

[files_number] = size(dir_files,1);

track_subjects = 0;

for ii = 3:files_number
    
    matrix_file = dir_files(ii).name;
    
    if (strcmp(matrix_file(1,end-2:end),'mat') == 1) 
 
  
  temp_file = load(matrix_file);
  data_exported_average_trials = [];
  
  data_exported_average_trials = temp_file.data_exported.average_trials_2_degree;
  tt_mean = temp_file.data_exported.time_average;
  sampl_freq = temp_file.data_exported.sampling_frequency;
  
  name_electrodes = temp_file.data_exported.labels;
  
extract_peaks_DCA_function(data_exported_average_trials,tt_mean,sampl_freq,name_electrodes,...
    P1_start_window,P1_end_window,N1_start_window,N1_end_window,P2_start_window,P2_end_window,matrix_file)

    end
    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Start window P1
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function P1_Start_DCA_Callback(hObject, eventdata, handles)
% hObject    handle to P1_Start_DCA (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of P1_Start_DCA as text
%        str2double(get(hObject,'String')) returns contents of P1_Start_DCA as a double


% --- Executes during object creation, after setting all properties.
function P1_Start_DCA_CreateFcn(hObject, eventdata, handles)
% hObject    handle to P1_Start_DCA (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%End window P1
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function P1_End_DCA_Callback(hObject, eventdata, handles)
% hObject    handle to P1_End_DCA (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of P1_End_DCA as text
%        str2double(get(hObject,'String')) returns contents of P1_End_DCA as a double


% --- Executes during object creation, after setting all properties.
function P1_End_DCA_CreateFcn(hObject, eventdata, handles)
% hObject    handle to P1_End_DCA (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Start window N1
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function N1_Start_DCA_Callback(hObject, eventdata, handles)
% hObject    handle to N1_Start_DCA (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of N1_Start_DCA as text
%        str2double(get(hObject,'String')) returns contents of N1_Start_DCA as a double


% --- Executes during object creation, after setting all properties.
function N1_Start_DCA_CreateFcn(hObject, eventdata, handles)
% hObject    handle to N1_Start_DCA (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%End window N1
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function N1_End_DCA_Callback(hObject, eventdata, handles)
% hObject    handle to N1_End_DCA (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of N1_End_DCA as text
%        str2double(get(hObject,'String')) returns contents of N1_End_DCA as a double


% --- Executes during object creation, after setting all properties.
function N1_End_DCA_CreateFcn(hObject, eventdata, handles)
% hObject    handle to N1_End_DCA (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Start window P2
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function P2_Start_DCA_Callback(hObject, eventdata, handles)
% hObject    handle to P2_Start_DCA (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of P2_Start_DCA as text
%        str2double(get(hObject,'String')) returns contents of P2_Start_DCA as a double


% --- Executes during object creation, after setting all properties.
function P2_Start_DCA_CreateFcn(hObject, eventdata, handles)
% hObject    handle to P2_Start_DCA (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%End window P2
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function P2_End_DCA_Callback(hObject, eventdata, handles)
% hObject    handle to P2_End_DCA (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of P2_End_DCA as text
%        str2double(get(hObject,'String')) returns contents of P2_End_DCA as a double


% --- Executes during object creation, after setting all properties.
function P2_End_DCA_CreateFcn(hObject, eventdata, handles)
% hObject    handle to P2_End_DCA (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
