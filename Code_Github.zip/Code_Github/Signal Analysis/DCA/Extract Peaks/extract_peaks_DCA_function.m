function extract_peaks_DCA_function(data_exported_average_trials,tt_mean,sampl_freq,name_electrodes,...
    P1_start_window,P1_end_window,N1_start_window,N1_end_window,P2_start_window,P2_end_window,matrix_file)

time_ms = 1000*tt_mean; %Converting the time scale to "ms"

find_max_P1_N1_P2 = {zeros(4,size(data_exported_average_trials,1) + 1)};
find_max_P1_N1_P2(1,1) = {'Peak'};
find_max_P1_N1_P2(2,1) = {'P1'};
find_max_P1_N1_P2(3,1) = {'N1'};
find_max_P1_N1_P2(4,1) = {'P2'};

find_latency_P1_N1_P2 = {zeros(4,size(data_exported_average_trials,1) + 1)};
find_latency_P1_N1_P2(1,1) = {'Peak'};
find_latency_P1_N1_P2(2,1) = {'P1'};
find_latency_P1_N1_P2(3,1) = {'N1'};
find_latency_P1_N1_P2(4,1) = {'P2'};

for ll = 1:size(data_exported_average_trials,1)

find_max_P1_N1_P2(1,ll + 1) = name_electrodes(ll);
find_latency_P1_N1_P2(1,ll + 1) = name_electrodes(ll);    
    
end

%% Starting and end points for P1, N1 and P2 
start_P1 = P1_start_window;
end_P1 = P1_end_window;
start_N1 = N1_start_window;
end_N1 = N1_end_window;
start_P2 = P2_start_window;
end_P2 = P2_end_window;

find_p1_sampl_freq = time_ms(find(time_ms <= start_P1,1,'Last'));
find_n1_sampl_freq = time_ms(find(time_ms <= start_N1,1,'Last'));
find_p2_sampl_freq = time_ms(find(time_ms <= start_P2,1,'Last'));

for kk = 1:size(data_exported_average_trials,1)
   
    find_max_P1_N1_P2(2,kk + 1) = {max(data_exported_average_trials(kk,find(time_ms >= start_P1,1,'First'):find(time_ms <= end_P1,1,'Last')))};
    find_max_P1_N1_P2(3,kk + 1) = {min(data_exported_average_trials(kk,find(time_ms >= start_N1,1,'First'):find(time_ms <= end_N1,1,'Last')))};
    find_max_P1_N1_P2(4,kk + 1) = {max(data_exported_average_trials(kk,find(time_ms >= start_P2,1,'First'):find(time_ms <= end_P2,1,'Last')))};
    
find_latency_P1_N1_P2(2,kk + 1) = {1000*find(data_exported_average_trials(kk,find(time_ms >= start_P1,1,'First'):find(time_ms <= end_P1,1,'Last')) == cell2mat(find_max_P1_N1_P2(2,kk + 1)))/sampl_freq + find_p1_sampl_freq};
find_latency_P1_N1_P2(3,kk + 1) = {1000*find(data_exported_average_trials(kk,find(time_ms >= start_N1,1,'First'):find(time_ms <= end_N1,1,'Last')) == cell2mat(find_max_P1_N1_P2(3,kk + 1)))/sampl_freq + find_n1_sampl_freq};
find_latency_P1_N1_P2(4,kk + 1) = {1000*find(data_exported_average_trials(kk,find(time_ms >= start_P2,1,'First'):find(time_ms <= end_P2,1,'Last')) == cell2mat(find_max_P1_N1_P2(4,kk + 1)))/sampl_freq + find_p2_sampl_freq};
    
end

    
       xlswrite (['Peaks_' matrix_file(1:end-4) '.xls'],find_max_P1_N1_P2)
                 
         xlswrite (['Latencies_' matrix_file(1:end-4) '.xls'],find_latency_P1_N1_P2)
             
   
