function remove_dca_function(ica_directory,ica_file,eeg_directory,eeg_file,output_name)

%This function remove the DCA by using a bivariate polynomial as described
%in Mc Laughlin et al. 2013  "Cochlear Implant artifact attenuation in late 
%auditory evoked potentials: A single channel approach", Hearing Research

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Upload the sensor that better represents the stimulus artifact
cd(ica_directory)
temp_file_ica = load(ica_file);
ica_selected = temp_file_ica.data_exported.average_trials(:,:);
dca_template_sweeps = squeeze(temp_file_ica.data_exported.single_trials(1,:,:));
sf = temp_file_ica.data_exported.sampling_frequency;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Upload the Average to be cleaned up
cd(eeg_directory)
temp_file_eeg = load(eeg_file);
eeg_data_dca = temp_file_eeg.data_exported.average_trials;
eeg_sweeps_dca = temp_file_eeg.data_exported.single_trials;
time_average = temp_file_eeg.data_exported.time_average;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

eeg_sweeps_saved = zeros(size(eeg_sweeps_dca,1),size(eeg_sweeps_dca,2),size(eeg_sweeps_dca,3));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Independent variables used to fit the response
mean_data = align_template_sweeps(dca_template_sweeps(temp_file_eeg.data_exported.pos_single_trials,:),time_average);
%mean_data = mean(dca_template_sweeps(temp_file_eeg.data_exported.pos_single_trials,:));
ind_variables = [time_average;mean_data]';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
dca_average_trials = zeros(size(eeg_data_dca,1),size(eeg_data_dca,2));

 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Plotting the EEG data and the average of the DCA template
for kk = 1:size(eeg_data_dca,1)

    temp_eeg_data = eeg_data_dca(kk,:);
    temp_time_av = time_average;
  
%{    
figure
plot(1000*time_average,mapstd(ica_selected),'Color','r','LineWidth',1)

hold on

tt_average = [0:size(temp_eeg_data,2)-1]/sf;
plot(1000*time_average,mapstd(temp_eeg_data),'Color','k','LineWidth',1)
%}
    
%{
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Computing the coefficients for the bivariate polynomial    
%{'constant, 'x', 'x^2', 'y', 'x*y', 'y^2'} Second degree
%{'constant', 'x', 'x^4', 'y', 'x*y', 'y^4'}) Fourth degree

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%pol_fact_2_degree = polyfitn(ind_variables,eeg_data_dca(kk,1:size(ind_variables,1)),'constant, x, x^2, y, x*y, y^2');

%Calculating the bivariate polynomial 
%Second degree
%equation_dca_2_degree = pol_fact_2_degree.Coefficients(1) + pol_fact_2_degree.Coefficients(2)*(time_average) + pol_fact_2_degree.Coefficients(3)*(time_average.^2) + ...
 %   pol_fact_2_degree.Coefficients(4)*(mean_data) + pol_fact_2_degree.Coefficients(5)*((mean_data).*(time_average)) + pol_fact_2_degree.Coefficients(6)*(mean_data.^2);
%}

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Computing the coefficients for the bivariate polynomial    
%Creating the matrix with the Independent variables for a second degree model. 
%A columns of "ones" will be added to account for the bias
ind_var = [ones(size(ind_variables,1),1) ind_variables(:,1) ind_variables(:,2) ind_variables(:,1).^2 ind_variables(:,2).^2 ind_variables(:,1).*ind_variables(:,2)];
[equation_dca_2_degree var_regr_2_degree] = Polynomial_Regress_Model(eeg_data_dca(kk,1:size(ind_variables,1)),ind_var,sf);

dca_average_trials(kk,:) = temp_eeg_data(:,1:size(ind_variables,1)) - equation_dca_2_degree';
dca_average_trials_fit_2_degree(kk,:) = equation_dca_2_degree';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Computing the coefficients for the bivariate polynomial    
%Creating the matrix with the Independent variables for a fourth degree model. 
%A columns of "ones" will be added to account for the bias
ind_var = [ones(size(ind_variables,1),1) ind_variables(:,1) ind_variables(:,2) ind_variables(:,1).^2 ind_variables(:,2).^2 ind_variables(:,1).*ind_variables(:,2) ind_variables(:,1).^3 ind_variables(:,2).^3 ind_variables(:,1).^4 ind_variables(:,2).^4];
[equation_dca_4_degree var_regr_4_degree] = Polynomial_Regress_Model(eeg_data_dca(kk,1:size(ind_variables,1)),ind_var,sf);

dca_average_trials_4_degree(kk,:) = temp_eeg_data(:,1:size(ind_variables,1)) - equation_dca_4_degree';
dca_average_trials_4_degree_fit(kk,:) = equation_dca_4_degree';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%{
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Removing the DCA at the single sweep and then computing the average 
[save_dca_removal_single_sweeps mean_single_sweeps_eeg] = dca_removal_single_sweep(ind_var,squeeze(eeg_sweeps_dca(kk,:,:)));

eeg_sweeps_saved(kk,:,:) = save_dca_removal_single_sweeps;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%}

end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%{
%% Calculate the DSS to denoise data, if the bivariate polynomial has
%failed to remove the pedestal
[dss_first_file todss fromdss clean] = DSS_CI_data(eeg_sweeps_saved);

%%Aligning the data to the EEG data relative to the first DDS (which is supposed to be the one 
%representing the CI artifact) and subtracting this signal component from
%the average after applying a regression model

[cleaned_data_DSS_spline] = spline_DSS(todss,fromdss,clean,dca_average_trials,time_average,sf);
%}
%saveas(gcf,[eeg_file '_DCA_Corrected.fig'])

data_exported.average_trials_2_degree = dca_average_trials;
data_exported.dca_average_trials_fit_2_degree = dca_average_trials_fit_2_degree;
data_exported.regr_var_2_degree = var_regr_2_degree;

data_exported.average_trials_4_degree =dca_average_trials_4_degree;
data_exported.dca_average_trials_4_degree_fit = dca_average_trials_4_degree_fit;
%data_exported.average_trials_cleaned_spline_2_degree = cleaned_data_DSS_spline;
data_exported.regr_var_4_degree = var_regr_4_degree;
%data_exported.single_trials_2_degree = eeg_sweeps_saved;

data_exported.time_average = time_average;
%data_exported.single_trials_dss = clean;
%data_exported.dss_extracted = dss_first_file;
%data_exported.spatial_filter_dss = todss;
%data_exported.electrical_field_dss = fromdss;
data_exported.sampling_frequency = temp_file_eeg.data_exported.sampling_frequency;
data_exported.sensors_removed = temp_file_eeg.data_exported.sensors_removed;
data_exported.labels = temp_file_eeg.data_exported.labels;

figure
plot(1000*time_average,dca_average_trials(end,:),'k')
hold on
plot(1000*time_average,dca_average_trials_fit_2_degree(end,:),'r')
hold off

title('\bfSecond degree bivariate polynomial waveform (Cz) - ([-5 5]ms in the [-50 550]ms range)')

xlabel('\bfTime (ms)')
ylabel('\bfStandardized amplitude (\muV)')

legend('DCA corrected waveform (Cz)','DCA estimate')

saveas(gcf,[eeg_file '_DCA_Corrected_Cz.fig'])

save ([ output_name '_DCA_Corrected'],'data_exported')

message = 'Waveforms have been fitted with a bivariate polynomial';

        msgbox(message,'Bivariate polynomial and DSS have been calculated and saved','warn','replace');
