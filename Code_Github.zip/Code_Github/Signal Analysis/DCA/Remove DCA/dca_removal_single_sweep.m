function [save_dca_removal_single_sweeps mean_eeg] = dca_removal_single_sweep(ind_var,eeg_sweeps);

save_dca_removal_single_sweeps = [];

[Q,R,e] = qr(ind_var,0);

for hh = 1:size(eeg_sweeps,1)
   
    temp_sweep = eeg_sweeps(hh,:)';
    
b = R\(Q'*temp_sweep);

%Calculating the prediction vector;
equation_dca_2_degree_sweeps = ind_var(:,e)*b;


save_dca_removal_single_sweeps(hh,:) = temp_sweep' - equation_dca_2_degree_sweeps';

end

mean_eeg = mean(save_dca_removal_single_sweeps);

