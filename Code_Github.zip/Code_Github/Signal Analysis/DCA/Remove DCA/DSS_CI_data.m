function [dss_first_file todss fromdss clean] = DSS_CI_data(temp_data)

%% Rearrenging the files for the DSS analysis
   for hh = 1:size(temp_data,2)
       
        temp_data_rearrenge = squeeze(temp_data(:,hh,:))';
        
       data_dss(:,:,hh) = temp_data_rearrenge; 
        clean(:,:,hh) = temp_data_rearrenge;
        
    end
    
%prepare data
%and also calculate autocorrelation matrices
% cmat1 is the sphering autocorrelation matrix
% cmat2 is the biased evoked potential matrix

% Clearing the variables
clear cmat1;
clear cmat2;

    
    sumch=squeeze(sum(abs(data_dss(:,:,:))));
    
        %data_dss(:,sumch(1,:)>1e3)=0;    %It is arbitrary
     for ll = 1:size(data_dss,3)
            
            data_dss(sumch(1,:)>1e3,:,ll)=0;
        end
     
     inducedclean=unfold(data_dss);
    cmat1(:,:)=inducedclean'*inducedclean;
    evokedclean=sum(data_dss,3);
    cmat2(:,:)=evokedclean'*evokedclean*size(clean,3)^2;


% apply DSS using the average over epochs as a bias function
%cmat2=mean(cmat2,3);cmat1=mean(cmat1,3);
keep2=10.^-13;
keep1=[];
[todss,fromdss,ratio,pwr]=dss0(cmat1,cmat2,keep1,keep2);
%todss=pad02D(todss,bad_channels);
 
 dss_first_file = fold(unfold(clean(:,:,:))*todss(:,1),size(clean,1));