function [cleaned_data_DSS_spline] = spline_DSS(todss,fromdss,clean,dca_average_trials,time_average,sf)

%% Calcuating the first DSS
first_DSS_temp = fold(unfold(clean(:,:,:))*todss(:,1),size(clean,1));

%% Cleaned EEG data with respect to the first DSS => CI artifact
residual_CI_artifact = fold(unfold(first_DSS_temp(:,:,:))*fromdss(1,:),size(clean,1));

mean_residual_CI_artifact = mean(residual_CI_artifact,3)';

%% Reducing the residual CI artifact at the onset and offset by using an "Adaptive Regression Splines" model
cleaned_data_DSS_spline = [];
%[b,a] = butter(2,30/(sf/2),'Low');

for kk = 1:size(dca_average_trials,1)
    
[model_spline, time_spline] = aresbuild(mean_residual_CI_artifact(kk,:)',dca_average_trials(kk,:)');
Yq = arespredict(model_spline, mean_residual_CI_artifact(kk,:)');

temp_data = dca_average_trials(kk,:) - Yq';
%filt_data = filtfilt(b,a,temp_data);

cleaned_data_DSS_spline = [cleaned_data_DSS_spline;temp_data];

clc

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Aligning the data to the CI artifact
%aligned_average_trials = [];
%for kk = 1:size(mean_residual_CI_artifact,1)
    
%[corr_val,lags_corr] = xcorr(mean_residual_CI_artifact(kk,:),dca_average_trials(kk,:),'biased');
    
    %find the position of the max value
 %   pos_max = lags_corr(find(max(corr_val) == corr_val));
    
    %Shift the sweep based on the max(corr val) calculated 
  %  aligned_average_trials = [aligned_average_trials;circshift(dca_average_trials(kk,:),[1 pos_max])];
    
%end

%aligned_average_trials = dca_average_trials;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%% Applying a "smoothingspline" fit to the onset and offset 
%{
%Onset
temp_wind_onset(1,1) = find(time_average >= -0.005,1,'First');
temp_wind_onset(1,2) = find(time_average <= 0.04,1,'Last');
t_w_on = [temp_wind_onset(1,1):temp_wind_onset(1,2)];
first_peak = zeros(1,size(mean_residual_CI_artifact,2));
first_peak(1,t_w_on) = mean_residual_CI_artifact(31,t_w_on);

%Offset
temp_wind_offset(1,1) = find(time_average >= length_stim -0.005,1,'First');
temp_wind_offset(1,2) = find(time_average <= length_stim + 0.07,1,'Last');
t_w_off = [temp_wind_offset(1,1):temp_wind_offset(1,2)];
second_peak = zeros(1,size(mean_residual_CI_artifact,2));
second_peak(1,t_w_off) = mean_residual_CI_artifact(31,t_w_off);

artifact_on_off = first_peak + second_peak;

%[sf gg out] = fit(artifact_on_off',aligned_average_trials(31,:)', 'smoothingspline','SmoothingParam', 1);
%[sf gg out] = fit(mean_residual_CI_artifact(31,:)',aligned_average_trials(31,:)', 'smoothingspline','SmoothingParam', 1);

%Evaluating the spline with the data points used to predict the artifact 
%spline_fit = ppval(sf.p,artifact_on_off);
%}





