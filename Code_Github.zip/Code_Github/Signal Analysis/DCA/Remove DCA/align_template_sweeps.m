function temp_template_sweeps = align_template_sweeps(template_sweeps,time_average);

%% Function used to align the "CI artifact sweeps" based on the cross-correlation
% The time window used goes from -10ms pre-stimulus to 10ms post stimulus
%start_time_align = find(time_average <= -0.005,1,'Last');    
%end_time_align = find(time_average >= (length_stim + 0.025),1,'First');


%templ_sweeps = template_sweeps(1,:);
save_synchr_sweeps = [];
template_grand_av = mean(template_sweeps);

for hh = 1:size(template_sweeps,1)

    [corr_val,lags_corr] = xcorr(template_grand_av,template_sweeps(hh,:),'biased');
    
    %find the position of the max value
    pos_max = lags_corr(find(max(corr_val) == corr_val));
    
    %Shift the sweep based on the max(corr val) calculated 
    aligned_sweep = circshift(template_sweeps(hh,:),[1 pos_max]);
    save_synchr_sweeps = [save_synchr_sweeps;aligned_sweep];
   
end

temp_template_sweeps = mean(save_synchr_sweeps);
