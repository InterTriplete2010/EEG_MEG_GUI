function varargout = Remove_DCA_Algorithm(varargin)
% REMOVE_DCA_ALGORITHM MATLAB code for Remove_DCA_Algorithm.fig
%      REMOVE_DCA_ALGORITHM, by itself, creates a new REMOVE_DCA_ALGORITHM or raises the existing
%      singleton*.
%
%      H = REMOVE_DCA_ALGORITHM returns the handle to a new REMOVE_DCA_ALGORITHM or the handle to
%      the existing singleton*.
%
%      REMOVE_DCA_ALGORITHM('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in REMOVE_DCA_ALGORITHM.M with the given input arguments.
%
%      REMOVE_DCA_ALGORITHM('Property','Value',...) creates a new REMOVE_DCA_ALGORITHM or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before Remove_DCA_Algorithm_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to Remove_DCA_Algorithm_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help Remove_DCA_Algorithm

% Last Modified by GUIDE v2.5 18-Aug-2015 15:32:02

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Remove_DCA_Algorithm_OpeningFcn, ...
                   'gui_OutputFcn',  @Remove_DCA_Algorithm_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before Remove_DCA_Algorithm is made visible.
function Remove_DCA_Algorithm_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to Remove_DCA_Algorithm (see VARARGIN)

% Choose default command line output for Remove_DCA_Algorithm
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes Remove_DCA_Algorithm wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = Remove_DCA_Algorithm_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Remove the DCA
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in Remove_DCA_Alg.
function Remove_DCA_Alg_Callback(hObject, eventdata, handles)
% hObject    handle to Remove_DCA_Alg (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global template_file;
global template_directory;
global eeg_file;
global eeg_directory;

output_name = get(handles.Name_DCA_File,'String');

remove_dca_function(template_directory,template_file,eeg_directory,eeg_file,output_name)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Upload the average
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in Upload_DCA_Average.
function Upload_DCA_Average_Callback(hObject, eventdata, handles)
% hObject    handle to Upload_DCA_Average (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global eeg_file;
global eeg_directory;

[eeg_file,eeg_directory] = uigetfile('*.mat','Select the mat file');

set(handles.DCA_Average_Uploaded,'String',eeg_file);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Average uploaded
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function DCA_Average_Uploaded_Callback(hObject, eventdata, handles)
% hObject    handle to DCA_Average_Uploaded (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of DCA_Average_Uploaded as text
%        str2double(get(hObject,'String')) returns contents of DCA_Average_Uploaded as a double


% --- Executes during object creation, after setting all properties.
function DCA_Average_Uploaded_CreateFcn(hObject, eventdata, handles)
% hObject    handle to DCA_Average_Uploaded (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Upload the template
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in Upload_DCA_Template.
function Upload_DCA_Template_Callback(hObject, eventdata, handles)
% hObject    handle to Upload_DCA_Template (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global template_file;
global template_directory;

[template_file,template_directory] = uigetfile('*.mat','Select the mat file');

set(handles.DCA_Template_Uploaded,'String',template_file);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Template uploaded
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function DCA_Template_Uploaded_Callback(hObject, eventdata, handles)
% hObject    handle to DCA_Template_Uploaded (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of DCA_Template_Uploaded as text
%        str2double(get(hObject,'String')) returns contents of DCA_Template_Uploaded as a double


% --- Executes during object creation, after setting all properties.
function DCA_Template_Uploaded_CreateFcn(hObject, eventdata, handles)
% hObject    handle to DCA_Template_Uploaded (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Name of the output file
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Name_DCA_File_Callback(hObject, eventdata, handles)
% hObject    handle to Name_DCA_File (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Name_DCA_File as text
%        str2double(get(hObject,'String')) returns contents of Name_DCA_File as a double


% --- Executes during object creation, after setting all properties.
function Name_DCA_File_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Name_DCA_File (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

