function varargout = FFT_Cortex(varargin)
% FFT_CORTEX MATLAB code for FFT_Cortex.fig
%      FFT_CORTEX, by itself, creates a new FFT_CORTEX or raises the existing
%      singleton*.
%
%      H = FFT_CORTEX returns the handle to a new FFT_CORTEX or the handle to
%      the existing singleton*.
%
%      FFT_CORTEX('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in FFT_CORTEX.M with the given input arguments.
%
%      FFT_CORTEX('Property','Value',...) creates a new FFT_CORTEX or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before FFT_Cortex_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to FFT_Cortex_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help FFT_Cortex

% Last Modified by GUIDE v2.5 22-Apr-2019 16:00:48

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @FFT_Cortex_OpeningFcn, ...
                   'gui_OutputFcn',  @FFT_Cortex_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before FFT_Cortex is made visible.
function FFT_Cortex_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to FFT_Cortex (see VARARGIN)

% Choose default command line output for FFT_Cortex
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes FFT_Cortex wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = FFT_Cortex_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Upload the directory with the files to be analyzed
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in Upload_Dir_FFT.
function Upload_Dir_FFT_Callback(hObject, eventdata, handles)
% hObject    handle to Upload_Dir_FFT (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global Files_Mat_file_selected_FFT;
global Files_Mat_file_directory_FFT;

[Files_Mat_file_selected_FFT,Files_Mat_file_directory_FFT] = uigetfile('*.mat','Select the mat file');

set(handles.Dir_Uploaded_FFT,'String',Files_Mat_file_directory_FFT);


function Dir_Uploaded_FFT_Callback(hObject, eventdata, handles)
% hObject    handle to Dir_Uploaded_FFT (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Dir_Uploaded_FFT as text
%        str2double(get(hObject,'String')) returns contents of Dir_Uploaded_FFT as a double


% --- Executes during object creation, after setting all properties.
function Dir_Uploaded_FFT_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Dir_Uploaded_FFT (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Extract the frequencies
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in Extract_Frequencies_FFT.
function Extract_Frequencies_FFT_Callback(hObject, eventdata, handles)
% hObject    handle to Extract_Frequencies_FFT (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global Files_Mat_file_selected_FFT;
global Files_Mat_file_directory_FFT;

freq_bins_number = str2double(get(handles.Freq_Bin_FFT,'String'));
freq_analysis = str2num(get(handles.Frequencies_Analysis_FFT,'String'));

start_wind_FFT_Signal = str2double(get(handles.Start_T_FFT,'String'))/1000;
end_wind_FFT_Signal = str2double(get(handles.End_T_FFT,'String'))/1000;

Start_wind_FFT_Noise = str2double(get(handles.Start_T_Noise,'String'))/1000;
end_wind_FFT_Noise = str2double(get(handles.End_T_Noise,'String'))/1000;

start_freq_axis = str2double(get(handles.Start_Freq_FFT,'String'));
end_freq_axis = str2double(get(handles.End_Freq_FFT,'String'));

cf_analysis = str2num(get(handles.CF_Cortex,'String'));

condition_eeg_recording = get(handles.Condition_EEG,'String');

FFT_cortex_function(freq_bins_number,freq_analysis,start_wind_FFT_Signal,end_wind_FFT_Signal,Files_Mat_file_directory_FFT,start_freq_axis,end_freq_axis,...
                    Start_wind_FFT_Noise,end_wind_FFT_Noise,cf_analysis,condition_eeg_recording);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

message = 'Calculations completed';

        msgbox(message,'Calculations completed','warn');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Frequency bins
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Freq_Bin_FFT_Callback(hObject, eventdata, handles)
% hObject    handle to Freq_Bin_FFT (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Freq_Bin_FFT as text
%        str2double(get(hObject,'String')) returns contents of Freq_Bin_FFT as a double


% --- Executes during object creation, after setting all properties.
function Freq_Bin_FFT_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Freq_Bin_FFT (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Frequencies to be analyzed
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Frequencies_Analysis_FFT_Callback(hObject, eventdata, handles)
% hObject    handle to Frequencies_Analysis_FFT (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Frequencies_Analysis_FFT as text
%        str2double(get(hObject,'String')) returns contents of Frequencies_Analysis_FFT as a double


% --- Executes during object creation, after setting all properties.
function Frequencies_Analysis_FFT_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Frequencies_Analysis_FFT (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Start time window for the Signal
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Start_T_FFT_Callback(hObject, eventdata, handles)
% hObject    handle to Start_T_FFT (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Start_T_FFT as text
%        str2double(get(hObject,'String')) returns contents of Start_T_FFT as a double


% --- Executes during object creation, after setting all properties.
function Start_T_FFT_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Start_T_FFT (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%End time window for the Signal
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function End_T_FFT_Callback(hObject, eventdata, handles)
% hObject    handle to End_T_FFT (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of End_T_FFT as text
%        str2double(get(hObject,'String')) returns contents of End_T_FFT as a double


% --- Executes during object creation, after setting all properties.
function End_T_FFT_CreateFcn(hObject, eventdata, handles)
% hObject    handle to End_T_FFT (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Start frequency FFT
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Start_Freq_FFT_Callback(hObject, eventdata, handles)
% hObject    handle to Start_Freq_FFT (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Start_Freq_FFT as text
%        str2double(get(hObject,'String')) returns contents of Start_Freq_FFT as a double


% --- Executes during object creation, after setting all properties.
function Start_Freq_FFT_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Start_Freq_FFT (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%End frequency FFT
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function End_Freq_FFT_Callback(hObject, eventdata, handles)
% hObject    handle to End_Freq_FFT (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of End_Freq_FFT as text
%        str2double(get(hObject,'String')) returns contents of End_Freq_FFT as a double


% --- Executes during object creation, after setting all properties.
function End_Freq_FFT_CreateFcn(hObject, eventdata, handles)
% hObject    handle to End_Freq_FFT (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Start time window for the Noise
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Start_T_Noise_Callback(hObject, eventdata, handles)
% hObject    handle to Start_T_Noise (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Start_T_Noise as text
%        str2double(get(hObject,'String')) returns contents of Start_T_Noise as a double


% --- Executes during object creation, after setting all properties.
function Start_T_Noise_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Start_T_Noise (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%End time window for the Noise
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function End_T_Noise_Callback(hObject, eventdata, handles)
% hObject    handle to End_T_Noise (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of End_T_Noise as text
%        str2double(get(hObject,'String')) returns contents of End_T_Noise as a double


% --- Executes during object creation, after setting all properties.
function End_T_Noise_CreateFcn(hObject, eventdata, handles)
% hObject    handle to End_T_Noise (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%CF of the analysis
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function CF_Cortex_Callback(hObject, eventdata, handles)
% hObject    handle to CF_Cortex (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of CF_Cortex as text
%        str2double(get(hObject,'String')) returns contents of CF_Cortex as a double


% --- Executes during object creation, after setting all properties.
function CF_Cortex_CreateFcn(hObject, eventdata, handles)
% hObject    handle to CF_Cortex (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Condition for EEG
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Condition_EEG_Callback(hObject, eventdata, handles)
% hObject    handle to Condition_EEG (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Condition_EEG as text
%        str2double(get(hObject,'String')) returns contents of Condition_EEG as a double


% --- Executes during object creation, after setting all properties.
function Condition_EEG_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Condition_EEG (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
