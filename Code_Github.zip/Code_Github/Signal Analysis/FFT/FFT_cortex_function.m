function FFT_cortex_function(freq_bins_number,freq_analysis,start_wind_FFT_Signal,end_wind_FFT_Signal,Files_Mat_file_directory_FFT,start_freq_axis,end_freq_axis,...
                    Start_wind_FFT_Noise,end_wind_FFT_Noise,cf_analysis,condition_eeg_recording);

clear save_fft;
clear save_fft_signal;
clear save_sample;

%Initializing the excel file where to save the data
save_fft_signal(1,1) = {'subject_ID'};
%save_fft_noise(1,1) = {'File'};
save_freq_resp_av = [];
save_freq_resp_av_Noise = [];
save_max_pxx = [];

for kk = 1:length(freq_analysis)

    if kk == 1
        
save_fft_signal(1,kk + 1) = {'session'};

    end
    
save_fft_signal(1,kk + 2) = {['s' num2str(cf_analysis) '_har_' num2str(freq_analysis(kk))]};
%save_fft_noise(1,kk + 1) = {freq_analysis(kk)};
save_fft_signal(1,kk + 2 + length(freq_analysis)) = {['n' num2str(cf_analysis) '_har_' num2str(freq_analysis(kk))]};

save_fft_signal(1,kk + 2 + length(freq_analysis)*2) = {['SNR' num2str(cf_analysis) '_har_' num2str(freq_analysis(kk))]};

end

cd(Files_Mat_file_directory_FFT)

mat_files = dir;

[files_number] = size(mat_files,1);

track_files = 0;

for ii = 3:files_number
    
    if (strcmp(mat_files(ii).name(end-3:end), '.mat') == 1)

        track_files = track_files + 1;
        
  matrix_file = mat_files(ii).name;      
  
  load(matrix_file);

  Pxx = [];
  Freq = [];

if track_files == 1  
  if start_wind_FFT_Signal == 0
     
      start_wind_FFT_Signal = 1;
            
  else
      
      start_wind_FFT_Signal = round(start_wind_FFT_Signal*data_exported.sampling_frequency);
      
  end
  
  if end_wind_FFT_Signal > data_exported.time_average(end)
     
      if size(data_exported.average_trials,2) > size(data_exported.average_trials,1)
            
      end_wind_FFT_Signal = size(data_exported.average_trials,2);
      
      else
         
        end_wind_FFT_Signal = size(data_exported.average_trials,1); 
          
      end
      
  else
      
      end_wind_FFT_Signal = round(end_wind_FFT_Signal*data_exported.sampling_frequency);
      
  end
  
end

if track_files == 1  
  if Start_wind_FFT_Noise == 0
     
      Start_wind_FFT_Noise = 1;
            
  else
      
      Start_wind_FFT_Noise = round(Start_wind_FFT_Noise*data_exported.sampling_frequency);
      
  end
  
  if end_wind_FFT_Noise > data_exported.time_average(end)
     
      if size(data_exported.average_trials,2) > size(data_exported.average_trials,1)
      
      end_wind_FFT_Noise = size(data_exported.average_trials,2);
      
      else
          
          end_wind_FFT_Noise = size(data_exported.average_trials,1);
                
      end
      
  else
      
      end_wind_FFT_Noise = round(end_wind_FFT_Noise*data_exported.sampling_frequency);
      
  end
  
end

  temp_av = [];
  
  if size(data_exported.average_trials,2) > size(data_exported.average_trials,1)
      
  temp_av = data_exported.average_trials(:,start_wind_FFT_Signal:end_wind_FFT_Signal);
  
  else
      
     temp_av = data_exported.average_trials(start_wind_FFT_Signal:end_wind_FFT_Signal,:)'; 
  
  end
  
  save_freq_resp_av = [save_freq_resp_av;temp_av];
  
  temp_av_noise = [];
  
  if size(data_exported.average_trials,2) > size(data_exported.average_trials,1)
      
  temp_av_noise = data_exported.average_trials(:,Start_wind_FFT_Noise:end_wind_FFT_Noise);
  
  else
      
     temp_av_noise = data_exported.average_trials(Start_wind_FFT_Noise:end_wind_FFT_Noise,1)';
  
  end
  
  save_freq_resp_av_Noise = [save_freq_resp_av_Noise;temp_av_noise];

  [Pxx Freq] = pwelch(temp_av,size(temp_av,2),size(temp_av,2)/2,round(data_exported.sampling_frequency),data_exported.sampling_frequency);
    [Pxx_Noise Freq] = pwelch(temp_av_noise,size(temp_av_noise,2),size(temp_av_noise,2)/2,round(data_exported.sampling_frequency),data_exported.sampling_frequency);

  
%Find the frequency components
if track_files == 1

    curr_fig =figure;
    find_freq = zeros(1,length(freq_analysis));

for nn = 1:length(find_freq)
    
find_freq(1,nn) = find(Freq == freq_analysis(nn));

end

end

array_freq_signal = zeros(1,length(find_freq));
find_offset = strfind(matrix_file,'_');
save_fft_signal(track_files + 1,1) = {matrix_file(1:find_offset - 1)};

%array_freq_noise = zeros(1,length(find_freq));
%save_fft_noise(track_files + 1,1) = {matrix_file};

for kk = 1:length(find_freq)
    
    if kk == 1
        
        save_fft_signal(track_files + 1,kk + 1) = {condition_eeg_recording};
        
    end
    
    power_fft_signal = mean(Pxx(find_freq(kk) - round(freq_bins_number/2):find_freq(kk) + round(freq_bins_number/2)));
    array_freq_signal(1,kk) = mean(sqrt(Pxx(find_freq(kk) - round(freq_bins_number/2):find_freq(kk) + round(freq_bins_number/2))));
    save_fft_signal(track_files + 1,kk + 2) = {array_freq_signal(1,kk)};
       
    power_fft_noise = mean(Pxx_Noise(find_freq(kk) - round(freq_bins_number/2):find_freq(kk) + round(freq_bins_number/2)));
    array_freq_noise(1,kk) = mean(sqrt(Pxx_Noise(find_freq(kk) - round(freq_bins_number/2):find_freq(kk) + round(freq_bins_number/2))));
    %save_fft_noise(track_files + 1,kk + 1) = {array_freq_noise(1,kk)};
    save_fft_signal(track_files + 1,kk + 2 + length(freq_analysis)) = {array_freq_noise(1,kk)};
    
    save_fft_signal (track_files + 1,kk + 2 + length(freq_analysis)*2) = {10*log10(power_fft_signal./power_fft_noise)};
end

save_max_pxx = [save_max_pxx;max(sqrt(Pxx(start_freq_axis + 1:end_freq_axis + 1)))];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Plotting and saving the grand average
figure(curr_fig.Number)
subplot(2,2,1)
plot(Freq,sqrt(Pxx))
hold on

figure(curr_fig.Number)
subplot(2,2,2)
plot(Freq,sqrt(Pxx_Noise))
hold on
    end

end

figure(curr_fig.Number)
subplot(2,2,1)
hold off
xlabel('\bfFrequency (Hz)')
ylabel('\bfAmplitude (\muV)')
title('\bfIndividual FFT')
set(gca,'fontweight','bold')

axis ([start_freq_axis end_freq_axis 0 max(save_max_pxx)])

figure(curr_fig.Number)
subplot(2,2,2)
hold off
xlabel('\bfFrequency (Hz)')
ylabel('\bfAmplitude (\muV)')
title('\bfIndividual FFT Noise')
set(gca,'fontweight','bold')

axis ([start_freq_axis end_freq_axis 0 max(save_max_pxx)])

Pxx_av = [];
Freq_av = [];

try
    
[Pxx_av Freq_av] = pwelch(mean(save_freq_resp_av),size(save_freq_resp_av,2),size(save_freq_resp_av,2)/2,round(data_exported.sampling_frequency),data_exported.sampling_frequency);

catch
  
    [Pxx_av Freq_av] = pwelch(save_freq_resp_av,size(save_freq_resp_av,2),size(save_freq_resp_av,2)/2,round(data_exported.sampling_frequency),data_exported.sampling_frequency);
    
end

subplot(2,2,3)
plot(Freq_av,sqrt(Pxx_av))
xlabel('\bfFrequency (Hz)')
ylabel('\bfAmplitude (\muV)')
title('\bfGrand Average')
set(gca,'fontweight','bold')
axis ([start_freq_axis end_freq_axis 0 max(sqrt(Pxx_av(start_freq_axis + 1:end_freq_axis + 1)))])


Pxx_av_Noise = [];
Freq_av_Noise = [];

try 
    
[Pxx_av_Noise Freq_av_Noise] = pwelch(mean(save_freq_resp_av_Noise),size(save_freq_resp_av_Noise,2),size(save_freq_resp_av_Noise,2)/2,round(data_exported.sampling_frequency),data_exported.sampling_frequency);

catch
   
  [Pxx_av_Noise Freq_av_Noise] = pwelch(save_freq_resp_av_Noise,size(save_freq_resp_av_Noise,2),size(save_freq_resp_av_Noise,2)/2,round(data_exported.sampling_frequency),data_exported.sampling_frequency);  
    
end

subplot(2,2,4)
plot(Freq_av_Noise,sqrt(Pxx_av_Noise))
xlabel('\bfFrequency (Hz)')
ylabel('\bfAmplitude (\muV)')
title('\bfGrand Average Noise')
set(gca,'fontweight','bold')
axis ([start_freq_axis end_freq_axis 0 max(sqrt(Pxx_av_Noise(start_freq_axis + 1:end_freq_axis + 1)))])

saveas(gcf,['FFT_' num2str(size(save_freq_resp_av,1)) '_Files.fig']) 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   
    xlswrite (['FFT_' num2str(size(save_freq_resp_av,1)) '_Files'],save_fft_signal,1)
    %xlswrite ('FFT_Freq_Comp',save_fft_noise,2)
    