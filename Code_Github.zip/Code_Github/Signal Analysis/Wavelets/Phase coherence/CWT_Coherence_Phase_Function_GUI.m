function varargout = CWT_Coherence_Phase_Function_GUI(varargin)
% CWT_COHERENCE_PHASE_FUNCTION_GUI M-file for CWT_Coherence_Phase_Function_GUI.fig
%      CWT_COHERENCE_PHASE_FUNCTION_GUI, by itself, creates a new CWT_COHERENCE_PHASE_FUNCTION_GUI or raises the existing
%      singleton*.
%
%      H = CWT_COHERENCE_PHASE_FUNCTION_GUI returns the handle to a new CWT_COHERENCE_PHASE_FUNCTION_GUI or the handle to
%      the existing singleton*.
%
%      CWT_COHERENCE_PHASE_FUNCTION_GUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in CWT_COHERENCE_PHASE_FUNCTION_GUI.M with the given input arguments.
%
%      CWT_COHERENCE_PHASE_FUNCTION_GUI('Property','Value',...) creates a new CWT_COHERENCE_PHASE_FUNCTION_GUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before CWT_Coherence_Phase_Function_GUI_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to CWT_Coherence_Phase_Function_GUI_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help CWT_Coherence_Phase_Function_GUI

% Last Modified by GUIDE v2.5 15-Jan-2014 11:18:06

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @CWT_Coherence_Phase_Function_GUI_OpeningFcn, ...
                   'gui_OutputFcn',  @CWT_Coherence_Phase_Function_GUI_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before CWT_Coherence_Phase_Function_GUI is made visible.
function CWT_Coherence_Phase_Function_GUI_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to CWT_Coherence_Phase_Function_GUI (see VARARGIN)

% Choose default command line output for CWT_Coherence_Phase_Function_GUI
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes CWT_Coherence_Phase_Function_GUI wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = CWT_Coherence_Phase_Function_GUI_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Low frequency
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Low_Freq_CWT_Phase_Coherence_Callback(hObject, eventdata, handles)
% hObject    handle to Low_Freq_CWT_Phase_Coherence (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Low_Freq_CWT_Phase_Coherence as text
%        str2double(get(hObject,'String')) returns contents of Low_Freq_CWT_Phase_Coherence as a double


% --- Executes during object creation, after setting all properties.
function Low_Freq_CWT_Phase_Coherence_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Low_Freq_CWT_Phase_Coherence (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%High frequency
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function High_Freq_CWT_Phase_Coherence_Callback(hObject, eventdata, handles)
% hObject    handle to High_Freq_CWT_Phase_Coherence (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of High_Freq_CWT_Phase_Coherence as text
%        str2double(get(hObject,'String')) returns contents of High_Freq_CWT_Phase_Coherence as a double


% --- Executes during object creation, after setting all properties.
function High_Freq_CWT_Phase_Coherence_CreateFcn(hObject, eventdata, handles)
% hObject    handle to High_Freq_CWT_Phase_Coherence (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Starting time for the analysis
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Start_Window_CWT_Coherence_Phase_Callback(hObject, eventdata, handles)
% hObject    handle to Start_Window_CWT_Coherence_Phase (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Start_Window_CWT_Coherence_Phase as text
%        str2double(get(hObject,'String')) returns contents of Start_Window_CWT_Coherence_Phase as a double


% --- Executes during object creation, after setting all properties.
function Start_Window_CWT_Coherence_Phase_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Start_Window_CWT_Coherence_Phase (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Ending time for the analysis
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function End_Window_CWT_Coherence_Phase_Callback(hObject, eventdata, handles)
% hObject    handle to End_Window_CWT_Coherence_Phase (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of End_Window_CWT_Coherence_Phase as text
%        str2double(get(hObject,'String')) returns contents of End_Window_CWT_Coherence_Phase as a double


% --- Executes during object creation, after setting all properties.
function End_Window_CWT_Coherence_Phase_CreateFcn(hObject, eventdata, handles)
% hObject    handle to End_Window_CWT_Coherence_Phase (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Clycles for the phase coherence
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Cycles_Phase_Coherence_Callback(hObject, eventdata, handles)
% hObject    handle to Cycles_Phase_Coherence (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Cycles_Phase_Coherence as text
%        str2double(get(hObject,'String')) returns contents of Cycles_Phase_Coherence as a double


% --- Executes during object creation, after setting all properties.
function Cycles_Phase_Coherence_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Cycles_Phase_Coherence (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Upload the EEG
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in Upload_EEG_CWT_Phase_Coherence.
function Upload_EEG_CWT_Phase_Coherence_Callback(hObject, eventdata, handles)
% hObject    handle to Upload_EEG_CWT_Phase_Coherence (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global EEG_cwt_phase_coherence_selected;
global EEG_cwt_phase_coherence_directory;

[EEG_cwt_phase_coherence_selected,EEG_cwt_phase_coherence_directory] = uigetfile('*.mat','Select the EEG file');

cd(EEG_cwt_phase_coherence_directory)
load_signal = load(EEG_cwt_phase_coherence_selected);

set(handles.EEG_CWT_Phase_Coherence_Uploaded,'String',EEG_cwt_phase_coherence_selected);

try
        
    set(handles.Channel_EEG,'String',load_signal.data_exported.labels)

catch
   
    set(handles.Channel_EEG,'String','Cz')
    
end



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Upload the kinematics
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in Upload_EEGII_CWT_Phase_Coherence.
function Upload_EEGII_CWT_Phase_Coherence_Callback(hObject, eventdata, handles)
% hObject    handle to Upload_EEGII_CWT_Phase_Coherence (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global EEGII_cwt_phase_coherence_selected;
global EEGII_cwt_phase_coherence_directory;

[EEGII_cwt_phase_coherence_selected,EEGII_cwt_phase_coherence_directory] = uigetfile('*.mat','Select the EEG file');

set(handles.EEGII_CWT_Phase_Coherence_Uploaded,'String',EEGII_cwt_phase_coherence_selected);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%EEG uploaded
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function EEG_CWT_Phase_Coherence_Uploaded_Callback(hObject, eventdata, handles)
% hObject    handle to EEG_CWT_Phase_Coherence_Uploaded (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of EEG_CWT_Phase_Coherence_Uploaded as text
%        str2double(get(hObject,'String')) returns contents of EEG_CWT_Phase_Coherence_Uploaded as a double


% --- Executes during object creation, after setting all properties.
function EEG_CWT_Phase_Coherence_Uploaded_CreateFcn(hObject, eventdata, handles)
% hObject    handle to EEG_CWT_Phase_Coherence_Uploaded (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Kinematics uploaded
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function EEGII_CWT_Phase_Coherence_Uploaded_Callback(hObject, eventdata, handles)
% hObject    handle to EEGII_CWT_Phase_Coherence_Uploaded (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of EEGII_CWT_Phase_Coherence_Uploaded as text
%        str2double(get(hObject,'String')) returns contents of EEGII_CWT_Phase_Coherence_Uploaded as a double


% --- Executes during object creation, after setting all properties.
function EEGII_CWT_Phase_Coherence_Uploaded_CreateFcn(hObject, eventdata, handles)
% hObject    handle to EEGII_CWT_Phase_Coherence_Uploaded (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Calculate the phase coherence
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in Calculate_CWT_Phase_Coherence.
function Calculate_CWT_Phase_Coherence_Callback(hObject, eventdata, handles)
% hObject    handle to Calculate_CWT_Phase_Coherence (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global EEG_cwt_phase_coherence_selected;
global EEG_cwt_phase_coherence_directory;
global EEGII_cwt_phase_coherence_selected;
global EEGII_cwt_phase_coherence_directory;

%% Upload the EEG
cd(EEGII_cwt_phase_coherence_directory)
dir_EEG_II = dir;

cd(EEG_cwt_phase_coherence_directory)
dir_EEG_I = dir;

eeg_file_uploaded = load(EEG_cwt_phase_coherence_selected);
sampling_frequency = eeg_file_uploaded.data_exported.sampling_frequency;

%% Variables for EEG 
start_t = find(eeg_file_uploaded.data_exported.time >= str2double(get(handles.Start_Window_CWT_Coherence_Phase,'String')),1,'First');

if (start_t == 0)
    
    start_t = 1;
    
end

end_t = find(eeg_file_uploaded.data_exported.time >= str2double(get(handles.End_Window_CWT_Coherence_Phase,'String')),1,'First');

tt_domain_analysis = eeg_file_uploaded.data_exported.time(1,start_t:end_t);

channel_chosen = get(handles.Channel_EEG,'Value');
names_channel_temp = get(handles.Channel_EEG,'String');
names_channel = names_channel_temp(channel_chosen);

for hh = 3:size(dir_EEG_I,1)

    temp_load_I = [];
    EEGII_file_uploaded = [];
    
    eeg_file_data = [];
    EEGII_file_data = [];
        
try
    
    if (get(handles.Envelope_Fine_Structure_PLV,'Value') == 1)
    
        cd(EEG_cwt_phase_coherence_directory)
        temp_load_I = load(dir_EEG_I(hh).name);
eeg_file_data = temp_load_I.data_exported.average_trials(:,start_t:end_t);

cd(EEGII_cwt_phase_coherence_directory)
EEGII_file_uploaded = load(dir_EEG_II(hh).name);
EEGII_file_data = EEGII_file_uploaded.data_exported.average_trials(:,start_t:end_t);

    else
       
        eeg_file_data = eeg_file_uploaded.data_exported.average_sub(:,start_t:end_t);
cd(EEGII_cwt_phase_coherence_directory)
EEGII_file_uploaded = load(EEGII_cwt_phase_coherence_selected);
EEGII_file_data = EEGII_file_uploaded.data_exported.average_sub(:,start_t:end_t);
        
    end

catch
    
    eeg_file_data = eeg_file_uploaded.data_exported.grand_av(:,start_t:end_t);
cd(EEGII_cwt_phase_coherence_directory)
EEGII_file_uploaded = load(EEGII_cwt_phase_coherence_selected);
EEGII_file_data = EEGII_file_uploaded.data_exported.grand_av(:,start_t:end_t);
    
end

try
events_trigger = eeg_file_uploaded.data_exported.events_trigger;

catch

    events_trigger = 0;
    
end


%% Variables for the coherence analysis
lowest_frequency = str2double(get(handles.Low_Freq_CWT_Phase_Coherence,'String'));
highest_frequency = str2double(get(handles.High_Freq_CWT_Phase_Coherence,'String'));
decimation_factor = str2double(get(handles.Decimation_Factor_CWT_Phase_Coherence,'String'));

%stim_onset = round((str2double(get(handles.Onset_Phase_Coherence,'String'))/1000)*sampling_frequency);% - start_t + 1;
stim_onset = str2double(get(handles.Onset_Phase_Coherence,'String'));

freq_average = str2double(get(handles.Frequencies_Average_Phase_Coherence,'String'));

[sign_threshold cycles_number_coherence] = sign_threshold_function(get(handles.Significance_Threshold_Phase_Coherence,'Value')); 

set(handles.Cycles_Phase_Coherence,'String',cycles_number_coherence);

CWT_Phase_Coherence(dir_EEG_I(hh).name,dir_EEG_II(hh).name,...
    names_channel,events_trigger,eeg_file_data,EEGII_file_data,start_t,end_t,...
    sampling_frequency,cycles_number_coherence,lowest_frequency,highest_frequency,decimation_factor,stim_onset,freq_average,...
    sign_threshold,tt_domain_analysis);
  
end

%% Calculations have been completed
  message = 'Calculations completed';
msgbox(message,'End of the calculations','warn','replace');


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Decimation factor
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Decimation_Factor_CWT_Phase_Coherence_Callback(hObject, eventdata, handles)
% hObject    handle to Decimation_Factor_CWT_Phase_Coherence (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Decimation_Factor_CWT_Phase_Coherence as text
%        str2double(get(hObject,'String')) returns contents of Decimation_Factor_CWT_Phase_Coherence as a double


% --- Executes during object creation, after setting all properties.
function Decimation_Factor_CWT_Phase_Coherence_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Decimation_Factor_CWT_Phase_Coherence (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Channel chosen
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on selection change in Channel_EEG.
function Channel_EEG_Callback(hObject, eventdata, handles)
% hObject    handle to Channel_EEG (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns Channel_EEG contents as cell array
%        contents{get(hObject,'Value')} returns selected item from Channel_EEG


% --- Executes during object creation, after setting all properties.
function Channel_EEG_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Channel_EEG (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Onset of the stimulus (in ms)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Onset_Phase_Coherence_Callback(hObject, eventdata, handles)
% hObject    handle to Onset_Phase_Coherence (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Onset_Phase_Coherence as text
%        str2double(get(hObject,'String')) returns contents of Onset_Phase_Coherence as a double


% --- Executes during object creation, after setting all properties.
function Onset_Phase_Coherence_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Onset_Phase_Coherence (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Frequencies to be averaged
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Frequencies_Average_Phase_Coherence_Callback(hObject, eventdata, handles)
% hObject    handle to Frequencies_Average_Phase_Coherence (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Frequencies_Average_Phase_Coherence as text
%        str2double(get(hObject,'String')) returns contents of Frequencies_Average_Phase_Coherence as a double


% --- Executes during object creation, after setting all properties.
function Frequencies_Average_Phase_Coherence_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Frequencies_Average_Phase_Coherence (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Significance threshold for the phase
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on selection change in Significance_Threshold_Phase_Coherence.
function Significance_Threshold_Phase_Coherence_Callback(hObject, eventdata, handles)
% hObject    handle to Significance_Threshold_Phase_Coherence (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns Significance_Threshold_Phase_Coherence contents as cell array
%        contents{get(hObject,'Value')} returns selected item from Significance_Threshold_Phase_Coherence


% --- Executes during object creation, after setting all properties.
function Significance_Threshold_Phase_Coherence_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Significance_Threshold_Phase_Coherence (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Envelope - Fine Structure for PLV
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on selection change in Envelope_Fine_Structure_PLV.
function Envelope_Fine_Structure_PLV_Callback(hObject, eventdata, handles)
% hObject    handle to Envelope_Fine_Structure_PLV (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns Envelope_Fine_Structure_PLV contents as cell array
%        contents{get(hObject,'Value')} returns selected item from Envelope_Fine_Structure_PLV


% --- Executes during object creation, after setting all properties.
function Envelope_Fine_Structure_PLV_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Envelope_Fine_Structure_PLV (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
