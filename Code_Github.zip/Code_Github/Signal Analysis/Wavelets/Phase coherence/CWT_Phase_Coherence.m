function CWT_Phase_Coherence(EEG_cwt_phase_coherence_selected,EEGII_cwt_phase_coherence_selected,...
    name_channels,events_trigger,FileName_EEG,FileName_EEGII,start_t,end_t,...
sampling_frequency,cycles_number_coherence,lowest_frequency,highest_frequency,decimation_factor,stim_onset,freq_average,...
sign_threshold,tt_domain);

try
   
    name_channels = cell2mat(name_channels);
    
catch
    
end

tic
wavelet_builder_check = 0;
wavelet_builder_time_frequency_check = 0;

[channels_eeg samples_eeg] = size(FileName_EEG);
number_of_calculations = channels_eeg;

for ll = 1:channels_eeg
     
    fre_coherence_builder = lowest_frequency;
    fre_coherence_plotting = lowest_frequency;
    
%% Builiding up the mother wavelet 

if (wavelet_builder_check == 0)

    %% Checking if the number of samples is odd or even
check_odd_even = mod(samples_eeg,2);

if (check_odd_even == 1)

    FileName_EEG(:,end) = [];
    FileName_EEGII(:,end) = []; 
    
    [rows_signal columns_signal] = size(FileName_EEG);

else
    
    [rows_signal columns_signal] = size(FileName_EEG);

    
end   
    
border = columns_signal;
border_effect = columns_signal/2;

fs = sampling_frequency;%/decimation_factor;
N = columns_signal + border;  %Samples for the border effect
dt = 1/fs;   %Period
columns_dec = N/decimation_factor;
t = ((0:N-1)-N/2+1)*dt;

df = fs/columns_dec;   %Frequency resolution

f = (0:columns_dec-1)*df;

%Creating matrix "H" used to shift back the mother wavelet
h = zeros(1,N);
h_decimate = resample(h,1,decimation_factor); %DownSample "h"  
h_decimate(round(length(h_decimate)/2)) = 1;
H = fft(h_decimate);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Generation of wavelets to be stored in frequency domain
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

energy_track = zeros(1,length([lowest_frequency:1:highest_frequency]));

%This is used to start saving the frequencies from row "1"; for instance,
%if the starting frequency is "20", this line of code will make sure that
%20 Hz will be saved in the first row "j" (starting_point = 19 (20-1) and j = 1 (20-19))
starting_point = lowest_frequency - 1;
for f0 = lowest_frequency : highest_frequency 
sf = f0/7;
    st = 1/(2*pi*sf);
        A = 1/sqrt(st*sqrt(pi)); %Normalization factor
            j=f0-starting_point;
  
            ond(j,:) = A*exp(-t.^2/(2*st^2)).*exp(2*i*pi*f0*t); %Generation of the Mother Wavelet (The Morlet in this case)
             
            ond_signal = ond(j,:);
            
                energy_track(j) =  sum(abs(ond_signal).^2)/fs;
                        
            ond_dec = resample(ond_signal,1,decimation_factor); %DownSampling of the Mother Wavelet
            
                
            sg(j,:) = fft(ond_dec(1,:))./H;  %Computes FFT of the Mother Wavelet and shift wave back to zero (see Fourier Transform Property)
                
                ener(j)=sqrt(sum(sg(j,:).*conj(sg(j,:))))/N; %Computes the energy of the wavelet
                        freq(j)=f0;
                        
end;

%% Plotting the energy at each frequency to make sure they are all = 1;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure
plot([lowest_frequency:1:highest_frequency],energy_track)

xlabel('\bfFrequency')
ylabel('\bfEnergy')
title(['\bfEnergy of each frequency for each mother wavelet. The mean is: ' num2str(mean(energy_track))])
set(gca,'fontweight','bold')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

wavelet_builder_check = 1;  %This variable is used to avoid building the mother wavelet multiple times
border_effect = border_effect/decimation_factor;
end

%% Calculating the coefficients of signal X
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Creating the extension for the border effect for the signal "x"
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
message = 'Calculating the coefficients for EEGI';
msgbox(message,'Calculation in progress...','warn','replace');

EEG_temp = FileName_EEG(ll,:);
x_dec = resample(EEG_temp,1,decimation_factor);       
 
 border_effect = border_effect/decimation_factor;

[rows_dec columns_dec] = size(x_dec);

diff_add_first_sum_x = x_dec (1:border_effect);
diff_add_last_sum_x = x_dec (border_effect + 1:end);

diff_border_sum_x = zeros(rows_dec, columns_dec + border_effect*2);

diff_border_sum_x(rows_dec, 1:border_effect) = diff_add_last_sum_x(:,:);
diff_border_sum_x(rows_dec, columns_dec + 1 + border_effect:border_effect*2 + columns_dec) = diff_add_first_sum_x(:,:);
diff_border_sum_x(rows_dec, border_effect + 1:columns_dec + border_effect) = x_dec(rows_dec,:);
fft_diff_border_sum_x = fft(diff_border_sum_x);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

[r c] = size(sg);

        coefficient_x = zeros(r,c);
        
for k = 1:r
 
                    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Calculating the coeffcients of the signal "x"
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
            wmor_sum_x = sg(k,:);
                msig_sum_x = fft_diff_border_sum_x(rows_dec,:);
                      temp_sum_x = wmor_sum_x.*msig_sum_x; 
  temp_sum_x = ifft(temp_sum_x);
                             
             coefficient_x(k,:) = temp_sum_x;
            
                                    
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Removal of the border effect for signal "x"
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
elimination_border_sum_x = border_effect;

coefficient_x(:,1:elimination_border_sum_x) = [];

[righe_sum colonne_sum] = size(coefficient_x);

coefficient_x (:,columns_signal + 1:end) = [];



%% Calculating the coefficients of signal Y
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Creating the extension for the border effect for the signal "y"
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
message = 'Calculating the coefficients for EEGII';
msgbox(message,'Calculation in progress...','warn','replace');

y_temp = FileName_EEGII(ll,:);

y_dec = resample(y_temp,1,decimation_factor);       
    
 border_effect = border_effect/decimation_factor;

[rows_dec columns_dec] = size(y_dec);

diff_add_first_sum_y = y_dec (1:border_effect);
diff_add_last_sum_y = y_dec (border_effect + 1:end);

diff_border_sum_y = zeros(rows_dec, columns_dec + border_effect*2);

diff_border_sum_y(rows_dec, 1:border_effect) = diff_add_last_sum_y(:,:);
diff_border_sum_y(rows_dec, columns_dec + 1 + border_effect:border_effect*2 + columns_dec) = diff_add_first_sum_y(:,:);
diff_border_sum_y(rows_dec, border_effect + 1:columns_dec + border_effect) = y_dec(rows_dec,:);
fft_diff_border_sum_y = fft(diff_border_sum_y);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


[r c] = size(sg);
                    
        coefficient_y = zeros(r,c);
        
for k = 1:r
 
                    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Calculating the coeffcients of the signal "y"
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
        wmor_sum_y = sg(k,:);
                msig_sum_y = fft_diff_border_sum_y(rows_dec,:);
                      temp_sum_y = wmor_sum_y.*msig_sum_y; 
  temp_sum_y = ifft(temp_sum_y);
                             
             coefficient_y(k,:) = temp_sum_y;                     
                  
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Removal of the border effect for the signal "y"
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
elimination_border_sum_y = border_effect;

coefficient_y(:,1:elimination_border_sum_y) = [];

[righe_sum colonne_sum] = size(coefficient_y);

coefficient_y (:,columns_signal + 1:end) = [];



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Time-Frequency coherence function
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
number_of_calculations = number_of_calculations - 1;
message = ['Calculating the phase coeherence between EEGI and EEGII. Calculations remaining: ' num2str(number_of_calculations)];
msgbox(message,'Calculation in progress...','warn','replace');

[rows_coeff columns_coeff] = size(coefficient_x);


    extension_coefficient = 200; %134; %Last 10ms of recording;
extension_size = columns_coeff - extension_coefficient + 1;
   
coeff_x_last_4 = coefficient_x(:,extension_size:end); %This corresponds to the last 10 ms of the recordings
coeff_y_last_4 = coefficient_y(:,extension_size:end); %This corresponds to the last 10 ms of the recordings

new_coeff_x = [coefficient_x coeff_x_last_4 coeff_x_last_4 coeff_x_last_4 coeff_x_last_4 coeff_x_last_4 coeff_x_last_4 coeff_x_last_4 coeff_x_last_4 coeff_x_last_4 coeff_x_last_4 coeff_x_last_4 coeff_x_last_4];
new_coeff_y = [coefficient_y coeff_y_last_4 coeff_y_last_4 coeff_x_last_4 coeff_x_last_4 coeff_x_last_4 coeff_x_last_4 coeff_y_last_4 coeff_y_last_4 coeff_x_last_4 coeff_x_last_4 coeff_x_last_4 coeff_x_last_4];

% new_coeff_x = [coefficient_x coeff_x_last_4 coeff_x_last_4 coeff_x_last_4];
% new_coeff_y = [coefficient_y coeff_y_last_4 coeff_y_last_4 coeff_y_last_4];

[rowscoh columnscoh] = size(new_coeff_x);


%% Calculating the phase coherence
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Phase-Correlation
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Cross-correlation based on the article "A wavelet Based Approach for the
%detection of Coupling in EEG Signals" (Ssab, McKeown, Myers and Abu-Gharbieh)

phase_coherence_sum = zeros(rowscoh,columnscoh);
cycle_summation = (1/fre_coherence_builder)*cycles_number_coherence;

%This variable is used to make sure the integral is calculated between
%[-range_sum/2 range_sum/2]
shift_phase = round((cycle_summation*(sampling_frequency/decimation_factor)/2)); 

h = waitbar(0,'0','Name','Calculation in progress... Minutes left');

time_left = 0;

tic

for kk = 1:rowscoh
range_sum = round(cycle_summation*(sampling_frequency/decimation_factor));

if(mod(range_sum,2) ~= 0)
    
    range_sum = range_sum + 1;
    
end

end_sum = range_sum/2;

waitbar(kk/rowscoh,h,sprintf('%f',time_left))

stim_onset_temp = round((stim_onset/1000)*sampling_frequency);

for tt = 1:columnscoh
   
   start_sum = tt;
       %phase_coherence_sum(kk,tt) = abs(sum((new_coeff_x(kk,start_sum:end_sum).*conj(new_coeff_y(kk,start_sum:end_sum)))./(abs((new_coeff_x(kk,start_sum:end_sum)).*new_coeff_y(kk,start_sum:end_sum))))./range_sum); 
     phase_coherence_sum(kk,tt) = abs(sum((new_coeff_x(kk,start_sum + shift_phase - (range_sum/2):shift_phase + end_sum).*conj(new_coeff_y(kk,start_sum + shift_phase - (range_sum/2):shift_phase + end_sum)))./(abs((new_coeff_x(kk,start_sum + shift_phase - (range_sum/2):shift_phase + end_sum)).*new_coeff_y(kk,start_sum + shift_phase - (range_sum/2):shift_phase + end_sum))))./range_sum); 
      
  %end_sum = range_sum + tt;
end_sum = end_sum + 1;
  
%   if (end_sum + stim_onset_temp > columnscoh)              
%                     
%       end_sum = columnscoh - stim_onset_temp;
                  if (end_sum + shift_phase > columnscoh)              
                   
      end_sum = end_sum - 1; 
  end
  
  if (kk == 1)
        
        time_elapsed = toc;
        
        end
   
  time_left = time_elapsed*(rowscoh - kk)/60;
  
end

fre_coherence_builder = fre_coherence_builder + 1;
cycle_summation = (1/(fre_coherence_builder))*cycles_number_coherence;
%shift_phase = round(cycle_summation*(sampling_frequency/decimation_factor))/2; 

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

phase_coherence = phase_coherence_sum(:,1:columns_coeff);

if (wavelet_builder_time_frequency_check == 0)

%% Creating the range of frequencies with round(high_freq/low_freq)*10 Hz step
frequency_range_plot = [fre_coherence_plotting:1:highest_frequency];

for kk = 1:length(freq_average)
    
    frequency_range_temp(kk) = find(frequency_range_plot == freq_average(kk));

            
end

frequency_range = frequency_range_plot(frequency_range_temp);

%tt_domain = (start_t - 1 + shift_phase:end_t - 1 + shift_phase)/sampling_frequency - (stim_onset)/sampling_frequency;
%tt_domain = (start_t - 1 + shift_phase:end_t - 1 + shift_phase)/sampling_frequency - (stim_onset/1000);
%tt_domain = ([0:end_t - start_t]/sampling_frequency);

if (check_odd_even == 1)
   
    tt_domain(end) = [];  
    
end

wavelet_builder_time_frequency_check = 1;

end
  
%Remove additional noise
remove_noise = round(((cycles_number_coherence/frequency_range_plot(1))*sampling_frequency)/2);

% phase_coherence = phase_coherence(:,1:end-remove_noise);
% tt_domain = tt_domain(1,1:end-remove_noise);

close (gcf)

figure
contourf(1000*tt_domain,frequency_range_plot,phase_coherence)

        set(gca,'fontweight','bold')

    title(['\bfPhase-coherence of: ' EEG_cwt_phase_coherence_selected(1:end-4) ' - ' EEGII_cwt_phase_coherence_selected(1:end-4) ' of ' name_channels(1)]);   
   
    xlabel('\bfTime(s)')
    ylabel('\bfFrequency (Hz)')

colorbar

caxis([0 1])

set(gca,'fontweight','bold')

%cd ..


saveas(gcf,['Coherence_between_' EEG_cwt_phase_coherence_selected(1:end-4) '_and_' EEGII_cwt_phase_coherence_selected(1:end-4) '_' name_channels '.fig'])

close (gcf)

%% Filtering the time series and saving the phase coherence and the time series

%% Filtering the time series
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[b,a] = butter(3,[frequency_range_plot(1) frequency_range_plot(end)]/(sampling_frequency/2)); 
  
 FileName_EEG = filtfilt(b,a,FileName_EEG);
 FileName_EEGII = filtfilt(b,a,FileName_EEGII);
 tt_time_series = ([start_t:end_t - 1]/sampling_frequency) - (stim_onset_temp + start_t - 1)/sampling_frequency;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 

 figure
subplot(2,1,1)
contourf(1000*tt_domain,frequency_range_plot,phase_coherence)
    
    title(['\bfPhase-coherence with respect to threshold ' num2str(sign_threshold) ' of: ' EEG_cwt_phase_coherence_selected(1:end-4) ' - ' EEGII_cwt_phase_coherence_selected(1:end-4) ' of ' name_channels]);   

    xlabel('\bfTime(s)')
    ylabel('\bfFrequency (Hz)')


set(gca,'fontweight','bold')

subplot(2,1,2)

% plot(1000*tt_time_series(:,find(tt_time_series <= tt_domain(1),1,'Last'):find(tt_time_series <= tt_domain(end),1,'Last')),FileName_EEG(:,find(tt_time_series <= tt_domain(1),1,'Last'):find(tt_time_series <= tt_domain(end),1,'Last')),'r')
plot(1000*tt_time_series,FileName_EEG,'r')

hold on

% plot(1000*tt_time_series(:,find(tt_time_series <= tt_domain(1),1,'Last'):find(tt_time_series <= tt_domain(end),1,'Last')),FileName_EEGII(:,find(tt_time_series <= tt_domain(1),1,'Last'):find(tt_time_series <= tt_domain(end),1,'Last')),'k')
plot(1000*tt_time_series,FileName_EEGII,'k')

xlabel('\bfTime(s)')
    ylabel('\bfAmplitude(uV)')
    
    title('\bfTime series')
    
legend(EEG_cwt_phase_coherence_selected,EEGII_cwt_phase_coherence_selected)

set(gca,'fontweight','bold')

axis tight

saveas(gcf,['Coherence_Time_Series_between_' EEG_cwt_phase_coherence_selected(1:end-4) '_and_' EEGII_cwt_phase_coherence_selected(1:end-4) '_' name_channels '.fig'])

close (gcf)

%% Plotting the coherence with respect to the significance threshold. 1 => significant; 0 => not significant
phase_coherence_sign_threshold = zeros(size(phase_coherence,1),size(phase_coherence,2));

for kk = 1:size(phase_coherence,1)
                
    phase_coherence_sign_threshold(kk,find(phase_coherence(kk,:) >= sign_threshold)) = 1;

end

figure
subplot(2,1,1)

contourf(1000*tt_domain,frequency_range_plot,phase_coherence_sign_threshold)

title(['\bfPhase-coherence with respect to threshold ' num2str(sign_threshold) ' of: ' EEG_cwt_phase_coherence_selected(1:end-4) ' - ' EEGII_cwt_phase_coherence_selected(1:end-4) ' of ' name_channels]);   
   
    xlabel('\bfTime(s)')
    ylabel('\bfFrequency (Hz)')

%colorbar

%caxis([0 1])

set(gca,'fontweight','bold')

subplot(2,1,2)

% plot(1000*tt_time_series(:,find(tt_time_series <= tt_domain(1),1,'Last'):find(tt_time_series <= tt_domain(end),1,'Last')),FileName_EEG(:,find(tt_time_series <= tt_domain(1),1,'Last'):find(tt_time_series <= tt_domain(end),1,'Last')),'r')
plot(1000*tt_time_series,FileName_EEG,'r')

hold on

% plot(1000*tt_time_series(:,find(tt_time_series <= tt_domain(1),1,'Last'):find(tt_time_series <= tt_domain(end),1,'Last')),FileName_EEGII(:,find(tt_time_series <= tt_domain(1),1,'Last'):find(tt_time_series <= tt_domain(end),1,'Last')),'k')
plot(1000*tt_time_series,FileName_EEGII,'k')

xlabel('\bfTime(s)')
    ylabel('\bfAmplitude(uV)')
    
    title('\bfTime series')
    
legend(EEG_cwt_phase_coherence_selected,EEGII_cwt_phase_coherence_selected)

set(gca,'fontweight','bold')

axis tight

saveas(gcf,['Coherence_Sign_Threshold_between_' EEG_cwt_phase_coherence_selected(1:end-4) '_and_' EEGII_cwt_phase_coherence_selected(1:end-4) '_' name_channels '.fig'])

close (gcf)

%% Tracking some frequencies in time
coherence_selected_frequencies = phase_coherence(frequency_range_temp,:);

figure

plot(1000*tt_domain,coherence_selected_frequencies(:,:))

title(['\bfPhase-coherence of: ' EEG_cwt_phase_coherence_selected(1:end-4) ' and ' EEGII_cwt_phase_coherence_selected(1:end-4) ' of ' name_channels ' with respect to threshold ' num2str(sign_threshold)]);    
   
    xlabel('\bfTime(s)')
    ylabel('\bfPhase-Coherence value')

    legend_values = [];
for kk = 1:length(frequency_range)    
   
    legend_values =[legend_values;{num2str(frequency_range(kk))}];
   
end
    
legend(legend_values)

set(gca,'fontweight','bold')

axis tight

saveas(gcf,['Coherence_Selected_Frequencies_between_' EEG_cwt_phase_coherence_selected(1:end-4) '_and_' EEGII_cwt_phase_coherence_selected(1:end-4) '_' name_channels '.fig'])

close (gcf)

%% Mean of the frequencies analyzed
av_coherence = mean(phase_coherence(:,find(tt_domain >= 0,1,'first'):end)');
av_coherence = av_coherence(frequency_range_temp);

figure

plot(frequency_range,av_coherence)

title(['\bfAverage Phase-coherence of: ' EEG_cwt_phase_coherence_selected(1:end-4) ' and ' EEGII_cwt_phase_coherence_selected(1:end-4) ' of ' name_channels ' with respect to threshold ' num2str(sign_threshold)]);   
      
    xlabel('\bfFrequency(Hz)')
    ylabel('\bfPhase-Coherence value')

set(gca,'fontweight','bold')

saveas(gcf,['Coherence_Average_Selected_Frequencies_between_' EEG_cwt_phase_coherence_selected(1:end-4) '_and_' EEGII_cwt_phase_coherence_selected(1:end-4) '_' name_channels '.fig'])

close (gcf)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Mean of the frequencies analyzed per region

%% Transition
av_coherence = mean(phase_coherence(:,find(tt_domain >= 0,1,'first'):find(tt_domain <=0.062 ,1,'last'))');
av_coherence = av_coherence(frequency_range_temp);

figure

plot(frequency_range,av_coherence)

title(['\bfAverage Phase-coherence of transition region of: ' EEG_cwt_phase_coherence_selected(1:end-4) ' and ' EEGII_cwt_phase_coherence_selected(1:end-4) ' of ' name_channels ' with respect to threshold ' num2str(sign_threshold)]);   
      
    xlabel('\bfFrequency(Hz)')
    ylabel('\bfPhase-Coherence value')

set(gca,'fontweight','bold')

saveas(gcf,['Coherence_Average_Selected_Frequencies_Transition_Region_between_' EEG_cwt_phase_coherence_selected(1:end-4) '_and_' EEGII_cwt_phase_coherence_selected(1:end-4) '_' name_channels '.fig'])

close (gcf)

%% Steady-State
av_coherence = mean(phase_coherence(:,find(tt_domain > 0.062,1,'first'):end)');
av_coherence = av_coherence(frequency_range_temp);

figure

plot(frequency_range,av_coherence)

title(['\bfAverage Phase-coherence of Steady-State region of: ' EEG_cwt_phase_coherence_selected(1:end-4) ' and ' EEGII_cwt_phase_coherence_selected(1:end-4) ' of ' name_channels ' with respect to threshold ' num2str(sign_threshold)]);   
      
    xlabel('\bfFrequency(Hz)')
    ylabel('\bfPhase-Coherence value')

set(gca,'fontweight','bold')

saveas(gcf,['Coherence_Average_Selected_Frequencies_Steady_State_Region_between_' EEG_cwt_phase_coherence_selected(1:end-4) '_and_' EEGII_cwt_phase_coherence_selected(1:end-4) '_' name_channels '.fig'])

end

close (gcf)

save_coherence.data = phase_coherence;
save_coherence.time = tt_domain;
save_coherence.frequency = frequency_range_plot;
save_coherence.channel = name_channels;
save_coherence.name_file_I = EEG_cwt_phase_coherence_selected(1:end-4);
save_coherence.name_file_II = EEGII_cwt_phase_coherence_selected(1:end-4);

save (['PLV_' EEG_cwt_phase_coherence_selected(1:end-4) '_and_' EEGII_cwt_phase_coherence_selected(1:end-4) '_' name_channels '.mat'],'save_coherence')

% %% Calculations have been completed
%   message = 'Calculations completed';
% msgbox(message,'End of the calculations','warn','replace');
% 
% computation_time = toc/60;
% message = (['The analysis was performed in: ' num2str(computation_time) ' minutes']);
% msgbox(message,'Computation time','warn','replace');

delete(h)