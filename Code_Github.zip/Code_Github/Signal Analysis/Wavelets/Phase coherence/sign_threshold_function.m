function [sign_threshold integration_cycles] = sign_threshold_function(combination_selected)

switch combination_selected

case 1
    sign_threshold = 0.95;
    integration_cycles = 4;
    
    case 2
        sign_threshold = 0.93;
        integration_cycles = 5;
        
        case 3
            sign_threshold = 0.90;
            integration_cycles = 6;
            
            case 4
                sign_threshold = 0.87;
                integration_cycles = 7;
                
                case 5
                   sign_threshold = 0.84;
                   integration_cycles = 8;
                   
                    case 6
                      sign_threshold = 0.79; 
                      integration_cycles = 9;
                      
                        case 7
                            sign_threshold = 0.78;
                            integration_cycles = 10;
        
end