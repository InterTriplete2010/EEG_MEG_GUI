function varargout = ABR_Cortical_Import_GUI(varargin)
% ABR_CORTICAL_IMPORT_GUI MATLAB code for ABR_Cortical_Import_GUI.fig
%      ABR_CORTICAL_IMPORT_GUI, by itself, creates a new ABR_CORTICAL_IMPORT_GUI or raises the existing
%      singleton*.
%
%      H = ABR_CORTICAL_IMPORT_GUI returns the handle to a new ABR_CORTICAL_IMPORT_GUI or the handle to
%      the existing singleton*.
%
%      ABR_CORTICAL_IMPORT_GUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in ABR_CORTICAL_IMPORT_GUI.M with the given input arguments.
%
%      ABR_CORTICAL_IMPORT_GUI('Property','Value',...) creates a new ABR_CORTICAL_IMPORT_GUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before ABR_Cortical_Import_GUI_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to ABR_Cortical_Import_GUI_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help ABR_Cortical_Import_GUI

% Last Modified by GUIDE v2.5 10-Aug-2016 10:14:42

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @ABR_Cortical_Import_GUI_OpeningFcn, ...
                   'gui_OutputFcn',  @ABR_Cortical_Import_GUI_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before ABR_Cortical_Import_GUI is made visible.
function ABR_Cortical_Import_GUI_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to ABR_Cortical_Import_GUI (see VARARGIN)

% Choose default command line output for ABR_Cortical_Import_GUI
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes ABR_Cortical_Import_GUI wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = ABR_Cortical_Import_GUI_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Binary file with the raw data uploaded
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Binary_File_Uploaded_Callback(hObject, eventdata, handles)
% hObject    handle to Binary_File_Uploaded (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Binary_File_Uploaded as text
%        str2double(get(hObject,'String')) returns contents of Binary_File_Uploaded as a double


% --- Executes during object creation, after setting all properties.
function Binary_File_Uploaded_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Binary_File_Uploaded (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Upload the binary file with the raw data 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in Upload_Binary_File.
function Upload_Binary_File_Callback(hObject, eventdata, handles)
% hObject    handle to Upload_Binary_File (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global Binary_file_ABR_Cortical_selected;
global Binary_file_ABR_Cortical_directory; 

[Binary_file_ABR_Cortical_selected,Binary_file_ABR_Cortical_directory] = uigetfile('*.abr','Select the "binary" file with the raw data');

set(handles.Binary_File_Uploaded,'String',Binary_file_ABR_Cortical_selected);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Mat file with the info about the binary data uploaded
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Mat_File_Uploaded_Callback(hObject, eventdata, handles)
% hObject    handle to Mat_File_Uploaded (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Mat_File_Uploaded as text
%        str2double(get(hObject,'String')) returns contents of Mat_File_Uploaded as a double


% --- Executes during object creation, after setting all properties.
function Mat_File_Uploaded_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Mat_File_Uploaded (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Upload the "mat" file with the info about the binary data
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in Upload_Mat_File.
function Upload_Mat_File_Callback(hObject, eventdata, handles)
% hObject    handle to Upload_Mat_File (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global Mat_file_ABR_Cortical_selected;
global Mat_file_ABR_Cortical_directory; 

[Mat_file_ABR_Cortical_selected,Mat_file_ABR_Cortical_directory] = uigetfile('*.mat','Select the "mat" file with the info about the raw data');

set(handles.Mat_File_Uploaded,'String',Mat_file_ABR_Cortical_selected);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Name of the Dir where to save the data
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Save_Data_Dir_ABR_Cortical_Callback(hObject, eventdata, handles)
% hObject    handle to Save_Data_Dir_ABR_Cortical (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Save_Data_Dir_ABR_Cortical as text
%        str2double(get(hObject,'String')) returns contents of Save_Data_Dir_ABR_Cortical as a double


% --- Executes during object creation, after setting all properties.
function Save_Data_Dir_ABR_Cortical_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Save_Data_Dir_ABR_Cortical (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Name of the output mat file
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Mat_Name_ABR_Cortical_Callback(hObject, eventdata, handles)
% hObject    handle to Mat_Name_ABR_Cortical (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Mat_Name_ABR_Cortical as text
%        str2double(get(hObject,'String')) returns contents of Mat_Name_ABR_Cortical as a double


% --- Executes during object creation, after setting all properties.
function Mat_Name_ABR_Cortical_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Mat_Name_ABR_Cortical (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Save the data in a specific format
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% --- Executes on button press in Save_Data_ABR_Cortical.
function Save_Data_ABR_Cortical_Callback(hObject, eventdata, handles)
% hObject    handle to Save_Data_ABR_Cortical (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global Binary_file_ABR_Cortical_selected;
global Binary_file_ABR_Cortical_directory; 
global Mat_file_ABR_Cortical_selected;
global Mat_file_ABR_Cortical_directory; 

%% Read the binary data
cd(Binary_file_ABR_Cortical_directory)
open_bin = fopen(Binary_file_ABR_Cortical_selected);
read_data = fread(open_bin,'float32')';

%% Rescale the data. The gain of the TDT system is 20;
% Nbits = 32;
% rescaled_data = read_data*(10*1e6)/(2^((Nbits)/2)); 
rescaled_data = read_data/20;

%% Read the info about the binary data
cd(Mat_file_ABR_Cortical_directory)
open_info = load(Mat_file_ABR_Cortical_selected);

sf = ((1/(open_info.Cn.ADCTick))*10^6)/open_info.Cn.DecimateFactor;
samples_sweep = open_info.Pm.NADCPts/open_info.Cn.DecimateFactor;
time_d = 1000*[0:samples_sweep - 1]/sf - open_info.Pm.PreRecord; 
stop_sweeps = str2double(get(handles.Stop_Sweep_TDT,'String'));
[output_data fig_id fig_id_subplots_trials fig_id_subplots] = extract_trials_ABR_Cortical(open_info,rescaled_data,time_d,stop_sweeps);

%% Saving the data and the figure
data_exported.data = output_data;
data_exported.time = time_d;
data_exported.sampling_frequency = sf;
data_exported.gain = 0;
data_exported.record_type = open_info.Cn.RecordType;
data_exported.dB_Levels = open_info.Pm.ALevel;
data_exported.info_Stim_Cell = open_info.StimCell;
data_exported.info_Pm = open_info.Pm;
data_exported.info_Cn = open_info.Cn;

current_dir = what;

cd(get(handles.Save_Data_Dir_ABR_Cortical,'String'))

mkdir(get(handles.Folder_Name_TDT,'String'))

cd([get(handles.Save_Data_Dir_ABR_Cortical,'String') '\' get(handles.Folder_Name_TDT,'String')]);

save_eeg = [get(handles.Mat_Name_ABR_Cortical,'String') '.mat'];  
        save (save_eeg,'data_exported','-v7.3') %-v7.3 is used to save data > 2Gbytes
      
        saveas(fig_id,[get(handles.Mat_Name_ABR_Cortical,'String') '_Av_dB_Levels_Overlapped.fig'])
        saveas(fig_id_subplots_trials,[get(handles.Mat_Name_ABR_Cortical,'String') '_Av_dB_Levels_Single_Trials.fig'])
        saveas(fig_id_subplots,[get(handles.Mat_Name_ABR_Cortical,'String') '_Av_dB_Levels_Individuals.fig'])
        
        message = 'Data and figures have been saved';

        msgbox(message,'Data and figures saved','warn');

        cd(current_dir.path)
        
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Name of the folder where to save the data
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Folder_Name_TDT_Callback(hObject, eventdata, handles)
% hObject    handle to Folder_Name_TDT (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Folder_Name_TDT as text
%        str2double(get(hObject,'String')) returns contents of Folder_Name_TDT as a double


% --- Executes during object creation, after setting all properties.
function Folder_Name_TDT_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Folder_Name_TDT (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Value used to separate two consecutive sweeps
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Stop_Sweep_TDT_Callback(hObject, eventdata, handles)
% hObject    handle to Stop_Sweep_TDT (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Stop_Sweep_TDT as text
%        str2double(get(hObject,'String')) returns contents of Stop_Sweep_TDT as a double


% --- Executes during object creation, after setting all properties.
function Stop_Sweep_TDT_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Stop_Sweep_TDT (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
