function [reorg_stim fig_id fig_id_subplots_trials fig_id_subplots] = extract_trials_ABR_Cortical(open_info,rescaled_data,time_d,stop_sweeps);

%% Read basic info the extraction of the sweeps
length_sweep = open_info.Pm.NADCPts/open_info.Cn.DecimateFactor;
sweeps_N = open_info.Pm.NTrial;

%% Extract the sweeps
flag_sweep = 0;

if (rescaled_data(1) == stop_sweeps)
 
% This condition applies if a "stop-sweep sample" is applied to the data. In this case there is a "stop_sweeps" in between two consecutive sweeps.     
start_sweep = 2;
end_sweep = length_sweep + 1;
check_flag = 1;

else

% This condition applies if a "stop-sweep sample" is not applied to the data.      
    
    start_sweep = 1;
end_sweep = length_sweep;
check_flag = 0;    

end

save_sweeps = [];

for kk = 1:sweeps_N
 
save_sweeps = [save_sweeps;rescaled_data(1,start_sweep:end_sweep)];

start_sweep = start_sweep + length_sweep + check_flag;
end_sweep = end_sweep + length_sweep + check_flag;;
    
end

 

%% Reorganize according to the stimulus level
diff_levels = open_info.Pm.ALevel;
reorg_stim = zeros(length(diff_levels),open_info.Pm.NRep,size(save_sweeps,2));

%Find the position of the cell where the dB levels have been saved
cell_pos = [];
cell_names = open_info.StimCell(:,1);

for kk = 1:length(cell_names)

    if (strcmp(cell2mat(cell_names(kk,:)),'ALevel'))
        
       cell_pos = kk; 
        
    end
    
end

if (isempty(cell_pos))
    
    message = 'No ALevel field has been found. Analysis has been aborted';

        msgbox(message,'Analysis aborted','warn');
    
    return;
    
end
    
for hh = 1:length(diff_levels)
   
    temp_lev = find(diff_levels(hh) == cell2mat(open_info.StimCell(cell_pos,2)));
    
    temp_val = save_sweeps(temp_lev,:);
    reorg_stim(hh,:,:) = temp_val;
    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Plotting the averages for each sound level in one figure
figure
fig_id = gcf;

for gg = 1:size(reorg_stim,1)
   
    plot(time_d,mean(squeeze(reorg_stim(gg,:,:))),'Color',[randi(255) randi(255) randi(255)]/255)
    hold on
end

axis tight

hold off

legend(num2str(diff_levels'))

title('Average for each dB level tested')

xlabel('Time (ms)')
ylabel('Amplitude (\muV)')

set(fig_id,'Color',[1 1 1])
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Plotting the single trials + average for each sound level individually
figure
fig_id_subplots_trials = gcf;

for gg = 1:size(reorg_stim,1)
   
    subplot(2,5,gg)
    plot(time_d,squeeze(reorg_stim(gg,:,:))','b')
    
    hold on
    plot(time_d,mean(squeeze(reorg_stim(gg,:,:))),'Color','r','Linewidth',2)
    hold off
    
    title(['Level: ' num2str(diff_levels(gg))])
    
    axis tight;
    
end

xlabel('Time (ms)')
ylabel('Amplitude (\muV)')

set(fig_id_subplots_trials,'Color',[1 1 1])
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Plotting the averages for each sound level individually
figure
fig_id_subplots = gcf;

for gg = 1:size(reorg_stim,1)
   
    subplot(2,5,gg)
    plot(time_d,mean(squeeze(reorg_stim(gg,:,:))),'r')
    title(['Level: ' num2str(diff_levels(gg))])
    
    axis tight;

end



xlabel('Time (ms)')
ylabel('Amplitude (\muV)')

set(fig_id_subplots,'Color',[1 1 1])
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


