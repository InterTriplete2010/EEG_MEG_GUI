function display(t)


get(t);